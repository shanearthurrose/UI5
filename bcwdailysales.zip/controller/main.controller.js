sap.ui.define(["sap/ui/core/mvc/Controller"], function(Controller) {
	"use strict";
	return Controller.extend("BCWDailySales.controller.main", {
		onInit: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");

			//	var omtdPanel = this.byId("mtdpanel");
			//	omtdPanel.setBusy(true);

			//sap.ui.commons.MessageBox.alert("here");
			this.getView().setModel(this.getOwnerComponent()._getDailySales(this.getView()), "sales");

			//	var monthPanel = this.byId("monthpanel");
			//	monthPanel.setBusy(true);

			this.getView().setModel(this.getOwnerComponent()._getMonthlySales(this.getView()), "monthly");

			//	sap.ui.commons.MessageBox.alert("here again");
		},

		onBeforeRendering: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");

			//sap.ui.commons.MessageBox.alert("here");

			this.getView().setVisible(true);
			//this.byId("mtdpanel").seBusy(true);

		},

		formatNumber: function(value) {
			var intValue = parseFloat(value);
			if (parseFloat(value) < 0) {
				return "Error";
			}
			return "Success";
		},

		formatMyNumber: function(value) {
			//sap.m.MessageToast.show("Value:"+value);
			return value;
			//return ( parseFloat(Number(value).toPrecision() / 1000000).toFixed(2) );
		},
		formatNumber2decimals: function(value) {
			//return value;
			//	sap.m.MessageToast.show("Value:"+value);
			return (parseFloat(value).toFixed(2));
		},
		formatDate: function(value) {
			//	return value;
			var month = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November",
				"December"
			];
			//sap.m.MessageToast.show("Value:"+value);
			var date = new Date(value);
			//	sap.m.MessageToast.show("Value:"+ month[date.getMonth()]);
			return (date.getDate() + '-' + month[date.getMonth()] + '-' + date.getFullYear() + ' MTD Daily Sales');
		},

		formatMonthDate: function(value) {
			//	return value;
			var month = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November",
				"December"
			];
			//sap.m.MessageToast.show("Value:"+value);
			var date = new Date(value);
			//	sap.m.MessageToast.show("Value:"+ month[date.getMonth()]);
			return (date.getDate() + '-' + month[date.getMonth()] + '-' + date.getFullYear() + ' Full Month');
		},
		onMTDItemPress: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var mtd = this.byId("mtdtable");
			//	sap.ui.commons.MessageBox.alert("here");
			mtd.setGrowingThreshold(1);
			//	if (mtd.getVisibleRowCount() === 1) {
			//		mtd.setVisibleRowCount(5);
			//	} else {
			//		mtd.setVisibleRowCount(1);
			//	}
		},

		onfullItemPress: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var table = this.byId("fulltable");
			if (table.getVisibleRowCount() === 1) {
				table.setVisibleRowCount(5);
			} else {
				table.setVisibleRowCount(1);
			}
		},

		/**
		 *@memberOf FEEDBACK.controller.main
		 */
		onRefresh: function() {

			var oRefresh = new sap.m.PullToRefresh();
			oRefresh = this.byId("refresh");
			/*
			   @todo call to get data with refresh flag = 'y'       
			*/
			this.getView().setModel(this.getOwnerComponent()._getDailySales(this.getView(), true), "sales");
			this.getView().setModel(this.getOwnerComponent()._getMonthlySales(this.getView(), true), "monthly");

			oRefresh.hide();
		}

	});

});