sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"BCWDailySales/model/models"
], function(UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("BCWDailySales.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			// call the base component's init function
			//this._getDailySales();

			UIComponent.prototype.init.apply(this, arguments);
			// set the device model
			this.setModel(models.createDeviceModel(), "device");

		},

		_getDailySales: function(view, refresh) {
			jQuery.sap.require("sap.ui.commons.MessageBox");

			//sap.ui.core.BusyIndicator.show();

			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var oXMLModel = new sap.ui.model.xml.XMLModel();
			var oURL = "/rest/biCommon/service/dailySales";

			if (refresh) {
				oURL = oURL + "?refresh=true";
			}
			
			var omtdPanel = view.byId("mtdpanel");
			omtdPanel.setBusy(true);			

			that.setModel(oXMLModel, "sales");

			oModel.read(
				//"/rest/biCommon/service/dailySales",
				oURL,
				null, null, true,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					oXMLModel.setXML(obody);

					//that.setModel(oXMLModel, "sales");
					that.setModel(oXMLModel, "monthly");

					//	sap.ui.core.BusyIndicator.hide();
					//that.view.byId("mtdpanel").setBusy(false);
					var monthPanel = view.byId("monthpanel");
					monthPanel.setBusy(false);

					//		sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));
					//	sap.ui.commons.MessageBox.alert(oXMLModel.getProperty("/s0:documentname"));
				},
				function(oError) {
					var monthPanel = view.byId("monthpanel");
					monthPanel.setBusy(false);
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oError,null, 4));
				});
			return oXMLModel;
		},

		_getMonthlySales: function(view, refresh) {
			jQuery.sap.require("sap.ui.commons.MessageBox");

			//sap.ui.core.BusyIndicator.show();

			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var oXMLModel = new sap.ui.model.xml.XMLModel();
			var oURL = "/rest/biCommon/service/dailySalesMonth";

			var monthPanel = view.byId("monthpanel");
			monthPanel.setBusy(true);

			if (refresh) {
				oURL = oURL + "?refresh=true";
			}

			that.setModel(oXMLModel, "sales");

			oModel.read(
				oURL,
		//		"/rest/biCommon/service/dailySalesMonth",
				null, null, true,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					oXMLModel.setXML(obody);

					that.setModel(oXMLModel, "sales");

					//sap.ui.core.BusyIndicator.hide();
					var monthPanel = view.byId("mtdpanel");
					monthPanel.setBusy(false);

					//	sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));
					//	sap.ui.commons.MessageBox.alert(oXMLModel.getProperty("/s0:documentname"));
				},
				function(oError) {
					var monthPanel = view.byId("mtdpanel");
					monthPanel.setBusy(false);
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oError,null, 4));
				});
			return oXMLModel;
		}

	});

});