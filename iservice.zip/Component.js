sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"iService/model/models"
], function(UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("iService.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			var oModel = new sap.ui.model.json.JSONModel();
			var userModel = new sap.ui.model.json.JSONModel("/services/userapi/currentUser");
			userModel.loadData("/services/userapi/currentUser", null, false);

			this.setModel(userModel, "userInfo");
			// set the device model
			this.setModel(models.createDeviceModel(), "device");

			this.getRouter().initialize();
			this.getRouter().navTo("initial", {}, false);

		},

		_getTicketCount: function(view, field) {

			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();

			var oTile = new sap.m.StandardTile();
			var oTile = view.byId(field);
			oTile.setBusy(true);

			var oXML = new sap.ui.model.xml.XMLModel();
			that.setModel(oXML, "TICKETS");

			oModel.read(
				//"/rest/commonCherwellWebservice/service/incident?OwnedByEmail=" + this.getModel("userInfo").getProperty("/email") +
				           "/rest/commonCherwellWebservice/service/incident?OwnedByEmail=Tim.Caldwell@lionco.com" +
				"&requestedFields=IncidentID,Description,Status&pageNumber=1&Status=In Progress",
				null, null, true,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					var oXMLModel = new sap.ui.model.xml.XMLModel();
					oXMLModel.setXML(obody);

					var oXML = new sap.ui.model.xml.XMLModel();
					oXML.setXML(obody);

					that.setModel(oXML, "TICKETS");

					var ototalOpen = oXML.getProperty("/totalRows");
					that.setModel(ototalOpen, "TOTAL");

					oTile.setBusy(false);
					oTile.setNumber(ototalOpen);

					var object = {};
					object.busObId = oXML.getProperty("/businessObjects/busObId");
					object.busObPublicId = oXML.getProperty("/businessObjects/busObPublicId");
					object.busObRecId = oXML.getProperty("/businessObjects/busObRecId");

					that.getOwnerComponent().setModel(object, "CHERWELL");
					sap.ui.commons.MessageBox.alert("ticket count");
				},
				function(oError) {
					oTile.setBusy(false);
					sap.ui.commons.MessageBox.alert("Session timeout - please refresh");
				});
		},

		_getTicket: function(ticket, view, field, successPage) {

			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			//that.setModel("start", "SINGLETICKET");
			var oField = view.byId(field);
			oField.setBusy(true);

			var oXML = new sap.ui.model.xml.XMLModel();
			that.setModel(oXML, "SINGLETICKET");

			oModel.read(
				"/rest/commonCherwellWebservice/service/incident/" + ticket,
				null, null, true,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					//var oXMLModel = new sap.ui.model.xml.XMLModel();
					//oXMLModel.setXML(obody);

					var oXML = new sap.ui.model.xml.XMLModel();
					oXML.setXML(obody);

					that.setModel(oXML, "SINGLETICKET");

					var object = {};
					object.busObId = oXML.getProperty("/businessObjects/busObId");
					object.busObPublicId = oXML.getProperty("/businessObjects/busObPublicId");
					object.busObRecId = oXML.getProperty("/businessObjects/busObRecId");

					that.setModel(object, "CHERWELL");
					oField.setBusy(false);
					that.getRouter().navTo(successPage, {}, false);
					//sap.ui.commons.MessageBox.alert(JSON.stringify(oXMLModel.getXML(), null, 4));
				},
				function(oError) {
					oField.setBusy(false);
					sap.ui.commons.MessageBox.alert("Session timeout - please refresh");
				});
			//sap.ui.commons.MessageBox.alert(JSON.stringify(this.getModel("SINGLETICKET"), null, 4));
		},
		/*
		  get all 
		*/
		_getTickets: function(view, field, successPage) {

			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			//that.setModel(null, "TICKETS");
			//var oTile = new sap.m.StandardTile();
			var oField = view.byId(field);
			oField.setBusy(true);

			var oXML = new sap.ui.model.xml.XMLModel();
			that.setModel(oXML, "TICKETS");

			oModel.read(
				//"/rest/commonCherwellWebservice/service/incident?OwnedByEmail=" + this.getModel("userInfo").getProperty("/email") +
				    "/rest/commonCherwellWebservice/service/incident?OwnedByEmail=Tim.Caldwell@lionco.com" +
				"&requestedFields=IncidentID,Description,Status&pageNumber=1&Status=In Progress",
				null, null, true,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					var oXMLModel = new sap.ui.model.xml.XMLModel();
					oXMLModel.setXML(obody);

					var oXML = new sap.ui.model.xml.XMLModel();
					oXML.setXML(obody);

					that.setModel(oXML, "TICKETS");

					var ototalOpen = oXML.getProperty("/totalRows");
					that.setModel(ototalOpen, "TOTAL");

					oField.setBusy(false);

					var object = {};
					object.busObId = oXML.getProperty("/businessObjects/busObId");
					object.busObPublicId = oXML.getProperty("/businessObjects/busObPublicId");
					object.busObRecId = oXML.getProperty("/businessObjects/busObRecId");

					that.setModel(object, "CHERWELL");
					that.getRouter().navTo(successPage, {}, false);
					//sap.ui.commons.MessageBox.alert("here");
					//sap.ui.commons.MessageBox.alert(JSON.stringify(oXMLModel.getXML(), null, 4));
				},
				function(oError) {
					oField.setBusy(false);
					sap.ui.commons.MessageBox.alert("Session timeout - please refresh");
					//sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				});
		}
	});

});