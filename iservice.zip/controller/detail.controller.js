sap.ui.define(["sap/ui/core/mvc/Controller"], function(Controller) {
	"use strict";
	return Controller.extend("iService.controller.detail", {
		/**
		 *@memberOf iService.controller.detail
		 */

		onInit: function() {

			/*
			 * sart to add coding to get the incident details - then show
			 */

		},
		onBeforeRendering: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			//sap.ui.commons.MessageBox.alert("here");
			this.getView().setModel(this.getOwnerComponent().getModel("SINGLETICKET"));
			this.getView().setVisible(true);

		},

		onBack: function() {
			//jQuery.sap.require("sap.ui.commons.MessageBox");
			//sap.ui.commons.MessageBox.alert("back");
			this.getView().setVisible(false);
			//jQuery.sap.require("sap.ui.commons.MessageBox");
			//sap.ui.commons.MessageBox.alert(JSON.stringify(this.getOwnerComponent().getModel("TICKETS"), null, 4));
			if (this.getOwnerComponent().getModel("SEARCH") !== true) {
				this.getOwnerComponent().getRouter().navTo("mycalls", {}, false);
			} else {
				this.getOwnerComponent().setModel(false,"SEARCH");
				this.getOwnerComponent().getRouter().navTo("search", {}, false);
			}
		}

	});
});