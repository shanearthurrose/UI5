sap.ui.define(["sap/ui/core/mvc/Controller"], function(Controller) {
	"use strict";
	return Controller.extend("iService.controller.main", {
		/**
		 *@memberOf iService.controller.main
		 */
		onInit: function(){
			jQuery.sap.require("sap.ui.commons.MessageBox");
			this.getOwnerComponent()._getTicketCount(this,"myopencalls");
	
		//  "name":"S0015789647","firstName":"Shane","lastName":"Rose","email":"shane.rose@lionco.com","displayName":"Shane Rose (S0015789647)"
		//	sap.ui.commons.MessageBox.alert("here"+this.getOwnerComponent().getModel("userInfo").getJSON());
			this.byId("mainpage").setTitle("iService Portal - " + this.getOwnerComponent().getModel("userInfo").getProperty("/displayName"));
			//this.byId("userName").setText(this.getOwnerComponent().getModel("userInfo").getProperty("/displayName"));
		},
		
		onPress: function() {
			//_getTickets: function(view, field, successPage) {
			this.getOwnerComponent()._getTickets(this,"myopencalls","mycalls");
		},
		
		onSearchPress: function(){
			this.getOwnerComponent().getRouter().navTo("search", {}, false);
		}

	});
});