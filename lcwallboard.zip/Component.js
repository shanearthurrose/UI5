sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"lcwallboard/model/models"
], function(UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("lcwallboard.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
		},

		_getCallInfo: function() {

			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			//that.setModel("callsWaiting");

			oModel.read("/rest/callCentreCommon.restsvc.lcEim",
				null, null, false,
				function(oData, oResponse) {
					// create JSON model  
					oDataJSONModel.setData(oResponse);
					var obody = oDataJSONModel.getProperty("/body");
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					var oXMLModel = new sap.ui.model.xml.XMLModel();
					oXMLModel.setXML(obody);
					//sap.ui.commons.MessageBox.alert(JSON.stringify(oXMLModel.getXML(), null, 4));

					// Calls Waiting
					//	sap.ui.commons.MessageBox.alert(oXMLModel.getProperty("/@CallsWaiting"));
					//    var callsWaiting = oXMLModel.getProperty("/@CallsWaiting");
					that.setModel(oXMLModel, "callsInfo");

				},
				function(oError) {
				//	sap.ui.commons.MessageBox.alert("error:" + JSON.stringify(oError, null, 4));
				});

		},

		_getWaitTime: function() {

			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			//that.setModel("callsWaiting");

			oModel.read("/rest/callCentreCommon.restsvc.lcAwt",
				null, null, false,
				function(oData, oResponse) {
					// create JSON model  
					oDataJSONModel.setData(oResponse);
					var obody = oDataJSONModel.getProperty("/body");
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					var oXMLModel = new sap.ui.model.xml.XMLModel();
					oXMLModel.setXML(obody);
					//sap.ui.commons.MessageBox.alert(JSON.stringify(oXMLModel.getXML(), null, 4));

					// Calls Waiting
					//	sap.ui.commons.MessageBox.alert(oXMLModel.getProperty("/@LCAWT"));
					var waitTime = oXMLModel.getProperty("/@LCAWT");
					that.setModel(waitTime, "waittime");

				},
				function(oError) {
				//	sap.ui.commons.MessageBox.alert("error:" + JSON.stringify(oError, null, 4));
				});

		},

		_getCallsWaiting: function() {

			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			//that.setModel("callsWaiting");
		//	sap.ui.commons.MessageBox.alert("refresh");
			oModel.read("/rest/callCentreCommon.restsvc.lcCallsWaiting",
				null, null, false,
				function(oData, oResponse) {
					// create JSON model  
					oDataJSONModel.setData(oResponse);
					var obody = oDataJSONModel.getProperty("/body");
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					var oXMLModel = new sap.ui.model.xml.XMLModel();
					oXMLModel.setXML(obody);
				//	sap.ui.commons.MessageBox.alert(JSON.stringify(oXMLModel.getXML(), null, 4));

					// Calls Waiting
					
					// LCCallsWaiting=\"0\" LCLongestCall=\"1899-12-30 00:00:00.0\"
					//	sap.ui.commons.MessageBox.alert(oXMLModel.getProperty("/@CallsWaiting"));
					//var NocallsWaiting = oXMLModel.getProperty("/@LCCallsWaiting");
					//var TimecallsWaiting = oXMLModel.getProperty("/@LCLongestCall");					
				//	that.setModel(oXMLModel, "callswaiting");
					that.setModel(oXMLModel, "callsWaiting");					
					
					

				});
//				function(oError) {
//					sap.ui.commons.MessageBox.alert("error:" + JSON.stringify(oError, null, 4));
				//	sap.ui.commons.MessageBox.alert(oError.statusCode);					
//				});

		},
		_getQueueInfo: function() {

			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			//that.setModel("callsWaiting");

			oModel.read("/rest/callCentreCommon.restsvc.lcCallType",
				null, null, false,
				function(oData, oResponse) {
					// create JSON model  
					oDataJSONModel.setData(oResponse);
					var obody = oDataJSONModel.getProperty("/body");
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					var oXMLModel = new sap.ui.model.xml.XMLModel();
					oXMLModel.setXML(obody);
					//sap.ui.commons.MessageBox.alert(JSON.stringify(oXMLModel.getXML(), null, 4));

					// Calls Waiting
					//	sap.ui.commons.MessageBox.alert("oldest:"+oXMLModel.getProperty("/rs1/2/currentOldest"));
					//    var callsWaiting = oXMLModel.getProperty("/@CallsWaiting");
					//	var oFilter = new sap.ui.model.Filter("property");
					//	oFilter.fnFilter = function(value) {
					//	   return (value > 100);
					//	};
					var currentWait = oXMLModel.getProperty("/rs1/2/currentOldest");
					//sap.ui.commons.MessageBox.alert("oldest:" + model.length);
					that.setModel(oXMLModel, "queueinfo");
					that.setModel(currentWait, "currentwait");

				},
				function(oError) {
				//	sap.ui.commons.MessageBox.alert("error:" + JSON.stringify(oError, null, 4));
				});

		}
	});
});