sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("MB.controller.View1", {

		onInit: function() {
			var today = new Date();
			this.byId("DP1").setDateValue(today);
		},

		onPress: function(ev) {
			this.getOwnerComponent().getRouter().navTo("View2");
		}

	});
});