sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("MB.controller.View5", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf MB.view.View4
		 */
			onInit: function() {
		
			},

		onBack: function() {
			this.getOwnerComponent().getRouter().navTo("View4");
		},
		
		
		onAddProduct: function(ev) {
			var customData = ev.getSource().getCustomData();

			if (!this.oAddProduct) {
				this.oAddProduct = sap.ui.xmlfragment("MB.view.Product", this); 
			}
//			sap.ui.getCore().byId("agendatype").setValue();
//			sap.ui.getCore().byId("agendasubtype").setValue();

			this.oAddProduct.open();
		},
		
		onCloseDialog: function(ev){
			this.oAddProduct.close();
		},
		
		onSubmit: function(ev){
			this.getOwnerComponent().getRouter().navTo("View6");	
		},
		/*
		  add to list
		*/
		onSaveDialog: function(ev){
			var product = sap.ui.getCore().byId("product").getSelectedKey();
			var description = sap.ui.getCore().byId("product").getValue();
			var qty = sap.ui.getCore().byId("qty").getValue();
			var unit = sap.ui.getCore().byId("unit").getValue();						
			
			var item = new sap.m.ObjectListItem({title:description,number:qty,numberUnit:unit});
			var attrib = new sap.m.ObjectAttribute();
			attrib.setText(product);
			item.addAttribute(attrib);
			this.byId("products").addItem(item);
			this.onCloseDialog();
		}
		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf MB.view.View4
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf MB.view.View4
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf MB.view.View4
		 */
		//	onExit: function() {
		//
		//	}

	});

});