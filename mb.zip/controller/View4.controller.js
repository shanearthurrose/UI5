sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("MB.controller.View4", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf MB.view.View4
		 */
		onInit: function() {
			var oRouter = this.getOwnerComponent().getRouter();
			oRouter.attachRouteMatched(function(oEvent) {
				if (oEvent.getParameter("name") !== "View4") {
					return;
				}
				this._selectItemWithId(oEvent.getParameter("arguments"));
			}, this);
		},

		_selectItemWithId: function(arg) {
			//	this.getOwnerComponent()._getSalesDrive(this);	
			this.byId("DD").setDateValue(this.getOwnerComponent().dd);
		},

		onBack: function() {
			this.getOwnerComponent().getRouter().navTo("View3");
		},

		onNext: function(ev) {
			this.getOwnerComponent().getRouter().navTo("View5");
		},
		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf MB.view.View4
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf MB.view.View4
		 */
		onAfterRendering: function() {

		}

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf MB.view.View4
		 */
		//	onExit: function() {
		//
		//	}

	});

});