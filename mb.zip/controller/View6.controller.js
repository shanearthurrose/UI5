sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("MB.controller.View6", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf MB.view.View4
		 */
		onInit: function() {
			var messagePage = new sap.m.MessagePage();
			messagePage = this.byId("message");

			this.getView().setVisible(true);

			messagePage.setText("MasterBlast MMU Delivery Create");
			messagePage.setTitle("MMU Delivery Created");
			messagePage.setDescription("Thankyou");

		},

		onBack: function() {
			this.getOwnerComponent().getRouter().navTo("View1");
		}

	});

});