sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";
	return Controller.extend("callplanning.controller.RetailReview", {

		onInit: function() {
			
			// a validation error will be disallow 
			// 1. back navigation
			// 2. save and close
		   //  3. block editing on all other rows
			// this.canProceed = {
			// 	row: null,
			// 	fields: null,
			// 	message: null
			// };
			
			// check if this function has been called before
			
			var prevView = this.getOwnerComponent().prevView;
			var oRetailReviewConfig = new sap.ui.model.json.JSONModel({
				prevView: prevView
			});
			this.getView().setModel(oRetailReviewConfig, "retailReviewConfig");
			var oRouter = this.getOwnerComponent().getRouter();
			/*
			Attach a listener to the view, so fm: _selectItemWithId will be called everytime this view is triggered via Route
			*/

			oRouter.attachRouteMatched(function(oEvent) {
				if (oEvent.getParameter("name") !== "retailreview") {
					return;
				}
				this._selectItemWithId(oEvent.getParameter("arguments"));
				
				this.getView().byId("tblRetailReview");
			}, this);

		},

		_selectItemWithId: function(arg) {
			var oCustomer = this.getOwnerComponent()._getCustomer();
			var oOutlet = this.getOwnerComponent()._getOutlet();
			//implementation
			var callId = oCustomer.getActivityId();
		//	var outlet = this.getOwnerComponent().getModel(callId);
		//	var assessId = outlet.marketintelid;

			var accountId = oCustomer.getAccountId();
			this.byId("ddlDeliverablesAmended").setVisible(true);
			this.byId("ddlReasonCode").setVisible(true);

//			if (this.getOwnerComponent().prevView === "plan") {
//				this.byId("ddlDeliverablesAmended").setVisible(false);
//				this.byId("ddlReasonCode").setVisible(false);
//			}


			//var accountId = "1-2N361U";
			//var callId = "1-4BETNAW"; 
			this.getOwnerComponent()._getRetailReviewData(this.byId("tblRetailReview"), accountId, callId);
			sap.ui.core.BusyIndicator.hide();
			//	alert(oOutlet.getActivityId());                 
		},
		
		onTableInitialized: function (oEvent) {
			var prevView = this.getOwnerComponent().prevView;
			var oTable = this.getView().byId("tblRetailReview");
			var oRows = oTable.getItems();
			var oRow;
			var oCells;
			var oAchieved;
			var sAchieved;
			var oReasonCode;
			var sReasonCode;
			var oDeliverablesAmended;
			var sDeliverablesAmended;
			if(oRows != null && oRows.length > 0) {
				for(var i = 0;i < oRows.length; i++) {
					oRow = oRows[i];
					oCells = oRow.getCells();
					if(oCells.length > 0 && Array.isArray(oCells)) {
						oAchieved = oCells[5];
						oReasonCode = oCells[6];
						oDeliverablesAmended = oCells[7];
						sAchieved = oAchieved.getValue();
						sReasonCode = oReasonCode.getValue();
						sDeliverablesAmended = oDeliverablesAmended.getValue();
						
						/*
							SAP UI5 might or might not use the same table and change the data instead of destroying the table
							and creating a new one ( which might be a more expensive thing, thus we detach any listeners to ensure
							that we are not responsible for binding multiple event listeners to a control and for keeping controls in memory
							as zombie views when they should be destroyed)
						*/
						
						
						
						if (prevView === "sell" && sAchieved === "No") {
							// attach change listeners to the fields for reason code and deliverables amended
							if (sReasonCode == null || sReasonCode === "") {
								oReasonCode.attachSelectionChange(this.onLockingControlChange, this);
							} else {
								oReasonCode.detachSelectionChange(this.onLockingControlChange, this);
							}
							
							if (sDeliverablesAmended == null || sDeliverablesAmended === "") {
								oDeliverablesAmended.attachSelectionChange(this.onLockingControlChange, this);
							} else {
								oDeliverablesAmended.detachSelectionChange(this.onLockingControlChange, this);
							}
						}
					}
				}
			}
		},

		onBack: function() {
			//	window.history.go(-1);
			// let's add more advanced conditions as situations come up
				this.canProceed = {};
				var oTable = this.getView().byId("tblRetailReview");
				var oRows = oTable.getItems();	
				if(oRows != null && oRows.length > 0) {
					for(var i = 0;i < oRows.length; i++) {
						var oRow = oRows[i];
						var oCells = oRow.getCells();
						if(oCells.length > 0 && Array.isArray(oCells)) {
							oCells[5].setValueState("None");
							oCells[6].setValueState("None");
							oCells[7].setValueState("None");	
						}
					}
				}
				jQuery.sap.delayedCall(100, this, function() {
					this.getOwnerComponent()._onProcessFlowPress(this.getOwnerComponent().prevView);
				});
				sap.ui.core.BusyIndicator.show(10);		
		},
		
		isNotAchieved: function (prevView, achieved) {
			prevView = this.getOwnerComponent().prevView; 
			if(prevView === "sell" && achieved === "No") {
				return true;
			}
			return false;
		},
		
		onAchievedFieldChange: function(oEvent) {
			var oParams = oEvent.getParameters();
			var sValue = oParams.selectedItem.getText();
			var oCells = oEvent.getSource().getParent().getCells();
			var prevView = this.getOwnerComponent().prevView;
			var oReasonCode = oCells[6];
			var oDeliverableAmended = oCells[7];
			var sReasonCode = oReasonCode.getValue();
			var sDeliverableAmended = oDeliverableAmended.getValue();
			var sRowId;
			var oRow;
			var $row =  $('#' + oReasonCode.getId()).closest("tr");
			
			if($row.length > 0) {
				sRowId = $row.prop("id");
				oRow = this.getView().byId(sRowId);
			}
			
			// YES is always unlocking, no matter what state the row is in
		   // it should always clear both fields and 
			if(sValue === "Yes") {
				this.unlockAllRows();
				oReasonCode.setSelectedKey("");
				oDeliverableAmended.setSelectedKey("");
				oReasonCode.setValueState("None");
				oDeliverableAmended.setValueState("None");
				oReasonCode.detachSelectionChange(this.onLockingControlChange, this);
				oDeliverableAmended.detachSelectionChange(this.onLockingControlChange, this);
			}
			
			if(prevView === "plan") {
				if(sValue != null) {
					oEvent.getSource().setValueState("None");
					//do this always, regardless of whether you are in a locked or unlocked state
				   // clear the event only when it is locked 
					if (sValue !== "N/A") {
						oReasonCode.setValueState("None");
						oReasonCode.setSelectedKey("");
						this.unlockAllRows();
						oReasonCode.detachSelectionChange(this.onLockingControlChange, this);
					}
					// if (this.canProceed != null && this.canProceed.locked === true) {
					// 	if(this.canProceed.row && sRowId === this.canProceed.row) {
					// 		if (sValue !== "N/A") {
					// 			oReasonCode.detachSelectionChange(this.onLockingControlChange, this);
					// 		}
					// 	}
					// }
				}				
			}
			
			if(prevView === "sell") {
				if(sValue != null) {
					oEvent.getSource().setValueState("None");
					if(this.canProceed != null && this.canProceed.locked === true) {
						if(this.canProceed.row && sRowId === this.canProceed.row) {
							// if(sValue === "Yes") {
							// 	this.unlockAllRows();
							// 	oReasonCode.setSelectedKey("");
							// 	oDeliverableAmended.setSelectedKey("");
							// 	oReasonCode.setValueState("None");
							// 	oDeliverableAmended.setValueState("None");
							// 	oReasonCode.detachSelectionChange(this.onLockingControlChange, this);
							// 	oDeliverableAmended.detachSelectionChange(this.onLockingControlChange, this);
							// }
							
							if (sValue === "N/A") {
								// UNLOCKED -> LOCKED -> LOCKED, this is the case where we go from Yes -> No (specify Reason Code) -> N/A
								if(sReasonCode !== "" && sReasonCode != null) {
									this.unlockAllRows();	
									oReasonCode.setValueState("None");
									oReasonCode.detachSelectionChange(this.onLockingControlChange, this);
								}
								oDeliverableAmended.setValueState("None");
								oDeliverableAmended.detachSelectionChange(this.onLockingControlChange, this);
							}
							
							// UNLOCKED -> LOCKED -> LOCKED (YES -> N/A -> NO)
							if(sValue === "No") {
								oDeliverableAmended.setEditable(true);
							}
							
							if(sValue === "No" &&  sDeliverableAmended !== "" && sDeliverableAmended != null) {
								oDeliverableAmended.setValueState("None");
								oDeliverableAmended.detachSelectionChange(this.onLockingControlChange, this);
							} 
							
							if(sValue === "No" && sReasonCode != null && sReasonCode !== "") {
								oReasonCode.setValueState("None");
								oReasonCode.detachSelectionChange(this.onLockingControlChange, this);
							}
						}
					}
				} 
			}

			// ideally, this code should not exist, by the time the user reaches the discrepency screen, any achieved N/A has a value
			if(sValue === "N/A" && (sReasonCode === "" || sReasonCode == null)) {
				oReasonCode.setEditable(true);
				oReasonCode.setValueState("Error");
				oReasonCode.setValueStateText("");
				this.canProceed = {
					row: sRowId,
					message: "Reason code must be provided when Achieved is N/A",
					fields: [
						oReasonCode.getId()	
					]
				};
				sap.m.MessageToast.show(this.canProceed.message);
				this.lockUnansweredRows(sRowId);
				oReasonCode.attachSelectionChange(this.onLockingControlChange, this);
			}
			
			if(prevView === "sell" && sValue === "No" && (sDeliverableAmended === "" || sDeliverableAmended == null || sReasonCode === "" || sReasonCode == null)) {
				
				/*
					When checking for discrepency
					
					Locked -> Locked
					Unlocked -> Locked (due to lack of previous validation or when initially entering the screen)
					
					it could be
					
					|Reason Code|Deliverable Amended|Action|
					|:---------:|:-----------------:|:-----:|
					|BAD|BAD|Highlight both fields and set listeners on both|
					|GOOD|BAD|Dehighlight Reason code if already highlighted(bad data in Siebel Unlocked -> Locked -> Locked), and highlight the Deliverables Amended and set listener|
					|BAD|GOOD|Highlight Reason code and set listener on it, dehighlight Deliverable Amended if already highlighted (Unlocked -> Locked -> Loccked)|
				*/
				
				
				// there are two fields here, if one field is locked and the other is unlocked, it is still an error
			   //  but only that one field should be given the scorn and the criticism it deserves, the other field should
			  //   not be tainted by association
			  
			  // however, if they are partners in crime, both of them must be judged with an equal amount of harshness
			  if( (sDeliverableAmended === "" || sDeliverableAmended == null) && (sReasonCode === "" || sReasonCode == null)) {
			  	oReasonCode.setValueState("Error");
				oDeliverableAmended.setValueState("Error");
				this.canProceed = {
					row: sRowId,
					message: 'Reason code and Deliverable Amended cannot be empty when Achieved is No and a Discrepency has been created',
					fields: [
						oReasonCode.getId(),
						oDeliverableAmended.getId()
					]
				};
				oReasonCode.attachSelectionChange(this.onLockingControlChange, this);
				oDeliverableAmended.attachSelectionChange(this.onLockingControlChange, this);
			  } else if(sDeliverableAmended === "" || sDeliverableAmended == null) {
			  	oDeliverableAmended.setValueState("Error");
			  	this.canProceed = {
					row: sRowId,
					message: 'Deliverable Amended cannot be empty when Achieved is No and a Discrepency has been created',
					fields: [
						oDeliverableAmended.getId()
					]
				};
				oDeliverableAmended.attachSelectionChange(this.onLockingControlChange, this);
				// caution should be exercised to ensure that the other one's is in the clear if it has not already been done (Unlocked -> Locked with 1 value)
				//REASON CODE is GOOD
				oReasonCode.setValueState("None");
				oReasonCode.detachSelectionChange(this.onLockingControlChange, this);
			  } else if(sReasonCode === "" || sReasonCode == null) {
			  	//REASON CODE IS THE ROTTEN EGG
			  	oReasonCode.setValueState("Error");
			  	oReasonCode.attachSelectionChange(this.onLockingControlChange, this);
			  	this.canProceed = {
					row: sRowId,
					message: 'Reason code cannot be empty when Achieved is No and a Discrepency has been created',
					fields: [
						oReasonCode.getId()
					]
				};
				// remove any taint from either a past association or incorrect assumption (Unlocked -> Locked with 1 value)
				oDeliverableAmended.setValueState("None");
				oDeliverableAmended.detachSelectionChange(this.onLockingControlChange, this);
			  } else {
			  	oDeliverableAmended.setValueState("None");
				oDeliverableAmended.detachSelectionChange(this.onLockingControlChange, this);
				oReasonCode.setValueState("None");
				oReasonCode.detachSelectionChange(this.onLockingControlChange, this);
			  }
			
				// the message can only be displayed now
				sap.m.MessageToast.show(this.canProceed.message);
				this.lockUnansweredRows(sRowId);
			}
			
		},
		
		lockUnansweredRows: function (sRowId) {
			// this function cannot be generalised
			var oTable = this.getView().byId("tblRetailReview");
			var oItems = oTable.getItems();
			var oRow;
			var sId;
			var oCells;
			for(var i=0; i< oItems.length; i++) {
				oRow = oItems[i];
				sId = oRow.getId();
				if (sId !== sRowId) {
					oCells = oRow.getCells();
					oCells[5].setEditable(false);
					oCells[6].setEditable(false);
					oCells[7].setEditable(false);
					oCells[8].setEditable(false);
				}
			}
			if (this.canProceed != null) {
				this.canProceed.locked = true;
			}
		},
		
		onLockingControlChange: function (oEvent) {
			debugger;
			var oParams = oEvent.getParameters();
			var oControl = oEvent.getSource();
			var sId = oControl.getId();
			var $row = $('#' + sId).closest("tr");
			var sRowId;
			if($row.length > 0) {
				sRowId = $row.prop("id");
			}    
			
			var oCells = oControl.getParent();
			var prevView = this.getOwnerComponent().prevView;
			
			if (oCells.getCells && !Array.isArray(oCells)) {
				oCells = oCells.getCells();	
			}
			
			
			if(oCells.length > 0) {
				var sAchieved = oCells[5].getValue();
				if (prevView === "sell" && sAchieved === "No" ) {
					var sReasonCode = oCells[6].getValue();
					var sDeliverableAmended = oCells[7].getValue();
					if(sReasonCode !== "" && sReasonCode != null && sDeliverableAmended !== "" && sDeliverableAmended != null) {
						this.unlockAllRows();
						oCells[6].setValueState("None");
						oCells[7].setValueState("None");
						oCells[6].detachSelectionChange(this.onLockingControlChange, this);
						oCells[7].detachSelectionChange(this.onLockingControlChange, this);
					} else if(sDeliverableAmended != null && sDeliverableAmended !== "") {
						oCells[7].setValueState("None");
						/*
							When the table is initially mounted and a field already has a value of `NO`, this function becomes the first line
							of defence against preventing the user from moving on without specifying an appropriate value for the fields.
							
							In this case canProceed has not been defined yet and has to be defined now.
							
							It also means that highlighting and displaying the error message has not happened yet and it has to happen now
							because achievedFieldChange was not called yet.
						*/
						var showPopup = false;
						if(this.canProceed == null) {
							this.canProceed = {
								row: sRowId,
								fields: [
									oCells[6].getId()
								]
							};							
						
							oCells[6].setValueState("Error");
							showPopup = true;
						}

						this.canProceed.message = "Reason code cannot be empty when Achieved is No and a Discrepency has been created";
						if(showPopup) {
							sap.m.MessageToast.show(this.canProceed.message);
							showPopup = false;
						}
						oCells[7].detachSelectionChange(this.onLockingControlChange, this);
					} else {
						oCells[6].setValueState("None");
						
						
						if(this.canProceed == null) {
							this.canProceed = {
								row: sRowId,
								fields: [
									oCells[7].getId()
								]
							};
							
							oCells[7].setValueState("Error");
							showPopup = true;
						}
						this.canProceed.message = "Deliverable Amended cannot be empty when Achieved is No and a Discrepency has been created";
						if(showPopup) {
							sap.m.MessageToast.show(this.canProceed.message);
							/* this variable is scoped to the function, better reset it*/
							showPopup = false;
						}
						oCells[6].detachSelectionChange(this.onLockingControlChange, this);
					}
				} else if(sAchieved === "N/A") {
					if (oParams.value) {
						if (oParams.value != null && oParams.value != "") {
							this.unlockAllRows();
							oControl.detachSelectionChange(this.onLockingControlChange, this);
						}
					} else if (oParams.selectedItem) {
						if(oParams.selectedItem.getText() != null && oParams.selectedItem.getText() != "") {
							this.unlockAllRows();
							oControl.detachSelectionChange(this.onLockingControlChange, this);
						}	
					}
				}
			}
		},
		
		unlockAllRows: function () {
			var oTable = this.getView().byId("tblRetailReview");
			var oItems = oTable.getItems();
			var oRow;
			var sAchieved;
			var oCells;
			var prevView = this.getOwnerComponent().prevView;
			for(var i=0; i< oItems.length; i++) {
				oRow = oItems[i];
				oCells = oRow.getCells();
				if(prevView === "plan") {
					oCells[5].setEditable(true);	
				}
				sAchieved = oCells[5].getValue();
				if(sAchieved === "N/A") {
					oCells[6].setEditable(true);	
				} else if(sAchieved === "No" && prevView === "sell") {
					oCells[6].setEditable(true);
					oCells[7].setEditable(true);
				}
				oCells[8].setEditable(true);
			}
			if (this.canProceed != null) {
				this.canProceed.locked = false;
			}
		},
		
		isNotAchievedReasonCode: function(achieved) {
			var prevView = this.getOwnerComponent().prevView;
			
			if(prevView === "plan" && achieved === "N/A") {
				return true;
			}
			
			if(prevView === "sell" && achieved === "No") {
				return true;
			}
			return false;
		},
		
		onReasonCodeChanged: function(oEvent) {
			var sValue = oEvent.getParameters().value;
			var oReasonCode = oEvent.getSource();
			var cells = oEvent.getSource().getParent().getCells();
			var oAchieved = cells[5];
			var sAchieved = oAchieved.getSelectedKey();
			var prevView = this.getOwnerComponent().prevView;
			
			if(sAchieved === "N/A" && prevView === "plan") {
				if(sValue !== "") {
					oReasonCode.setValueState("None");
				}
			}
		},
		
		
		achievedFormatter: function(prevView) {
			prevView = this.getOwnerComponent().prevView;
			if(prevView === "sell") {
				return false;
			}
			return true;
		},

		onSave: function() {
			// TO DO
			var that = this;
			if (this.canProceed != null && this.canProceed.locked === true) {
				sap.m.MessageToast.show(this.canProceed.message);
			} else {
				var customer = this.getOwnerComponent()._getCustomer();
				var oOutlet = this.getOwnerComponent()._getOutlet();
				
				var isAchievedFieldBlank = false;
				var accountId = customer.getAccountId();
				var callId = customer.getActivityId();
	
				// var accountId = "1-2N361U";
				// var callId = "1-4BETNAW"; 
	
				var retailAccountId = this.byId("retailaccountid").getText();
	
				var retailAssessId = this.byId("retailassessid").getText();
	
				// Create update payload
	
				var items = [];
				var prevView = this.getOwnerComponent().prevView;
				var mandatoryFieldMissing = true;
				var reasonCodeMissing = false;
				
				// Get update values from table
				var table = this.byId("tblRetailReview");
				var cells = table.getItems();
				for (var i = 0; i < cells.length; i++) {
					var cell = cells[i].getCells();
					var achieved = cell[5].getValue();
					var reasonCode = cell[6].getValue();
					var delAmended = cell[7].getValue();
					
					if(prevView === "plan") {
						if(achieved === "N/A" && reasonCode === "") {
							reasonCodeMissing = true;
							cell[6].setValueState("Error");
							cell[6].setValueStateText("");
						} else {
							if(achieved === "") {
								isAchievedFieldBlank = true;
								cell[5].setValueState("Error");
								cell[5].setValueStateText("");
							}
							
							reasonCodeMissing = false;
							cell[6].setValueState("None");
						}	
					}
					
					if(prevView === "sell") {
						if(achieved === "No" && (delAmended === "" || reasonCode === "")) {
							cell[6].setValueState("Error");
							cell[6].setValueStateText("");
							cell[7].setValueState("Error"); 
							cell[7].setValueStateText("");
						} else {
							cell[6].setValueState("None");
							cell[7].setValueState("None"); 
						}		
					}
					
					items.push({
						"id": cell[0].getText(),
						"achieved": cell[5].getValue(),
						"comment": cell[8].getValue(),
						"reasonCode": cell[6].getValue(),
						"deliverablesAmended": cell[7].getValue()
					});
				}
				
				var notAchieved = items.filter(function(item){
					return item.achieved === "No";
				});
				
				var reasonCodeOrAmendedMissing = items.filter(function(item){
					return (
						( prevView === "sell" && item.achieved === "No" ) && (
							item.reasonCode == null || item.deliverablesAmended == null || 
							item.reasonCode == "" || item.deliverablesAmended == ""
						)		
					);
				});
				
				mandatoryFieldMissing = reasonCodeOrAmendedMissing.length > 0;
	
				var hasNotAchieved = notAchieved.length > 0;
				
				if(hasNotAchieved && prevView === "plan") {
					sap.m.MessageToast.show("A Discrepency will be created");
				}
				if(mandatoryFieldMissing && prevView==="sell") {
					sap.m.MessageToast.show("Deliverables Amended and Reason Code cannot be empty for a discrepency");
				} else if(reasonCodeMissing && prevView === "plan") {
					sap.m.MessageToast.show("Reason Code cannot be empty for Achieved N/A");
				} else if(isAchievedFieldBlank && prevView === "plan") {
					sap.m.MessageToast.show("Achieved fields cannot be empty");
				} else {
					jQuery.sap.delayedCall(100, this, function() {
						// Save values.
						that.getOwnerComponent()._setRetailReviewData(that, retailAccountId, retailAssessId, items, oOutlet.getActivityId());
					});
					sap.ui.core.BusyIndicator.show(10);	
				}	
			}
		}
	});
});