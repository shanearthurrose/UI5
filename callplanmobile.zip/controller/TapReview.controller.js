sap.ui.define(["sap/ui/core/mvc/Controller"], function(Controller) {
	"use strict";
	return Controller.extend("callplanning.controller.TapReview", {

		onInit: function() {
			// TO DO
			var oRouter = this.getOwnerComponent().getRouter();
			/*
			Attach a listener to the view, so fm: _selectItemWithId will be called everytime this view is triggered via Route
			*/

			oRouter.attachRouteMatched(function(oEvent) {
				if (oEvent.getParameter("name") !== "tapreview") {
					return;
				}
				this._selectItemWithId(oEvent.getParameter("arguments"));
			}, this);
		},
		onAfterRendering: function() {

		},

		_selectItemWithId: function(arg) {
			var oCustomer = this.getOwnerComponent()._getCustomer();
			var oOutlet = this.getOwnerComponent()._getOutlet();

			var accountId = oCustomer.getAccountId();

			// styling

			//

			//implementation
			var callId = oCustomer.getActivityId();
//			var outlet = this.getOwnerComponent().getModel(callId);
//			var assessId = outlet.marketintelid;
			this.getOwnerComponent()._getTapReviewData(this.byId("pnlTapCounter"), accountId, callId);
			//	this.getOwnerComponent()._getTapData(this.byId("pnlTapCounter"), accountId);

			sap.ui.core.BusyIndicator.hide();
		},
		onBack: function() {
			//	window.history.go(-1);
			//	alert(this.getOwnerComponent().prevView);
			jQuery.sap.delayedCall(100, this, function() {
				this.getOwnerComponent()._onProcessFlowPress(this.getOwnerComponent().prevView);
			});
			sap.ui.core.BusyIndicator.show(10);

		},

		handleLoadItems: function(oControlEvent) {
			//	alert(oControlEvent);
			oControlEvent.getSource().getBinding("items").resume();
		},
		onTapHelpRequest: function(ev) {
			//	alert(ev.getSource());

			if (!this.getOwnerComponent().oTapHelpDialog) {
				// create dialog via fragment factory
				this.getOwnerComponent().oTapHelpDialog = sap.ui.xmlfragment("callplanning.view.TapHelp", this.getOwnerComponent());
				this.getOwnerComponent().oTapHelpDialog.setModel(this.getOwnerComponent().getModel("tap"), "tap");
			}

			this.getOwnerComponent().oTapHelpDialog.setModel(this.getOwnerComponent().getModel("tap"), "tap");
			//		this.oAccountHelpDialog.getBinding("items").filter([]);

			this.getOwnerComponent().tap = ev.getSource();
			this.getOwnerComponent().oTapHelpDialog.open();
		},
		onShowDetails: function() {
			jQuery.sap.delayedCall(100, this, function() {
				this.getOwnerComponent().getRouter().navTo("tapreviewdetails");
			});
			sap.ui.core.BusyIndicator.show(10);

		},
		tapLoaded: function(ev) {

			var items = ev.getSource().getItems();
			for (var i = 0; i < items.length; i++) {
				var cells = items[i].getCells();
				cells[6].setTooltip(cells[6].getValue());
				cells[7].setTooltip(cells[7].getValue());
				cells[8].setTooltip(cells[8].getValue());
				cells[9].setTooltip(cells[9].getValue());
				cells[10].setTooltip(cells[10].getValue());
				cells[11].setTooltip(cells[11].getValue());
				cells[12].setTooltip(cells[12].getValue());
				cells[13].setTooltip(cells[13].getValue());
				cells[14].setTooltip(cells[14].getValue());
				cells[15].setTooltip(cells[15].getValue());
				cells[16].setTooltip(cells[16].getValue());
				cells[17].setTooltip(cells[17].getValue());
				cells[18].setTooltip(cells[18].getValue());
				cells[19].setTooltip(cells[19].getValue());
				cells[20].setTooltip(cells[20].getValue());
				cells[21].setTooltip(cells[21].getValue());
				cells[22].setTooltip(cells[22].getValue());
				cells[23].setTooltip(cells[23].getValue());
				cells[24].setTooltip(cells[24].getValue());
				cells[25].setTooltip(cells[25].getValue());
			}

		},
		checked: function(value) {
			//			alert(value);
			if (value === "Y" || value === "y") {
				return true;
			} else {
				return false;
			}

		},

		onSave: function() {
			this.saveTap(true);

		},

		onUpdate: function() {
			//	alert("Update Tap Counter.");
			this.saveTap(false);
			/** TO DO
			 * Navigate to Outlet Check.
			 */
		},

		saveTap: function(navigate) {
			// TO DO
			var customer = this.getOwnerComponent()._getCustomer();
			var oOutlet = this.getOwnerComponent()._getOutlet();

			var accountId = customer.getAccountId();
			var callId = customer.getActivityId();
			//var outlet = this.getOwnerComponent().getModel(callId);

			//var tapAccountId = this.byId("tapaccountid").getText();

			//var tapAssessId = this.byId("tapassessid").getText();

			// Create update payload
			var items = [];
			var glassware = {};

			var glassTable = this.byId("tblBrandedGlassware");
			var glassCells = glassTable.getItems();
			var glassCell = glassCells[0].getCells();

			glassware.glassware1 = glassCell[0].getValue();
			glassware.glassware2 = glassCell[1].getValue();
			glassware.glassware3 = glassCell[2].getValue();
			glassware.glassware4 = glassCell[3].getValue();
			glassware.glassware5 = glassCell[4].getValue();
			glassware.glassware6 = glassCell[5].getValue();

			// Get update values from table

			var table = this.byId("tblTapCounter");
			var cells = table.getItems();

			for (var i = 0; i < cells.length; i++) {
				var cell = cells[i].getCells();
				var mainBar = "N";
				/*
					alert(cell[0].getText());
					alert(cell[1].getValue());
					alert(cell[2].getValue());
					alert(cell[3].getValue());
					alert(cell[4].getValue());
					alert(cell[5].getValue());
					alert(cell[6].getSelectedItem().getKey());
				*/
				if (cell[3].getSelected()) {
					mainBar = "Y";
				}

				items.push({
					"id": cell[0].getText(),
					"barName": cell[1].getValue(),
					"barType": cell[2].getValue(),
					"mainBar": mainBar,
					"bankFont": cell[4].getValue(),
					"tapDecal": cell[5].getValue(),

					"tap1": cell[6].getValue(),
					"tap2": cell[7].getValue(),
					"tap3": cell[8].getValue(),
					"tap4": cell[9].getValue(),
					"tap5": cell[10].getValue(),
					"tap6": cell[11].getValue(),
					"tap7": cell[12].getValue(),
					"tap8": cell[13].getValue(),
					"tap9": cell[14].getValue(),
					"tap10": cell[15].getValue(),
					"tap11": cell[16].getValue(),
					"tap12": cell[17].getValue(),
					"tap13": cell[18].getValue(),
					"tap14": cell[19].getValue(),
					"tap15": cell[20].getValue(),
					"tap16": cell[21].getValue(),
					"tap17": cell[22].getValue(),
					"tap18": cell[23].getValue(),
					"tap19": cell[24].getValue(),
					"tap20": cell[25].getValue()

				});
			}

			jQuery.sap.delayedCall(100, this, function() {

				this.getOwnerComponent()._setTapReviewData(this, accountId, items, glassware, oOutlet.getActivityId(), navigate);

			});
			sap.ui.core.BusyIndicator.show(10);
		},

		onAddTap: function(ev) {
			var customData = ev.getSource().getCustomData();

			if (!this.getOwnerComponent().oAddTap) {
				this.getOwnerComponent().oAddTap = sap.ui.xmlfragment("callplanning.view.addTap", this.getOwnerComponent()); //	this.oContactDialog.setModel(this.getOwnerComponent().getModel("sellins"), "sellins");
			}

			jQuery.sap.delayedCall(100, this, function() {
				this.getOwnerComponent().oAddTap.setModel(this.getOwnerComponent().getModel("tap"), "tap");
				this.getOwnerComponent().oAddTap.setModel(this.getOwnerComponent().getModel("BARTYPE"), "BARTYPE");
				this.getOwnerComponent().oAddTap.setModel(this.getOwnerComponent().getModel("TAPBANK"), "TAPBANK");
				this.getOwnerComponent().oAddTap.setModel(this.getOwnerComponent().getModel("TAPDECAL"), "TAPDECAL");
				sap.ui.core.BusyIndicator.hide();
			});
			sap.ui.core.BusyIndicator.show(10);
			this.getOwnerComponent().oAddTap.open();
		},

		onDelete: function(ev) {
			jQuery.sap.require("sap.m.MessageBox");
			//var item = oEvent.getSource().getParent();
			var that = this;
			var customData = ev.getSource().getCustomData();
			var customer = this.getOwnerComponent()._getCustomer();
			var items = [];
			var glassware = {};

			sap.m.MessageBox.confirm(
				"Confirm Deletion of Tap?", {
					onClose: function(oAction) {
						//	alert(oAction);
						if (oAction !== "CANCEL") {
							jQuery.sap.delayedCall(100, this, function() {
								that.getOwnerComponent()._deleteTapReviewData(customData[0].getValue());
								that.getOwnerComponent()._getTapReviewData(null, customer.getAccountId(), customer.getActivityId());
							});
							sap.ui.core.BusyIndicator.show(10);
						} else {
							//
						}
					}
				}
			);
			//         var path = oEvent.getSource().getParent().getBindingContext("TapReview").getPath();
			//        this.getOwnerComponent()._deleteTapCounter(this, path);
		},

		onGoToAgreement: function(ev) {
			//			alert("go to agreement" + this.byId("txtAgreementName").getValue());
			if (this.byId("txtAgreementName").getValue() !== "") {
				this.getOwnerComponent()._getAgreementPDF(this.byId("txtAgreementNo").getText(), this.byId("txtAgreementName").getValue());
			} else {
				this.getOwnerComponent()._showError("No agreement Exists");
			}
		},

		statusClass: function(ev) {
			//						alert("complete");
			this.removeAllStatusClass("txtPartnershipCommitments");
			this.byId("txtPartnershipCommitments").addStyleClass(this.byId("txtPartnershipCommitments").getText().split(' ').join('-'));

			this.removeAllStatusClass("txtVolumePerformance");
			this.byId("txtVolumePerformance").addStyleClass(this.byId("txtVolumePerformance").getText().split(' ').join('-'));

			this.tapLoaded(ev);
			//			return "status statusAchieving";
		},

		removeAllStatusClass: function(field) {
			this.byId(field).removeStyleClass("NON-ACHIEVING");
			this.byId(field).removeStyleClass("NO-TARGET");
			this.byId(field).removeStyleClass("ON-TARGET");
			this.byId(field).removeStyleClass("AT-RISK");
			this.byId(field).removeStyleClass("BELOW-TARGET");
			this.byId(field).removeStyleClass("ACHIEVING");
			this.byId(field).removeStyleClass("ABOVE-TARGET");
		},

		onTapBrandNotAvailable: function() {
			this.getOwnerComponent()._showText("",
				"If the tap brand you're looking for is not available and there's no generic brand that covers your needs please send an email to prcontracts@lionco.com and provide the following information:1) Full Tap Brand Name2) Supplier Name3) Tap SegmentPourage Rights will endeavour to have the tap brand available within 7 days.(SBL-EXL-00151)"
			);
		},

		formatDate: function(val) {

			return this.getOwnerComponent().formatDate(val);
			//			var date = new Date(val);
			//			return date.toLocaleString("en-us", {
			//				month: "short"
			//			}) + " " + date.getDate() + "," + date.getFullYear();
		},
		roundValue: function(value) {
			var calc = parseFloat(value);
			if (isNaN(calc)) {
				return "";
			}

			return parseFloat(value).toFixed(0) + "%";

		}
	});
});