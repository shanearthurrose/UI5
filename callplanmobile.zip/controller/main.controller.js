sap.ui.define(["sap/ui/core/mvc/Controller"], function(Controller) {
	"use strict";
	return Controller.extend("callplanning.controller.main", {
		onInit: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var oRouter = this.getOwnerComponent().getRouter();
			oRouter.attachRouteMatched(function(oEvent) {
				if (oEvent.getParameter("name") !== "main") {
					return;
				}
				this._selectItemWithId(oEvent.getParameter("arguments"));
			}, this);
		},

		_selectItemWithId: function(arg) {
		//	this.getOwnerComponent()._getSalesDrive(this);			
			this.getOwnerComponent()._setTitles(this, null);
			sap.ui.core.BusyIndicator.hide();
		},
		onBeforeRendering: function() {
		//	this.getOwnerComponent()._setTitles(this, null);

		},
		onAfterRendering: function() {
			sap.ui.core.BusyIndicator.hide();
		},
		onPrevious: function() {

			jQuery.sap.delayedCall(100, this, function() {
				this.getOwnerComponent()._setTitles(this, "-");
				this._setDragDrop();
			//	sap.ui.core.BusyIndicator.hide();
			});
			//sap.ui.core.BusyIndicator.show(10);
			//sap.ui.commons.MessageBox.alert("Date:" + this.getOwnerComponent().getModel("CURRENTDATE"));
		},
		/**
		 *@memberOf infield.controller.main
		 */
		onNext: function() {
			jQuery.sap.delayedCall(100, this, function() {
				this.getOwnerComponent()._setTitles(this, "+");
			//	sap.ui.core.BusyIndicator.hide();
			});
		//	sap.ui.core.BusyIndicator.show(10);

		},
		/*
		  Add call button pressed
		
		*/
		_addCall: function() {
			// create dialog lazily
			if (!this.oAddCallDialog) {
				// create dialog via fragment factory
				this.oAddCallDialog = sap.ui.xmlfragment("callplanning.view.addCall", this.getView().getController());
				sap.ui.getCore().byId("planneddate").setValue((new Date()).toISOString().slice(0, 10));
			} else {
				sap.ui.getCore().byId("planneddate").setValue((new Date()).toISOString().slice(0, 10));
				sap.ui.getCore().byId("addcallaccountnumber").setValue();
				sap.ui.getCore().byId("addcallaccountname").setValue();
			}
			this.oAddCallDialog.open();

		},
		_callRescheduled: function(activityId, date) {

			//	sap.m.MessageToast.show("call Rescheduled:" + activityId + ":" + date )

			this.getOwnerComponent()._setReschedule(activityId, date);
			//this.getModel("error").getProperty("/reasons")			

			//	sap.m.MessageToast.show("call Rescheduled:");			

		},
		/*
		  when a user selects an activate item
		
		
		*/
		onActivateItemPress: function(oEvent) {
			// returns the data object accounts	
			//	alert("here"+oEvent.getSource().getId());
			var accounts = oEvent.getSource().data("accounts").split(",");
			var customData = oEvent.getSource().getCustomData();
			//--->alert(customData[3].getValue());
			var startDate = new Date(customData[2].getValue());			
			var endDate = new Date(customData[3].getValue());
			//oEvent.getSource().data("goal")
			//alert( accounts[0] );
			$(".sellins").removeClass("activationSelected");
			$(".activationEntry").removeClass("activationSelected");
			$(".visitTile").removeClass("activationSelected");
			$("#" + oEvent.getSource().getId()).addClass("activationSelected");

			//oEvent.getSource().removeStyleClass("activationSelected");
			//oEvent.getSource().addStyleClass("activationSelected");			

			for (var i = 0; i < accounts.length; i++) {
				$(".visitTile").each(function(index) {
					var accountData = $(this).data("accountid");
					var callDate = new Date($(this).data("calldate"));
					//					$(this).removeClass("activationSelected");

					if (accountData.indexOf(accounts[i]) > -1 &&
						startDate < callDate && endDate > callDate ) {
						//	if (oEvent.getSource().getPriority() === "High") {
						$(this).addClass("activationSelected");
					}
				});
			}
			//			if (oEvent.getSource().getPriority() === "High") {
			//				oEvent.getSource().setPriority("Low");

			//			} else {
			//				oEvent.getSource().setPriority("High");
			//				oEvent.getSource().removeStyleClass("activationSelected");				
			//			}
		},
		
		onSellinItemPress: function(oEvent) {
			// returns the data object accounts	
			//	alert("here"+oEvent.getSource().getId());
			var accounts = oEvent.getSource().data("accounts").split(",");
			var customData = oEvent.getSource().getCustomData();
			//--->alert(customData[3].getValue());
			//oEvent.getSource().data("goal")
			//alert( accounts[0] );
			$(".sellins").removeClass("activationSelected");
			$(".activationEntry").removeClass("activationSelected");
			$(".visitTile").removeClass("activationSelected");
			$("#" + oEvent.getSource().getId()).addClass("activationSelected");

			//oEvent.getSource().removeStyleClass("activationSelected");
			//oEvent.getSource().addStyleClass("activationSelected");			

			for (var i = 0; i < accounts.length; i++) {
				$(".visitTile").each(function(index) {
					var accountData = $(this).data("accountid");
					var callDate = new Date($(this).data("calldate"));
					//					$(this).removeClass("activationSelected");

					if (accountData.indexOf(accounts[i]) > -1 ) {
						//	if (oEvent.getSource().getPriority() === "High") {
						$(this).addClass("activationSelected");
					}
				});
			}
			//			if (oEvent.getSource().getPriority() === "High") {
			//				oEvent.getSource().setPriority("Low");

			//			} else {
			//				oEvent.getSource().setPriority("High");
			//				oEvent.getSource().removeStyleClass("activationSelected");				
			//			}
		},		
		_setDragDrop: function(ev) {

			var that = this;
			var today = new Date();
			//var currentDate = new Date();
			$(document).ready(function() {
				$(".day ul").addClass("ui-sortable");
				$(".day ul").sortable({
					revert: "valid",
					connectWith: ".day ul",
					items: "li.dayList",
					receive: function(event, ui) {
						// TODO: cancel reschedule in the past (not possible - coded with message)	
						var headingDate = $(ui.item).closest(".day").data("date").split("/");
						var currentDate = new Date(headingDate[2], headingDate[1], headingDate[0], 23, 59, 59);
						//		alert(currentDate + "/" + today);
						if (currentDate < today) {
							sap.m.MessageToast.show("Cannot Rescheduled in the past");
							ui.sender.sortable("cancel");
						} else {
							//	$(ui.item).find("#reschedule").addClass("reschedule");
							//var accountData = $(this).data("accountid");

							that._callRescheduled($(ui.item).find(".visitTile").data("activityid"), currentDate);

							//	alert("xxx..:"+that.getOwnerComponent().getModel("error").getProperty("/reasons"));

							if (that.getOwnerComponent().getModel("error").getProperty("/reasons") !== "") {
								//			alert("error:");																
								that.getOwnerComponent()._showError(that.getOwnerComponent().getModel("error").getProperty("/reasons"));
								ui.sender.sortable("cancel");
							} else {
								//	alert("call Rescheduled:");								
								$(ui.item).find("#reschedule").addClass("reschedule");
							}
						}
					},
					start: function(event, ui) {
						//	alert( $(ui.item).html());
					}
				});
			});
		},
		/*
		// TODO: when a user selects an account, go into detail (next page)   
		
		*/
		_onCallSelect: function(ev) {
			//>>// TODO: 		alert("Customer selected:" + ev.getSource().getAccountId());
			//this.getOwnerComponent()._setCustomer(ev.getSource().getAccountId());
			//this.getOwnerComponent()._setCustomer(ev.getSource().getAccountName());
			//	alert(ev.getSource().nextCall());

			return;

			var that = this;
			var source = ev.getSource();
			var accountId = ev.getSource().getAccountId();
			var activityId = ev.getSource().getActivityId();
			this.getOwnerComponent()._setCustomer(source);
			this.getOwnerComponent().finish = false;
			//		alert(activityId);

			//	sap.ui.core.BusyIndicator.show(100);

			jQuery.sap.delayedCall(100, this, function() {

				//that.getOwnerComponent()._setCustomer(ev.getSource());
				//				that.getOwnerComponent()._setCustomer(source);

				//	that.getOwnerComponent()._getKamNotes(that,ev.getSource().getAccountId());
				//				that.getOwnerComponent()._getKamNotes(that, accountId);

				//				that.getOwnerComponent()._getOPCNotes(that, accountId);
				//				that.getOwnerComponent()._getNotes(that, accountId);

				//				that.getOwnerComponent()._getAccountContacts(that, accountId);
				//				that.getOwnerComponent()._getAccountTeam(that, accountId);

				//				that.getOwnerComponent()._getAgendaItems(that, activityId);

				//				that.getOwnerComponent()._getOutletCheck(that, activityId);
				/*
				  pass: startDate
						endDate
						owner
						accountId
				*/
				var start = new Date(that.getOwnerComponent().getModel("salesdrive").getProperty("/StartDate"));
				var end = new Date(that.getOwnerComponent().getModel("salesdrive").getProperty("/StartDate"));

				start.setDate(start.getDate() - 60);
				end.setDate(end.getDate() - 1);
				//startDate = "2016-10-31";
				var startDate = start.getFullYear() + "-" + (start.getMonth() + 1) + "-" + start.getDate();
				var endDate = end.getFullYear() + "-" + (end.getMonth() + 1) + "-" + end.getDate();

				that.getOwnerComponent()._getAccountSellins(null,
					startDate,
					endDate,
					that.getOwnerComponent().userid,
					accountId,
					"accountsellinsprev");
				//				that.getOwnerComponent()._getAccountActivations(that.getOwnerComponent().getModel("salesdrive").getProperty("/StartDate"),
				//					that.getOwnerComponent().getModel("salesdrive").getProperty("/EndDate"),
				//					that.getOwnerComponent().userid,
				//					accountId);

				//				that.getOwnerComponent()._getAccountSellins(that.getOwnerComponent().getModel("salesdrive").getProperty("/StartDate"),
				//					that.getOwnerComponent().getModel("salesdrive").getProperty("/EndDate"),
				//					that.getOwnerComponent().userid,
				//					accountId);
				//this.getOwnerComponent()._getKamNotes(this,"1-2N00GZ");
				//				sap.ui.core.BusyIndicator.hide();

				that.getOwnerComponent().getRouter().navTo("plan", {
					id: accountId
				}, false);

			});
			sap.ui.core.BusyIndicator.show(10);

		},
		/**
		 *@memberOf callplanning.controller.main
		 */
		onLionWayTap: function() {
			//This code was generated by the layout editor.
			this.getOwnerComponent()._redirect("lionway");
		},

		/**
		 *@memberOf callplanning.controller.main
		 */
		onStructuredCallTap: function() {
			//This code was generated by the layout editor.
			this.getOwnerComponent()._redirect("structuredcall");
		},

		onRepToolKit: function() {
			//This code was generated by the layout editor.
			this.getOwnerComponent()._redirect("toolkit");
		},

		_onSellinSelect: function() {
			//alert("here");
			if (!this.oSellinDialog) {
				this.oSellinDialog = sap.ui.xmlfragment("callplanning.view.SalesDriveSellinStatus", this);
				this.oSellinDialog.setModel(this.getOwnerComponent().getModel("sellins"), "sellins");
			}
			this.oSellinDialog.setModel(this.getOwnerComponent().getModel("sellins"), "sellins");
			this.oSellinDialog.open();
		},

		_onActivateSelect: function() {
			if (!this.oActivateDialog) {
				this.oActivateDialog = sap.ui.xmlfragment("callplanning.view.SalesDriveActivateStatus", this);
				this.oActivateDialog.setModel(this.getOwnerComponent().getModel("activations"), "activations");
			}
			this.oActivateDialog.setModel(this.getOwnerComponent().getModel("activations"), "activations");
			this.oActivateDialog.open();
		},

		_brandImage: function(promoName) {
			var fiveSeeds = ["5 Seeds Bright", "5 Seeds Cloudy", "5 Seeds Crisp", "5 Seeds Pear", "5 Seeds Pre Cut", "5 Seeds NOCB",
				"5 Seeds NOCA"
			];
			var btbt = ["BTBT"];
			var emuBitter = ["Emu Bitter"];
			var guinness = ["Guinness"];
			var hahn = ["HSD", "HSD 3.5", "Hahn Ultra", "Hahn Radler", "HPL", "HAHN"];
			var heineken = ["Heineken", "Heineken 3"];
			var kosciuszko = ["Kosciuszko"];
			var jb = ["JB Draught", "JB Premium", "JB Premium Light"];
			var js = ["JS Lashes", "JS Cooper Ale", "JS Pilsener", "JS American PA", "JS Porter", "JS Amber Ale", "JS India PA",
				"JS Summer Ale", "JS Swindler", "JS Golden Ale", "james squire"
			];
			var jsCider = ["JS OC Apple", "JS OC Pear"];
			var kirin = ["Kirin", "Kirin Apple", "Kirin Apple & Pear "];
			var lc = ["LC Bright Ale", "LC Dog Days", "LC Inida PA", "LC Pale Ale", "LC Plisner", "LC Rogers"];
			var roam = ["Roam"];
			var swan = ["Swan"];
			var tooheys = ["Tooheys New", "Tooheys Old"];
			var ted = ["TED"];
			var wed = ["WED"];
			var wr = ["WR Pale Ale", "WR Dark Ale", "WR White Ale"];
			var xxxx = ["4XG", "4X APA", "XXXX"];
			var xxxxSummer = ["4XSBL", "4XSBL Lime", "4XSBL Mango", "XSBL"];

			//

			if (this.findStr(promoName, fiveSeeds)) {
				return "./images/5seeds.png";
			} else if (this.findStr(promoName, btbt)) {
				return "./images/btbt.png";
			} else if (this.findStr(promoName, emuBitter)) {
				return "./images/emu.png";
			} else if (this.findStr(promoName, guinness)) {
				return "./images/guiness.png";
			} else if (this.findStr(promoName, hahn)) {
				return "./images/hahn.png";
			} else if (this.findStr(promoName, heineken)) {
				return "./images/heineken.png";
			} else if (this.findStr(promoName, kosciuszko)) {
				return "./images/kosciuszko.png";
			} else if (this.findStr(promoName, jb)) {
				return "./images/jb.png";
			} else if (this.findStr(promoName, js)) {
				return "./images/js.png";
			} else if (this.findStr(promoName, jsCider)) {
				return "./images/jscider.png";
			} else if (this.findStr(promoName, kirin)) {
				return "./images/kirin.png";
			} else if (this.findStr(promoName, lc)) {
				return "./images/lc.png";
			} else if (this.findStr(promoName, roam)) {
				return "./images/roam.png";
			} else if (this.findStr(promoName, swan)) {
				return "./images/swan.png";
			} else if (this.findStr(promoName, tooheys)) {
				return "./images/tooheys.png";
			} else if (this.findStr(promoName, ted)) {
				return "./images/ted.png";
			} else if (this.findStr(promoName, wed)) {
				return "./images/wed.png";
			} else if (this.findStr(promoName, wr)) {
				return "./images/wr.png";
			} else if (this.findStr(promoName, xxxx)) {
				return "./images/xxxx.png";
			} else if (this.findStr(promoName, xxxxSummer)) {
				return "./images/xxxxsummer.png";
			} else {
				return "./images/lion.png";
			}
			return "./images/lion.jpg";
		},

		findStr: function(search, array) {
			//alert(search.toLowerCase());
			//	alert(search.toLowerCase());
			for (var i = 0; i < array.length; i++) {
				if (search.toLowerCase().indexOf(array[i].toLowerCase()) !== -1) {
					return true;
				}
			}
			return false;
		},

		formatDate: function(val) {
			var date = new Date(val);
			var year = date.getFullYear();

			return date.getDate() + " " + date.toLocaleString("en-us", {
				month: "short"
			}) + " " + String(year).substr(2, 2);
		},
		/*
		  Help request for account 
		*/
		onAccountHelpRequest: function() {

			if (!this.oAccountHelpDialog) {
				// create dialog via fragment factory
				this.oAccountHelpDialog = sap.ui.xmlfragment("callplanning.view.accountHelp", this);
				this.oAccountHelpDialog.setModel(this.getOwnerComponent().getModel("accountlist"), "accountlist");
			}
			//			alert("here");
			// clear the old search filter
			this.oAccountHelpDialog.setModel(this.getOwnerComponent().getModel("accountlist"), "accountlist");
			//		this.oAccountHelpDialog.getBinding("items").filter([]);
			this.oAccountHelpDialog.open();
		},

		handleAccountSearch: function(oEvent) {

			var sValue = oEvent.getParameter("value");

			var oFilterName = new sap.ui.model.Filter("xsdLocal1:Name", sap.ui.model.FilterOperator.Contains, sValue);
			var oFilterAccount = new sap.ui.model.Filter("xsdLocal1:AccountNumber", sap.ui.model.FilterOperator.Contains, sValue);
			var oFilter = new sap.ui.model.Filter({
				filters: [oFilterName, oFilterAccount],
				and: false
			});
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		},
		/*
		  handle account confirm(selected)
		*/
		handleAccountClose: function(oEvent) {

			var aContexts = oEvent.getParameter("selectedContexts");
			var sel = oEvent.getParameter("selectedItem").getCells();
			//  invisible text
			//	sap.m.MessageToast.show("Adding CAll"+sel[1].getText());
			if (aContexts && aContexts.length) {
				sap.ui.getCore().byId("addcallaccountnumber").setValue(sel[0].getTitle());
				sap.ui.getCore().byId("addcallaccountname").setValue(sel[0].getText());
				sap.ui.getCore().byId("addcallaccountid").setText(sel[1].getText());
			}
			oEvent.getSource().getBinding("items").filter([]);
		},
		/*
		
		*/
		onCloseAddCallDialog: function() {
			this.oAddCallDialog.close();
		},

		/*
		 Save - Add Call
		 */
		onSaveAddCallDialog: function() {
			sap.m.MessageToast.show("Adding CAll");
			var date = new Date(sap.ui.getCore().byId("planneddate").getValue());
			var accountId = sap.ui.getCore().byId("addcallaccountid").getText();
			var accountName = sap.ui.getCore().byId("addcallaccountname").getValue();
			this.getOwnerComponent()._addCall(accountName, accountId, date);
			/*
			 Show Error if one exists
			*/
			if (this.getOwnerComponent().getModel("error").getProperty("/reasons") !== "") {
				//			alert("error:");																
				this.getOwnerComponent()._showError(this.getOwnerComponent().getModel("error").getProperty("/reasons"));
				return false;
			}

			this.oAddCallDialog.close();

			this.getOwnerComponent()._setTitles(this, null);
		},

		onCloseSellinDialog: function() {
			this.oSellinDialog.close();
		},
		onCloseActivateDialog: function() {
			this.oActivateDialog.close();
		},

		handleIconTabBarSelect: function(ev) {
			//	alert("press"+ev.getSource().getSelectedKey());
			var mainLabel = this.byId("mainlabel");
			if (ev.getSource().getSelectedKey() === "sellins") {
				mainLabel.setText("TO SELL IN THIS SD");
			} else if (ev.getSource().getSelectedKey() === "activations") {
				mainLabel.setText("TO ACTIVATE THIS SD");
			} else {
				mainLabel.setText("KPI TRACKER");
			}
			$('.sapMTextMaxLine').dotdotdot({});			
		},

		refreshKPI: function(ev){
				this.getOwnerComponent()._getSalesDrive(this);
		},

		/*
		  get each sell in and set business priority
		*/
		
		_setBusinessPriorities: function() {
	
			var oView = this.getView();
			this.getOwnerComponent()._getSellIns(oView);
			this.getOwnerComponent()._getActivations(oView);
		},
		_setSellinBusinessPriorities: function(ev) {
			
			

			// var items = ev.getSource().getItems();
			// //	alert(ev.getSource());

			// for (var i = 0; i < items.length; i++) {
			// 	// for each sellin - set priority

			// 	var info = items[i].getCustomData()[1].getValue();
			// 	this.getOwnerComponent().getBusinessPriority(items[i], info);
			// 	//	alert(info);
			// 	//	items[i].setPriority(items[i],this.setBusinessPriority(info));
			// }
	//		$('.sellins .sapMNLI-Body .sapMNLI-Description .sapMTextMaxLine').dotdotdot({});
	//alert("here");
			$('.sapMTextMaxLine').dotdotdot({});			
		},

		_setActivationBusinessPriorities: function(ev) {
			// var oView = this.getView();
			// this.getOwnerComponent()._getActivations(oView);
			// var items = ev.getSource().getItems();
			// //	alert(ev.getSource());

			// for (var i = 0; i < items.length; i++) {
			// 	// for each sellin - set priority

			// 	var info = items[i].getCustomData()[1].getValue();
			// 	this.getOwnerComponent().getBusinessPriority(items[i], info);
			// 	//	alert(info);
			// 	//	items[i].setPriority(items[i],this.setBusinessPriority(info));
				
			// }
			$('.sapMTextMaxLine').dotdotdot({});	
			//	$('.activationEntry .sapMNLI-Body .sapMNLI-Description .sapMTextMaxLine').dotdotdot({});
				
		},
		
		sellinsItemformatter: function(item) {
			alert(item);
			return item;
		}

	});
});