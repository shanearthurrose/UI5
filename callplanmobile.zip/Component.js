sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"sap/m/MessageBox",
	"callplanning/model/models"
], function(UIComponent, Device, MessageBox, models) {
	"use strict";

	return UIComponent.extend("callplanning.Component", {

		metadata: {
			manifest: "json"
		},

		//  
		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {

			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			var userModel = new sap.ui.model.json.JSONModel("/services/userapi/currentUser");
			userModel.loadData("/services/userapi/currentUser", null, false);

			this.setModel(userModel, "userInfo");

			var userModelAttr = new sap.ui.model.json.JSONModel("/services/userapi/attributes");
			userModelAttr.loadData("/services/userapi/attributes", null, false);

			this.setModel(userModelAttr, "userAttributes");

			var User = this.getModel("userAttributes").getProperty("/userid");
			//User = "Rmctacke";
			//User = "jehill";
			//

			this.userid = "";
			this.email = "";
			this.password = "";
			this.finish = false;
			this.organisation = "1-LUF"; //===>  "Lion Nathan Australia"; 

			this.tap = new sap.m.Input();

			this.report = {};

			//this.userid = User.toString().toUpperCase();
			//this.userName = this.getModel("userAttributes").getProperty("/userid");
			//this.userid = "RMctacke";
			//this.userid = this.userid.toUpperCase();
			this.prevView = "";

			/*************************************************************************************************/
			// get all LOV fields 	
			/*************************************************************************************************/
			//	this._getSalesDrive();

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			var date = new Date();
			this.setModel(date, "CURRENTDATE");

			if (!this.logon) {
				this.logon = sap.ui.xmlfragment("callplanning.view.login", this); //	this.oContactDialog.setModel(this.getOwnerComponent().getModel("sellins"), "sellins");
			}

			//			sap.ui.getCore().byId("opctitle").setTitle("Add OPC Notes");

			//this.oContactDialog.setModel(this.getOwnerComponent().getModel("sellins"), "sellins");
			this.logon.open();

		},

		onLogin: function(ev) {

			this.userid = sap.ui.getCore().byId("username").getValue().toUpperCase();
			this.password = sap.ui.getCore().byId("password").getValue();

			//	alert($('.password input').val());

			if (this.userid === "") {
				sap.ui.getCore().byId("username").setValueState(sap.ui.core.ValueState.Error);
				sap.m.MessageToast.show("Please Enter all Mandatory Fields(Userame)");
			} else if (this.password === "") {
				sap.ui.getCore().byId("password").setValueState(sap.ui.core.ValueState.Error);
				sap.m.MessageToast.show("Please Enter all Mandatory Fields(passord)");
			} else {
				//get calls
				jQuery.sap.delayedCall(100, this, function() {
					// Save values.
					this._checkLogin();

				});
				sap.ui.core.BusyIndicator.show(10);
			}

		},

		_checkLogin: function() {
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var today = new Date();

			var query = "/rest/callPlanCommon.service.salesDrive?inputDate=" + today.getFullYear() + "-" + (today.getMonth() + 1) + "-" + today
				.getDate() + "&userId=" + this.userid + "&password=" + this.password;

			//			sap.ui.commons.MessageBox.alert(query);	

			oModel.read(
				query,
				null, null, true,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));					
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					var oXML = new sap.ui.model.xml.XMLModel();

					oXML.setXML(obody);
					if (oXML.getProperty("/reasons") === "" || oXML.getProperty("/reasons") === null) {
						//that.getRouter().navTo("main", {}, false);
//						that._getAccountList();
						that.getRouter().initialize();
						that.getRouter().navTo("main", {}, false);
						that.logon.close();
//						that._getUserDetails();
						sap.ui.core.BusyIndicator.hide();
						//return true;
					} else {
						sap.ui.core.BusyIndicator.hide();
						oXML.setXML(obody);
						that.setModel(oXML, "error");
						that._showSiebelError("/reasons");
						//return false;
					}

				},
				function(oError) {
					sap.ui.core.BusyIndicator.hide();
				});
		},

		_getUserDetails: function() {
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var today = new Date();

			var query = "/rest/callPlanCommon.service.ldapAccount?username=" + this.userid;
			//alert(query);

			oModel.read(
				query,
				null, null, true,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));

					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					var oXML = new sap.ui.model.xml.XMLModel();
					oXML.setXML(obody);
					that.email = oXML.getProperty("/resultsList/mail");

				},
				function(oError) {
					//	alert("eerror"+oError);
					sap.ui.core.BusyIndicator.hide();
				});
		},

		onAfterRendering: function() {
			//	sap.ui.commons.MessageBox.alert("after");

			this._resetSessionTime();
			//			this._getAccountList();
		},

		_resetSessionTime: function() {
			var that = this;
			window.setInterval(function() {
				//	that._getSalesDrive();
				that._getLOV("LNXX", "XX", "");
			}, 900000);
		},

		_setCustomer: function(object) {
			this.setModel(object, "account");
		},

		_getCustomer: function() {
			return this.getModel("account");
		},

		_setOutlet: function(object) {
			this.setModel(object, "outlettype");
		},

		_getOutlet: function() {
			return this.getModel("outlettype");
		},

		_onProcessFlowPress: function(stage) {
			var oCustomer = this._getCustomer();
			sap.ui.core.BusyIndicator.hide();
			switch (stage) {
				case 'plan':
					//	alert(oCustomer.getAccountId());
					this.getRouter().navTo("plan", {
						id: oCustomer.getAccountId()
					}, false);
					break;
				case 'sell':
					//	this._getDiscrepencies(oCustomer.getAccountId());
					this.getRouter().navTo("sell", {}, false);
					break;
				case 'do':
					this.getRouter().navTo("do", {}, false);
					break;

				case 'finish':
					this.getRouter().navTo("finish", {}, false);
					break;
				default:
					break;
			}
			//sap.m.MessageToast.show('flow pressed:'+ev.getSource().getLaneId());                    		
		},

		_navigateTo: function(screen) {

			var oCustomer = this._getCustomer();
			switch (screen) {
				case 'plan':
					this.getRouter().navTo("plan", {
						id: oCustomer.getAccountId()
					}, false);
					break;
				case 'sell':
					this.getRouter().navTo("sell", {
						id: oCustomer.getAccountId()
					}, false);
					break;
				case 'finish':
					this.getRouter().navTo("finish", {}, false);
					break;

				case 'dealsummary':
					this.getRouter().navTo("dealsummary", {
						id: oCustomer.getAccountId()
					}, false);
					break;
				default:
					break;
			}
			//sap.m.MessageToast.show('flow pressed:'+ev.getSource().getLaneId());                    		
		},
		_showAttachment: function(string) {
			//	alert(string);
			//	sap.m.URLHelper.redirect(string, true);	
			window.open(string);
		},

		_openSiebelWindow: function(name, id) {
			var link = "";
			link = this.getModel("i18n").getResourceBundle().getText(name);
			link = link.replace("<id>", id);
			window.open(link, "SIEBEL");
		},

		_redirect: function(name) {
			var link = "";
			//			if (name === "toolkit") {
			//	window.open('file:///C:/');
			//window.open('file:///C:/temp', "_self");
			//			} else {
			link = this.getModel("i18n").getResourceBundle().getText(name);
			sap.m.URLHelper.redirect(link, true);
			//			}
		},
		/*
		  get account info
		 */
		_getTapCounter: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();

			var query = "/rest/callPlanCommon.service.tapCounter";
			that.setModel("tap");

			//		sap.ui.commons.MessageBox.alert(query);
			//alert(query);

			oModel.read(
				query,
				null, null, true,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					var oXML = new sap.ui.model.xml.XMLModel();
					//			sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));

					oXML.setXML(obody);
					that.setModel(oXML, "tap");
					that.getModel("tap").setSizeLimit(1000);
				},
				function(oError) {

				});
		},
		/*
		  get account info
		 */
		_getDiscrepencies: function(element, accountId, callId) {
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();

			var query = "/rest/callPlanCommon.service.activitiesDiscrepency?accountId=" + accountId +
				"&callId=" + callId;
			that.setModel("discrepency");

			element.setBusyIndicatorDelay(10);
			element.setBusy(true);
			//		sap.ui.commons.MessageBox.alert(query);

			oModel.read(
				query,
				null, null, true,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					var oXML = new sap.ui.model.xml.XMLModel();
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));

					oXML.setXML(obody);
					that.setModel(oXML, "discrepency");
					element.setBusy(false);
				},
				function(oError) {
					element.setBusy(false);
				});
		},

		/*
		  get account info
		 */
		_getRSM: function(view, accountId) {
			var oCustomer = this._getCustomer();
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();

			var query = "/rest/callPlanCommon.service.accountTeam?accountId=" + accountId;
			that.setModel("accountteam");

			//		sap.ui.commons.MessageBox.alert(query);

			oModel.read(
				query,
				null, null, true,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					var oXML = new sap.ui.model.xml.XMLModel();
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));					

					oXML.setXML(obody);
					that.setModel(oXML, "accountteam");

				},
				function(oError) {});
		},
		/*
		  get account info
		 */
		_getAccountTeam: function(view, accountId) {
			var oCustomer = this._getCustomer();
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();

			var query = "/rest/callPlanCommon.service.accountTeam?accountId=" + accountId+"&allFlag=Y";
			that.setModel("accountteamall");

			//		sap.ui.commons.MessageBox.alert(query);

			oModel.read(
				query,
				null, null, true,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					var oXML = new sap.ui.model.xml.XMLModel();
				//	sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));					

					oXML.setXML(obody);
					that.setModel(oXML, "accountteamall");

				},
				function(oError) {});
		},
		/*
		  get account info
		 */
		_getAccountContacts: function(view, accountId) {
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();

			var query = "/rest/callPlanCommon.service.accountContacts?accountId=" + accountId;
			that.setModel("accountcontact");

			//		sap.ui.commons.MessageBox.alert(query);

			oModel.read(
				query,
				null, null, true,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					var oXML = new sap.ui.model.xml.XMLModel();
					//sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));

					oXML.setXML(obody);
					var account = {};
					account.integrationId = oXML.getProperty("/xsdLocal1:Account/xsdLocal1:IntegrationId");
					account.Location = oXML.getProperty("/xsdLocal1:Account/xsdLocal1:Location");

					that.setModel(oXML, "accountcontact");
					that.setModel(account, "accountDetails");
				},
				function(oError) {});
		},
		/*
		  Delete account info
		 */
		_deleteAccountContacts: function(firstname, lastname, personUID) {
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			var that = this;
			var oEntry = {};

			var timeStamp = new Date().getTime();
			var account = this.getModel("accountDetails");

			oEntry.firstName = firstname;
			oEntry.lastName = lastname;
			oEntry.personUId = personUID;

			var oDataJSONModel = new sap.ui.model.json.JSONModel();

			var query = "/rest/callPlanCommon.service.accountContacts?firstName=" + firstname +
				"&lastName=" + lastname +
				"&personUId=" + personUID;

			//alert(firstname + lastname + personUID);
			//sap.ui.commons.MessageBox.alert(oEntry.integrationId);

			oModel.remove(query, null,
				function(oData, response) {
					//			sap.ui.commons.MessageBox.alert(JSON.stringify(response, null, 4));
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					var oXML = new sap.ui.model.xml.XMLModel();
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));
					/* no Error occured */
					if (oXML.getProperty("/reasons") === "") {
						//return true;
					} else {
						oXML.setXML(obody);
						//return false;
					}
					that.setModel(oXML, "error");
					sap.m.MessageToast.show("Contact Deleted");

				},
				function(oError) {
					//	return false;
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				});
		},

		/*
		  Create account info
		 */
		_createAccountContacts: function(accountId, account, firstname, lastname, position, email, phone, hospitality) {
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			var that = this;
			var oEntry = {};

			var timeStamp = new Date().getTime();
			var account = this.getModel("accountDetails");

			oEntry.integrationId = "HCP" + timeStamp; //need unique identifier
			oEntry.accountId = accountId;
			oEntry.firstName = firstname;
			oEntry.lastName = lastname;

			oEntry.emailAddress = email;
			oEntry.mobileNo = phone;
			oEntry.jobTitle = position;

			oEntry.accountIntegrationId = account.integrationId;

			oEntry.account = account;
			oEntry.accountLocation = account.Location;
			oEntry.accountOrganisation = "Lion Nathan Australia";

			if (hospitality) {
				oEntry.hospitalityFlag = "Y";
			}

			var oDataJSONModel = new sap.ui.model.json.JSONModel();

			var query = "/rest/callPlanCommon.service.accountContacts";

			//sap.ui.commons.MessageBox.alert(oEntry.integrationId);

			oModel.create(query, oEntry, null,
				function(oData, response) {
					//			sap.ui.commons.MessageBox.alert(JSON.stringify(response, null, 4));
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					var oXML = new sap.ui.model.xml.XMLModel();
					//sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));
					/* no Error occured */
					if (oXML.getProperty("/reasons") === "") {
						//return true;
					} else {
						oXML.setXML(obody);
						//return false;
					}
					that.setModel(oXML, "error");
				},
				function(oError) {
					//	return false;
					sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				});
		},
		/*
		  Create account info
		 */
		_updateAccountContacts: function(contactId, firstname, lastname, position, email, phone, hospitality) {
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			var that = this;
			var oEntry = {};

			var timeStamp = new Date().getTime();
			var account = this.getModel("accountDetails");

			oEntry.contactId = contactId;

			oEntry.firstName = firstname;
			oEntry.lastName = lastname;

			oEntry.emailAddress = email;
			oEntry.mobileNo = phone;
			oEntry.jobTitle = position;

			if (hospitality) {
				oEntry.hospitalityFlag = "Y";
			}

			var oDataJSONModel = new sap.ui.model.json.JSONModel();

			var query = "/rest/callPlanCommon.service.accountContacts";

			//sap.ui.commons.MessageBox.alert(oEntry.integrationId);

			oModel.update(query, oEntry, null,
				function(oData, response) {
					//			sap.ui.commons.MessageBox.alert(JSON.stringify(response, null, 4));
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					var oXML = new sap.ui.model.xml.XMLModel();
					//sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));
					/* no Error occured */
					if (oXML.getProperty("/reasons") === "") {
						//return true;
					} else {
						oXML.setXML(obody);
						//return false;
					}
					that.setModel(oXML, "error");
				},
				function(oError) {
					//	return false;
					sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				});
		},

		/*
		  get account info
		 */
		_getAccountList: function() {
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var today = new Date();

			// TODO: Remove hardcoding

			//	accountId = "1-2MZTDK";
			//	owner = "FMIEL";

			var query = "/rest/callPlanCommon.service.getAccountList?owner=" + this.userid;
			that.setModel("accountlist");
			//alert(query);
			//		sap.ui.commons.MessageBox.alert(query);

			oModel.read(
				query,
				null, null, true,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));					
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					var oXML = new sap.ui.model.xml.XMLModel();
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));					

					oXML.setXML(obody);
					that.setModel(oXML, "accountlist");
				},
				function(oError) {});
		},

		/*a
		  get report info
		 */
		_getReport: function(type, date, account) {
			jQuery.sap.require("sap.m.MessageToast");
			var oCustomer = this._getCustomer();
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			//var reportDate = new Date(date);
			var reportDate = new Date();
			var inDate = new Date(oCustomer.getCallDate());
			var day = reportDate.getDate();
			var month = (reportDate.getMonth() + 1);
			month = ("0" + month).slice(-2);
			day = ("0" + day).slice(-2);

			var query = "/rest/callPlanCommon.service.reports?reportType=" + type + "&reportDate=" + reportDate.getFullYear() + month + day +
				"&accountNumber=" + account;

			//	sap.ui.commons.MessageBox.alert(query);
			sap.ui.core.BusyIndicator.show(10);
			var pdfString;

			if (inDate.getDate() !== reportDate.getDate()) {
				jQuery.sap.delayedCall(100, this, function() {
					that._createAdhocReport(oCustomer.getActivityId(), type.toUpperCase());
					that._getGeneratedReport(type, reportDate.getFullYear() + month + day, account);
				});
				sap.m.MessageToast.show("regenerating report " + type.toUpperCase());
			} else {

				jQuery.sap.delayedCall(100, this, function() {
					oModel.read(
						query,
						null, null, true,
						function(oData, response) {
							// create JSON model  
							oDataJSONModel.setData(response);
							var obody = oDataJSONModel.getProperty("/body");
							var oXML = new sap.ui.model.xml.XMLModel();

							sap.ui.core.BusyIndicator.hide();

							oXML.setXML(obody);
							var pdfString = oXML.getProperty("/reportOutput/reportContent");

							if (that.report[type]) {
								that.report[type].close();
							}
							that.report[type] = window.open(pdfString, type);
							that.report[type].focus();

							//						myWindow.close();
							//						myWindow = window.open(pdfString, type);
							//myWindow.focus();

						},
						function(oError) {
							jQuery.sap.delayedCall(100, this, function() {
								that._createAdhocReport(oCustomer.getActivityId(), type.toUpperCase());
								that._getGeneratedReport(type, reportDate.getFullYear() + month + day, account);
								sap.ui.core.BusyIndicator.hide();
							});
							sap.m.MessageToast.show("No report Found - regenerating report " + type.toUpperCase());
						});

				});
			}
		},
		_getGeneratedReport: function(type, date, account) {
			jQuery.sap.require("sap.m.MessageToast");
			var oCustomer = this._getCustomer();
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			//var reportDate = new Date(date);
			var reportDate = new Date();

			//reportType=bpc   (other input: mv,opc,dd,vplitres,vpunits)
			//reportDate=20161219 (yyyyMMdd)
			//accountNumber= 05658

			//	accountId = "1-2MZTDK";
			//	owner = "FMIEL";
			var day = reportDate.getDate();
			var month = (reportDate.getMonth() + 1);
			month = ("0" + month).slice(-2);
			day = ("0" + day).slice(-2);

			var query = "/rest/callPlanCommon.service.reports?reportType=" + type + "&reportDate=" + reportDate.getFullYear() + month + day +
				"&accountNumber=" + account;

			//	sap.ui.commons.MessageBox.alert(query);
			//sap.ui.core.BusyIndicator.show(100);
			var pdfString;

			oModel.read(
				query,
				null, null, false,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					var oXML = new sap.ui.model.xml.XMLModel();

					sap.ui.core.BusyIndicator.hide();

					oXML.setXML(obody);
					var pdfString = oXML.getProperty("/reportOutput/reportContent");

					//that.report.opc.close();
					if (that.report[type]) {
						that.report[type].close();
					}
					that.report[type] = window.open(pdfString, type);
					that.report[type].focus();

					sap.ui.core.BusyIndicator.hide();

				},
				function(oError) {
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageToast.show("No report Found");
				});
		},
		_emailReports: function(callId, account, emailTo, emailFrom, emailCC, emailSubject, emailBody, reports) {
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();

			var data = {};

			// Create update payload

			data.callId = callId;
			data.accountNumber = account;
			data.emailTo = emailTo;
			data.emailCC = emailCC;
			data.emailFrom = emailFrom;
			data.emailSubject = emailSubject;
			data.emailBody = emailBody;

			//			alert(callId +"/"+account+"/"+emailTo);

			data.report = reports;

			var query = "/rest/callPlanCommon.service.emailReport";

			//	alert(query);

			oModel.create(query, data, null,
				function(oData, response) {
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					var oXML = new sap.ui.model.xml.XMLModel();
					oXML.setXML(obody);
					//		sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));
					/* no Error occured */
					//		if (oXML.getProperty("/reasons") === "") {
					//that.onCloseEmailDialog();
					sap.ui.core.BusyIndicator.hide();
					sap.m.MessageToast.show("Email Successfully Sent");
					//		} else {
					//			oXML.setXML(obody);
					//			that.setModel(oXML, "error");
					//			that._showSiebelError("/reasons");
					//		}
				},
				function(oError) {
					//alert("error" + oError);
					sap.ui.core.BusyIndicator.hide();
					that._handleUnknownError(oError);
				});

		},
		_getSellinAttachment: function(promoId) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var today = new Date();

			// TODO: Remove hardcoding
			//	activityId = "1-493D0MI";

			var query = "/rest/callPlanCommon.service.promoAttachment?promoId=" + promoId;
			//	that.setModel("kpi");

			//	sap.ui.commons.MessageBox.alert(query);
			sap.ui.core.BusyIndicator.show(100);
			var pdfString;
			that.setModel("attachments");

			oModel.read(
				query,
				null, null, true,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					//sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));					
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					var oXML = new sap.ui.model.xml.XMLModel();

					sap.ui.core.BusyIndicator.hide();

					oXML.setXML(obody);
					that.setModel(oXML, "attachments");
					//sap.ui.commons.MessageBox.alert(oXML.getProperty("/xsdLocal1:CpgPromotion/xsdLocal1:ListOfAdminSalesTool/xsdLocal1:AdminSalesTool/xsdLocal1:LitFileBuffer"));
					var pdfString = oXML.getProperty(
						"/xsdLocal1:CpgPromotion/xsdLocal1:ListOfAdminSalesTool/xsdLocal1:AdminSalesTool/xsdLocal1:LitFileBuffer");
					//sap.ui.commons.MessageBox.alert(pdfString);
					var fileExt = oXML.getProperty(
						"/xsdLocal1:CpgPromotion/xsdLocal1:ListOfAdminSalesTool/xsdLocal1:AdminSalesTool/xsdLocal1:LitFileExt");
					var fileName = oXML.getProperty(
						"/xsdLocal1:CpgPromotion/xsdLocal1:ListOfAdminSalesTool/xsdLocal1:AdminSalesTool/xsdLocal1:LitFileName");

					//	alert(oXML.getProperty("/xsdLocal1:CpgPromotion/xsdLocal1:ListOfAdminSalesTool/xsdLocal1:AdminSalesTool/xsdLocal1:LitFileExt"));
					//	window.open("data:application/pdf;base64," + pdfString);
					// TODO: 

					var content = pdfString.slice(pdfString.indexOf("base64") + 7);
					//content = "data:ms-powerpoint;base64," + content;
					//	alert(content);
					if (fileExt === "pptx" || fileExt === "ppt") {
						var blob = that.b64toBlob(content, "application/vnd.openxmlformats-officedocument.presentationml.presentation", 512);
						//	alert(blob);
						var blobUrl = URL.createObjectURL(blob);
						//						window.open(blobUrl);
						download(blob, fileName + "." + fileExt);
					} else {
						window.open(pdfString);
					}
					//   download(content,fileName+"."+fileExt);
					//	document.location = pdfString;

				},
				function(oError) {
					sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
					sap.ui.core.BusyIndicator.hide();
				});

			//sap.m.URLHelper.redirect("data:application/pdf;base64," + pdfString, true);
			//	sap.ui.commons.MessageBox.alert(pdfString);
			//	window.open("data:application/pdf," + encodeURI(pdfString)); 
		},
		b64toBlob: function(b64Data, contentType, sliceSize) {
			contentType = contentType || '';
			sliceSize = sliceSize || 512;

			var byteCharacters = atob(b64Data);
			var byteArrays = [];

			for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
				var slice = byteCharacters.slice(offset, offset + sliceSize);

				var byteNumbers = new Array(slice.length);
				for (var i = 0; i < slice.length; i++) {
					byteNumbers[i] = slice.charCodeAt(i);
				}

				var byteArray = new Uint8Array(byteNumbers);

				byteArrays.push(byteArray);
			}

			var blob = new Blob(byteArrays, {
				type: contentType
			});
			return blob;
		},
		/*a
		  get KPI info
		 */
		_getActivityAttachment: function(activityId) {
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var today = new Date();

			// TODO: Remove hardcoding
			//	activityId = "1-493D0MI";

			var query = "/rest/callPlanCommon.service.activity?activityId=" + activityId;
			//	that.setModel("kpi");

			//	sap.ui.commons.MessageBox.alert(query);
			sap.ui.core.BusyIndicator.show(100);
			var pdfString;
			that.setModel("attachments");

			oModel.read(
				query,
				null, null, true,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));					
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					var oXML = new sap.ui.model.xml.XMLModel();

					sap.ui.core.BusyIndicator.hide();

					oXML.setXML(obody);
					that.setModel(oXML, "attachments");
					//	sap.ui.commons.MessageBox.alert(oXML.getProperty("/xsdLocal1:Action/xsdLocal1:ListOfActionAttachment/xsdLocal1:ActionAttachment/xsdLocal1:ActivityFileBuffer"));
					var pdfString = oXML.getProperty(
						"/xsdLocal1:Action/xsdLocal1:ListOfActionAttachment/xsdLocal1:ActionAttachment/xsdLocal1:ActivityFileBuffer");
					//alert(pdfString);

					var fileExt = oXML.getProperty(
						"/xsdLocal1:Action/xsdLocal1:ListOfActionAttachment/xsdLocal1:ActionAttachment/xsdLocal1:ActivityFileExt");
					var fileName = oXML.getProperty(
						"/xsdLocal1:Action/xsdLocal1:ListOfActionAttachment/xsdLocal1:ActionAttachment/xsdLocal1:ActivityFileName");

					//	alert(oXML.getProperty("/xsdLocal1:CpgPromotion/xsdLocal1:ListOfAdminSalesTool/xsdLocal1:AdminSalesTool/xsdLocal1:LitFileExt"));
					//	window.open("data:application/pdf;base64," + pdfString);
					// TODO: 

					var content = pdfString.slice(pdfString.indexOf("base64") + 7);
					//content = "data:ms-powerpoint;base64," + content;
					//	alert(content);
					if (fileExt === "pptx" || fileExt === "ppt") {
						var blob = that.b64toBlob(content, "application/vnd.openxmlformats-officedocument.presentationml.presentation", 512);
						//	alert(blob);
						var blobUrl = URL.createObjectURL(blob);
						download(blob, fileName + "." + fileExt);
						//	window.open(blobUrl);
					} else {
						window.open(pdfString);
					}
					//	window.open("data:application/pdf;base64," + pdfString);
					// TODO: 	
					//	window.open(pdfString);

				},
				function(oError) {
					sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
					sap.ui.core.BusyIndicator.hide();
				});

			//sap.m.URLHelper.redirect("data:application/pdf;base64," + pdfString, true);
			//	sap.ui.commons.MessageBox.alert(pdfString);
			//	window.open("data:application/pdf," + encodeURI(pdfString)); 
		},
		/*a
		  get KPI info
		 */
		_getKPI: function(startDate, endDate, owner, salesdrive) {
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var today = new Date();

			// TODO: Remove hardcoding

			//	accountId = "1-2MZTDK";
			//	owner = "FMIEL";

			var query = "/rest/callPlanCommon.service.kpiDetails?startDate=" + startDate + "&endDate=" + endDate + "&owner=" + owner +
				"&salesDrive=" + salesdrive;
			that.setModel("kpi");

			//		sap.ui.commons.MessageBox.alert(query);

			oModel.read(
				query,
				null, null, true,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					//				sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));					
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					var oXML = new sap.ui.model.xml.XMLModel();
					//		sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));					

					oXML.setXML(obody);
					that.setModel(oXML, "kpi");
				},
				function(oError) {
					sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				});
		},

		_setStartCall: function(activityId, view) {
			var sServiceUrl = "/destinations/WebMethods";
			//	var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
			//		"Content-Type": "application/xml; charset=utf-8"
			//	});
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);

			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var activity = {};

			// TODO: Remove hardcoding

			//	activityId = "1-4C5PQA9" ; //activityId;
			//	alert(activityId);

			var query = "/rest/callPlanCommon.service.call?callId=" + activityId + "&userId=" + this.userid + "&password=" + this.password;

			//		sap.ui.commons.MessageBox.alert(query);
			that.setModel("startcall");
			that.setModel(activityId);
			sap.ui.core.BusyIndicator.show(100);

			oModel.read(
				query,
				null, null, false,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					var oXML = new sap.ui.model.xml.XMLModel();
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));

					oXML.setXML(obody);
					sap.ui.core.BusyIndicator.hide();
					// Tap Review, Price Review,Retail Review. 
					//sap.ui.commons.MessageBox.alert(oXML.getProperty("/tns:Result"));
					//sap.ui.commons.MessageBox.alert(oXML.getProperty("/tns:Error_spcMessage"));
					if (oXML.getProperty("/tns:Result") === "FAILED") {
						activity.started = false;
						that.setModel(oXML, "error");
						that._showSiebelError("/tns:Error_spcMessage");
						that.setModel(activity, activityId);

					} else {
						activity.started = true;
						that.setModel(oXML, "startcall");
						that.setModel(activity, activityId);

						//					alert(activityId);
						that._getOutletCheck(null, activityId);
					}
					/*					
										var outletCheck = oXML.getProperty("/tns:Review_spcSub_spcTypes");

										activity.started = false;

										if (outletCheck.toLowerCase().indexOf("tap review") !== -1) {
											view.byId("tapreview").setVisible(true);
											activity.tapreview = true;
											activity.started = true;
											//alert(outletCheck);						
										}
										if (outletCheck.toLowerCase().indexOf("retail review") !== -1) {
											view.byId("retailreview").setVisible(true);
											activity.retailreview = true;
											activity.started = true;
										}
										if (outletCheck.toLowerCase().indexOf("price review") !== -1) {
											view.byId("pricecheck").setVisible(true);
											activity.pricecheck = true;
											activity.started = true;
										}
					*/

				},
				function(oError) {
					sap.ui.core.BusyIndicator.hide();
					sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				});

		},

		/*
		  Finish Call
		*/
		_setFinishCall: function(callId, contactId, feedBack, comments) {
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);

			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var oEntry = {};

			oEntry.callId = callId;
			oEntry.contactId = contactId;
			oEntry.feedBackFlag = feedBack;
			oEntry.comment = comments;

			// TODO: map comments to correct field

			var query = "/rest/callPlanCommon.service.call";

			//	sap.ui.commons.MessageBox.alert(query);

			jQuery.sap.delayedCall(500, this, function() {
				oModel.create(query, oEntry, null,
					function(oData, response) {
						//			sap.ui.commons.MessageBox.alert(JSON.stringify(response, null, 4));
						oDataJSONModel.setData(response);
						var obody = oDataJSONModel.getProperty("/body");
						var oXML = new sap.ui.model.xml.XMLModel();
						oXML.setXML(obody);
						//	sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));
						/* no Error occured */
						//sap.ui.commons.MessageBox.alert(oXML.getProperty("/tns:Result"));
						sap.ui.core.BusyIndicator.hide();
						if (oXML.getProperty("/tns:Result") === "SUCCESS") {
							//that.getRouter().navTo("main", {}, false);
							that._updateNotes(comments);
							that.onSelfReflection();
							//return true;
						} else {
							oXML.setXML(obody);
							that.setModel(oXML, "error");
							that._showSiebelError("/tns:Error_spcMessage");
							//return false;
						}

						that.setModel(oXML, "error");

					},
					function(oError) {
						sap.ui.core.BusyIndicator.hide();
						//	return false;
						//				sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
					});

			});
			sap.ui.core.BusyIndicator.show(100);

		},

		/*
		  Finish Call
		*/
		_setSelfReflection: function(contactId, note, behaviour, skill) {
			/*
			accountId=1-2MZTDK
			accountName= Coogee Bay Hotel
			accountNumber=16250
			contactId=1-3BJGIUN
			lnNoteCreatedfromCall=Y
			primaryOwnedBy= FMIEL
			primaryOwnedId=1-3BJGIUN
			
			note= Blah 1 Blah 2 Blah4
			noteType= Reflection Note
			reflectionNoteBehaviour= Collaborate to Achieve
			reflectionNoteSkill= Business acumen
*/
			var oCustomer = this._getCustomer();
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);

			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var oEntry = {};

			oEntry.accountId = oCustomer.getAccountId();
			oEntry.accountName = oCustomer.getAccountName();
			oEntry.accountNumber = oCustomer.getAccountNumber();

			oEntry.contactId = contactId;
			oEntry.lnNoteCreatedfromCall = "Y";
			oEntry.note = note;
			oEntry.noteType = "Reflection Note";
			oEntry.reflectionNoteBehaviour = behaviour;
			oEntry.reflectionNoteSkill = skill;

			// TODO: map comments to correct field

			var query = "/rest/callPlanCommon.service.selfReflectionNote";

			//	sap.ui.commons.MessageBox.alert(query);

			jQuery.sap.delayedCall(500, this, function() {
				oModel.create(query, oEntry, null,
					function(oData, response) {
						//			sap.ui.commons.MessageBox.alert(JSON.stringify(response, null, 4));
						oDataJSONModel.setData(response);
						var obody = oDataJSONModel.getProperty("/body");
						var oXML = new sap.ui.model.xml.XMLModel();
						oXML.setXML(obody);
						//	sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));
						/* no Error occured */
						//sap.ui.commons.MessageBox.alert(oXML.getProperty("/tns:Result"));
						sap.ui.core.BusyIndicator.hide();
						if (oXML.getProperty("/tns:Result") === "SUCCESS") {
							//that.getRouter().navTo("main", {}, false);
							//return true;
						} else {
							oXML.setXML(obody);
							that.setModel(oXML, "error");
							that._showSiebelError("/tns:Error_spcMessage");
							//return false;
						}

						that.setModel(oXML, "error");

					},
					function(oError) {
						sap.ui.core.BusyIndicator.hide();
						//	return false;
						//				sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
					});

			});
			sap.ui.core.BusyIndicator.show(100);

		},

		/*
		  Get customer Account Activations

		*/

		_setReschedule: function(activityId, date) {
			var sServiceUrl = "/destinations/WebMethods";
			//	var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
			//		"Content-Type": "application/xml; charset=utf-8"
			//	});
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);

			var oEntry = {};
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();

			// TODO: Remove hardcoding

			oEntry.activityUID = activityId;
			oEntry.startDate = date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate();

			var query = "/rest/callPlanCommon.service.callsInbound";

			//	sap.ui.commons.MessageBox.alert(query);
			that.setModel("error");

			oModel.create(query, oEntry, null,
				function(oData, response) {
					//			sap.ui.commons.MessageBox.alert(JSON.stringify(response, null, 4));
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					var oXML = new sap.ui.model.xml.XMLModel();
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));					
					/* no Error occured */
					if (oXML.getProperty("/reasons") === "") {
						//return true;
					} else {
						oXML.setXML(obody);
						//return false;
					}
					that.setModel(oXML, "error");
				},
				function(oError) {
					//	return false;
					//				sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				});

		},

		_setActivityStatus: function(activityId, status, comment) {
			var sServiceUrl = "/destinations/WebMethods";
			//	var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
			//		"Content-Type": "application/xml; charset=utf-8"
			//	});
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);

			var oEntry = {};
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();

			// TODO: Remove hardcoding

			oEntry.activityUID = activityId;
			oEntry.status = status;
			oEntry.comment = comment;

			var query = "/rest/callPlanCommon.service.activity";

			//	sap.ui.commons.MessageBox.alert(query);
			that.setModel("error");

			oModel.create(query, oEntry, null,
				function(oData, response) {
					//			sap.ui.commons.MessageBox.alert(JSON.stringify(response, null, 4));
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					var oXML = new sap.ui.model.xml.XMLModel();
					sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));
					/* no Error occured */
					if (oXML.getProperty("/reasons") === "") {
						//return true;
					} else {
						oXML.setXML(obody);
						//return false;
					}
					that.setModel(oXML, "error");
				},
				function(oError) {
					//	return false;
					//				sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				});

		},

		/*
		  Get customer Account Activations

		*/

		_addCall: function(accountName, accountId, date) {
			var sServiceUrl = "/destinations/WebMethods";
			//	var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
			//		"Content-Type": "application/xml; charset=utf-8"
			//	});
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);

			var oEntry = {};
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();

			// TODO: Remove hardcoding

			oEntry.accountName = accountName;
			oEntry.owner = this.userid;
			oEntry.accountId = accountId;
			oEntry.startDate = date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate();
			//	sap.ui.commons.MessageBox.alert(accountName + "/" + date + "/" + accountId);

			var query = "/rest/callPlanCommon.service.callsInbound";

			//	sap.ui.commons.MessageBox.alert(query);
			that.setModel("error");

			oModel.update(query, oEntry, null,
				function(oData, response) {
					//			sap.ui.commons.MessageBox.alert(JSON.stringify(response, null, 4));
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					var oXML = new sap.ui.model.xml.XMLModel();
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));					
					/* no Error occured */
					if (oXML.getProperty("/reasons") === "") {
						//return true;
					} else {
						oXML.setXML(obody);
						//	sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));	
						//return false;
					}
					that.setModel(oXML, "error");
				},
				function(oError) {
					//	return false;
					//				sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				});

		},

		_showSiebelError: function(field) {
			var oXML = this.getModel("error");
			var oErrorMessage = oXML.getProperty(field);
			this._showError(oErrorMessage);

		},

		_showError: function(message) {
			//			sap.ui.commons.MessageBox.alert("Error1:"+message);				
			//this.getModel("error").getProperty("/reasons")
			sap.ui.core.BusyIndicator.hide();
			var dialog = new sap.m.Dialog({
				title: 'Error',
				type: 'Message',
				state: 'Error',
				content: new sap.m.Text({
					text: message
				}),
				beginButton: new sap.m.Button({
					text: 'OK',
					press: function() {
						dialog.close();
					}
				}),
				afterClose: function() {
					dialog.destroy();
				}
			});

			dialog.open();
		},

		_showSiebelInfo: function(field) {
			var oXML = this.getModel("info");
			var oInfoMessage = oXML.getProperty(field);
			this._showInfo(oInfoMessage);

		},

		_showInfo: function(message) {
			//			sap.ui.commons.MessageBox.alert("Error1:"+message);				
			//this.getModel("error").getProperty("/reasons")
			sap.ui.core.BusyIndicator.hide();
			var dialog = new sap.m.Dialog({
				title: 'Information',
				type: 'Message',
				state: 'Success',
				content: new sap.m.Text({
					text: message
				}),
				beginButton: new sap.m.Button({
					text: 'OK',
					press: function() {
						dialog.close();
					}
				}),
				afterClose: function() {
					dialog.destroy();
				}
			});

			dialog.open();
		},

		_showText: function(title, message) {
			//			sap.ui.commons.MessageBox.alert("Error1:"+message);				
			//this.getModel("error").getProperty("/reasons")
			var dialog = new sap.m.Dialog({
				title: title,
				//	type: 'Message',
				state: 'None',
				content: new sap.m.Text({
					text: message
				}),
				beginButton: new sap.m.Button({
					text: 'OK',
					press: function() {
						dialog.close();
					}
				}),
				afterClose: function() {
					dialog.destroy();
				}
			});

			dialog.open();
		},

		/*
		  Get customer Account Activations
		*/
		_updateAccountactivations: function(activityId, status, reason, comment, rescheduleFlag, gotoPrevScreen) {
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			var oCustomer = this._getCustomer();
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var oEntry = {};

			oEntry.activityUID = activityId;
			oEntry.status = status;
			oEntry.comment = reason;

			if (rescheduleFlag !== "Y") {
				rescheduleFlag = "N";
			}
			oEntry.rescheduledFlag = rescheduleFlag;

			var startDate = new Date(oCustomer.getCallDate());
			//	alert(startDate.getDate() + "/" + (startDate.getMonth() +1 ) + "/"+startDate.getFullYear());

			var End;
			var Start = End = startDate.getFullYear() + "-" + ("0" + (startDate.getMonth() + 1)).slice(-2) + "-" + startDate.getDate();

			/*
			    valid values : Achieved, ...
			*/

			//		oEntry.comment = reason;

			var query = "/rest/callPlanCommon.service.activity";

			//	sap.ui.commons.MessageBox.alert(oEntry.rescheduleFlag);
			//	sap.ui.commons.MessageBox.alert(activityId + ":" + status);
			jQuery.sap.delayedCall(200, this, function() {
				oModel.update(query, oEntry, null,
					function(oData, response) {
						//			sap.ui.commons.MessageBox.alert(JSON.stringify(response, null, 4));
						oDataJSONModel.setData(response);
						var obody = oDataJSONModel.getProperty("/body");
						var oXML = new sap.ui.model.xml.XMLModel();
						oXML.setXML(obody);
						//		sap.ui.commons.MessageBox.alert("reason:"+oXML.getProperty("/reasons"));
						/* no Error occured */
						//	sap.ui.core.BusyIndicator.hide();
						//sap.ui.core.BusyIndicator.hide();
						if (oXML.getProperty("/reasons") === "" || oXML.getProperty("/reasons") === null) {
							//return true;
							//	sap.m.MessageToast.show("Status Updated Successfully");

							if (gotoPrevScreen) {
								that._onProcessFlowPress(that.prevView);
							} else {
								that._getOutletCheck(null, oCustomer.getActivityId());

								that._getAccountActivations(null,
									Start, End,
									//	that.getModel("salesdrive").getProperty("/StartDate"),
									//	that.getModel("salesdrive").getProperty("/EndDate"),
									that.userid,
									oCustomer.getAccountId());
							}

						} else {
							//	sap.m.MessageToast.show("error");
							that._getAccountActivations(null,
								Start, End,
								//	that.getModel("salesdrive").getProperty("/StartDate"),
								//	that.getModel("salesdrive").getProperty("/EndDate"),
								that.userid,
								oCustomer.getAccountId());
							sap.ui.core.BusyIndicator.hide();
							oXML.setXML(obody);
							that.setModel(oXML, "error");
							that._showSiebelError("/reasons");

						}
						that.setModel(oXML, "error");
					},
					function(oError) {
						//	return false;
						sap.ui.core.BusyIndicator.hide();
						sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
					});

			});

			sap.ui.core.BusyIndicator.show(100);

		},

		_getAccountActivations: function(element, startDate, endDate, owner, accountId) {
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var today = new Date();

			// TODO: Remove hardcoding

			//	accountId = "1-2MZTDK";
			//	owner = "FMIEL";

			var query = "/rest/callPlanCommon.service.accountActivateRead?startDate=" + startDate + "&endDate=" + endDate + "&owner=" + owner +
				"&accountId=" + accountId;
			that.setModel("accountactivations");

			//	sap.ui.commons.MessageBox.alert(element);
			if (element !== null) {
				element.setBusyIndicatorDelay(10);
				element.setBusy(true);
			}

			oModel.read(
				query,
				null, null, true,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));					
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					var oXML = new sap.ui.model.xml.XMLModel();
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));					
					oXML.setXML(obody);
					var oActivationsXML = that.getModel("activations");
					var _true = true;
					var i = 0;
					var j = 0;
					var bindingPath;
					var activationId;
					var activationDescription;
					var activationPromotionName = "c";
					var accountActivationPromotionName = "b";
					var accountActivationBindingPath = "/xsdLocal1:Account/xsdLocal1:ListOfActionThin/xsdLocal1:ActionThin/";

					while (_true) {
						try {
							i = 0;
							accountActivationPromotionName = oXML.getProperty(accountActivationBindingPath + j + "/xsdLocal1:Description2");
							if (accountActivationPromotionName != null && accountActivationPromotionName !== "") {
								while (_true) {
									bindingPath = "/actionList/" + i;
									try {
										activationId = oActivationsXML.getProperty(bindingPath + "/activationID");
										activationDescription = oActivationsXML.getProperty(bindingPath + "/description");

										if (activationId != null && activationId !== "" && activationPromotionName != null && activationPromotionName !== "") {
											activationPromotionName = activationId + " " + activationDescription;
										} else {
											activationPromotionName = "";
										}

										if (activationPromotionName !== "" && activationPromotionName != null && accountActivationPromotionName ===
											activationPromotionName) {

											var priority = oActivationsXML.getProperty(bindingPath + "/priority");
											var priorityNumber = oActivationsXML.getProperty(bindingPath + "/priorityNumber");
											if (priority == null || priority === "") {
												priority = "None";
											}

											if (priorityNumber == null || priorityNumber === "") {
												priorityNumber = 4;
											}
											var priorityNumNode = oXML.oData.createElement("priorityNumber");
											var priorityNode = oXML.oData.createElement("priority");
											var oNode = oXML.getObject(accountActivationBindingPath + j);
											priorityNumNode.innerHTML = priorityNumber;
											priorityNode.innerHTML = priority;
											oNode.appendChild(priorityNode);
											oNode.appendChild(priorityNumNode);
											j = j + 1;
											oXML.refresh();
											break;
										}
										i = i + 1;
									} catch (e) {
										// IF PRIORITY IS NOT FOUND FOR THE SELLIN
										j = j + 1;
										break;
									}
								}
							} else {
								break;
							}
						} catch (e) {
							break;
						}
					}

					that.setModel(oXML, "accountactivations");
					if (element !== null) {
						element.setBusy(false);
					} else {
						sap.ui.core.BusyIndicator.hide();
					}
					sap.ui.core.BusyIndicator.hide();
				},
				function(oError) {
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));	
					if (element !== null) {
						element.setBusy(false);
					} else {
						sap.ui.core.BusyIndicator.hide();
					}
				});
		},
		/*
		  Get account sell ins
		*/
		_getAccountSellins: function(element, startDate, endDate, owner, accountId, modelName) {
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;

			var oCustomer = this._getCustomer();
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var today = new Date();
			var model = "accountsellins";

			if (modelName) {
				model = modelName;
			}

			// TODO: Remove hardcoding
			owner = this.userid;

			//accountId = "1-2MZTDK";
			//owner = "FMIEL";
			//startDate = "2016-10-31";
			//endDate = "2016-11-27";	
			//	alert(startDate);

			var query = "/rest/callPlanCommon.service.accountSellIn?startDate=" + startDate + "&endDate=" + endDate + "&owner=" + owner +
				"&accountId=" + accountId;
			that.setModel(model);

			//	sap.ui.commons.MessageBox.alert(model);
			if (element !== null) {
				element.setBusyIndicatorDelay(10);
				element.setBusy(true);
			}

			oModel.read(
				query,
				null, null, true,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));					
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					var oXML = new sap.ui.model.xml.XMLModel();
					oXML.setXML(obody);
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));

					var oSellinsXML = that.getModel("sellins");
					var _true = true;
					var i = 0;
					var j = 0;
					var bindingPath;
					var sellinPromotionName = "b";
					var accountSellinPromotionName = "b";
					var accountSellinBindingPath = "/xsdLocal1:CpgPlanAccountPromotion/";
					while (_true) {
						try {
							i = 0;
							accountSellinPromotionName = oXML.getProperty(accountSellinBindingPath + j + "/xsdLocal1:PlanAccountPromotionName");
							if (accountSellinPromotionName != null && accountSellinPromotionName !== "") {
								while (_true) {
									bindingPath = "/accountPromotionList/" + i;
									try {

										sellinPromotionName = oSellinsXML.getProperty(bindingPath + "/promotionName");
										if (sellinPromotionName !== "" && sellinPromotionName != null && accountSellinPromotionName === sellinPromotionName) {

											var priority = oSellinsXML.getProperty(bindingPath + "/priority");
											var priorityNumber = oSellinsXML.getProperty(bindingPath + "/priorityNumber");
											if (priority == null || priority === "") {
												priority = "None";
											}

											if (priorityNumber == null || priorityNumber === "") {
												priorityNumber = 4;
											}
											var priorityNumNode = oXML.oData.createElement("priorityNumber");
											var priorityNode = oXML.oData.createElement("priority");
											var oNode = oXML.getObject(accountSellinBindingPath + j);
											priorityNumNode.innerHTML = priorityNumber;
											priorityNode.innerHTML = priority;
											oNode.appendChild(priorityNode);
											oNode.appendChild(priorityNumNode);
											j = j + 1;
											oXML.refresh();
											break;
										}
										i = i + 1;
									} catch (e) {
										// IF PRIORITY IS NOT FOUND FOR THE SELLIN
										j = j + 1;
										break;
									}
								}
							} else {
								break;
							}
						} catch (e) {
							break;
						}
					}

					that.setModel(oXML, model);
					if (element !== null) {
						element.setBusy(false);
					}

				},
				function(oError) {
					if (element !== null) {
						element.setBusy(false);
					}

				});
		},

		_updateAccountSellinsRSM: function(activityId, status, comment, description, reasonCode, position, login) {
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);

			var that = this;
			var oCustomer = this._getCustomer();

			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var oEntry = {};
			var customer = this._getCustomer();

			var startDate = new Date(oCustomer.getCallDate());
			//	alert(startDate.getDate() + "/" + (startDate.getMonth() +1 ) + "/"+startDate.getFullYear());

			var End;
			var Start = End = startDate.getFullYear() + "-" + ("0" + (startDate.getMonth() + 1)).slice(-2) + "-" + startDate.getDate();

			//					_deleteAccountContacts: function(accountId, firstname, lastname, position, email, phone )

			oEntry.accountId = customer.getAccountId();
			oEntry.joinedPromotionName = description;
			oEntry.planPromoNum = activityId;
			oEntry.accountPromotionStatus = status;
			oEntry.comment = comment;
			oEntry.lnReasonCode = reasonCode;
			
			oEntry.position = position;
			oEntry.login = login;
			
			//alert(accountid);

			var query = "/rest/callPlanCommon.service.accountSellIn";

			//				sap.ui.commons.MessageBox.alert(oEntry.accountId + "/" + oEntry.joinedPromotionName + "/" + oEntry.planPromoNum + "/" + oEntry.accountPromotionStatus +
			//					"/" + oEntry.comment);

			jQuery.sap.delayedCall(300, this, function() {
				oModel.update(query, oEntry, null,
					function(oData, response) {
						//sap.ui.commons.MessageBox.alert(JSON.stringify(response, null, 4));
						oDataJSONModel.setData(response);
						var obody = oDataJSONModel.getProperty("/body");
						var oXML = new sap.ui.model.xml.XMLModel();
						oXML.setXML(obody);
						//alert(oXML.getProperty("/reasons"));
						/* no Error occured */
						//sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));
						sap.ui.core.BusyIndicator.hide();

						if (oXML.getProperty("/reasons") === null || oXML.getProperty("/reasons") === "") {
							sap.m.MessageToast.show("Status Updated Successfully");

							//return true;
						} else {
							oXML.setXML(obody);
							that.setModel(oXML, "error");
							that._showSiebelError("/reasons");
							//return false;
						}

					},
					function(oError) {
						//	return false;
						sap.ui.core.BusyIndicator.hide();
						sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
					});

				that._getAccountSellins(null,
					Start, End,
					//	that.getModel("salesdrive").getProperty("/StartDate"),
					//	that.getModel("salesdrive").getProperty("/EndDate"),
					that.userid,
					oCustomer.getAccountId());

			});
			sap.ui.core.BusyIndicator.show(100);

		},
		/*
		  Create Agenda Items
		*/
		_updateAccountSellins: function(activityId, status, comment, description, reasonCode, rescheduleFlag, accountid) {
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);

			var that = this;
			var oCustomer = this._getCustomer();

			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var oEntry = {};
			var customer = this._getCustomer();

			var startDate = new Date(oCustomer.getCallDate());
			//	alert(startDate.getDate() + "/" + (startDate.getMonth() +1 ) + "/"+startDate.getFullYear());

			var End;
			var Start = End = startDate.getFullYear() + "-" + ("0" + (startDate.getMonth() + 1)).slice(-2) + "-" + startDate.getDate();

			//					_deleteAccountContacts: function(accountId, firstname, lastname, position, email, phone )

			oEntry.accountId = customer.getAccountId();
			oEntry.joinedPromotionName = description;
			oEntry.planPromoNum = activityId;
			oEntry.accountPromotionStatus = status;
			oEntry.comment = comment;
			oEntry.lnReasonCode = reasonCode;
			//alert(accountid);
			if (accountid) {
				oEntry.accountId = accountid;
			}

			if (rescheduleFlag !== "Y") {
				rescheduleFlag = "N";
			}
			oEntry.rescheduledFlag = rescheduleFlag;

			var query = "/rest/callPlanCommon.service.accountSellIn";

			//				sap.ui.commons.MessageBox.alert(oEntry.accountId + "/" + oEntry.joinedPromotionName + "/" + oEntry.planPromoNum + "/" + oEntry.accountPromotionStatus +
			//					"/" + oEntry.comment);

			jQuery.sap.delayedCall(300, this, function() {
				oModel.update(query, oEntry, null,
					function(oData, response) {
						//sap.ui.commons.MessageBox.alert(JSON.stringify(response, null, 4));
						oDataJSONModel.setData(response);
						var obody = oDataJSONModel.getProperty("/body");
						var oXML = new sap.ui.model.xml.XMLModel();
						oXML.setXML(obody);
						//alert(oXML.getProperty("/reasons"));
						/* no Error occured */
						//sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));
						sap.ui.core.BusyIndicator.hide();

						if (oXML.getProperty("/reasons") === null || oXML.getProperty("/reasons") === "") {
							sap.m.MessageToast.show("Status Updated Successfully");

							//return true;
						} else {
							oXML.setXML(obody);
							that.setModel(oXML, "error");
							that._showSiebelError("/reasons");
							//return false;
						}

					},
					function(oError) {
						//	return false;
						sap.ui.core.BusyIndicator.hide();
						sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
					});

				that._getAccountSellins(null,
					Start, End,
					//	that.getModel("salesdrive").getProperty("/StartDate"),
					//	that.getModel("salesdrive").getProperty("/EndDate"),
					that.userid,
					oCustomer.getAccountId());

			});
			sap.ui.core.BusyIndicator.show(100);

		},

		_getLOV: function(fieldName, parent, modelName, orgId) {
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var today = new Date();

			if (modelName === "") {
				modelName = fieldName;
			}

			var query = "/rest/callPlanCommon.service.lov?type=" + fieldName;
			if (orgId) {
				query = query + "&orgId=" + this.organisation;
			}
			query = query + "&parent=" + parent;

			that.setModel(modelName);

			//	alert(query);	

			oModel.read(
				query,
				null, null, true,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));					
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					var oXML = new sap.ui.model.xml.XMLModel();

					oXML.setXML(obody);
					//alert(fieldName);
					that.setModel(oXML, modelName);

				},
				function(oError) {});
		},

		/*
				get current sales drive data

		*/
		_getSalesDrive: function(view) {
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var today = new Date();

			var query = "/rest/callPlanCommon.service.salesDrive?inputDate=" + today.getFullYear() + "-" + (today.getMonth() + 1) + "-" + today
				.getDate();
			that.setModel("salesdrive");

			//			sap.ui.commons.MessageBox.alert(query);	

			oModel.read(
				query,
				null, null, true,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));					
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					var oXML = new sap.ui.model.xml.XMLModel();

					oXML.setXML(obody);
					//Initial Week Calculation
					var sdStartDate = new Date(oXML.getProperty("/StartDate"));
					var weeksFromStart = that.getWeekDifference(sdStartDate, today) + 1;

					var weekNoModel = new sap.ui.model.json.JSONModel({
						number: weeksFromStart
					});
					that.setModel(weekNoModel, "weekNo");

					that.setModel(oXML, "salesdrive");

					that._getKPI(oXML.getProperty("/StartDate"),
						oXML.getProperty("/EndDate"),
						that.userid,
						oXML.getProperty("/SalesDrive"));

					that.startdate = oXML.getProperty("/StartDate");
					that.enddate = oXML.getProperty("/EndDate");

					//	alert(that.startdate +":"+that.enddate);

					that._getSellIns(view);
					that._getActivations(view);

				},
				function(oError) {});
		},

		_getCalls: function(view, day, dd, mm, yyyy) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			//	sap.ui.commons.MessageBox.alert("day:"+dd+"month:"+mm+"year:"+yyyy);
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();

			var list = view.byId("day" + day + "Title");
			list.setBusy(true);

			this.setModel("day" + day);
			var startDay = dd;
			var endDate = new Date(yyyy, mm - 1, dd);
			endDate.setDate(endDate.getDate() + 1);

			var endDay = parseInt(dd, 10) + 1;

			//		var query = "/rest/commonSiebelWebservice/service/callInbound?startDate=" +
			//			yyyy + "-" + mm + "-" + startDay +
			//			"&endDate=" +
			//			yyyy + "-" + mm + "-" + endDay + "&owner=1-11PHWCK";

			//	sap.ui.commons.MessageBox.alert("user:"+ this.userid);

			// TODO: uncomment when live
			//			var query = "/rest/callPlanCommon.service.callList?startDate=" +
			//				yyyy + "-" + mm + "-" + startDay +
			//				"&endDate=" +
			//				yyyy + "-" + mm + "-" + endDay + "&owner="+this.userid+'"';

			var query = "/rest/callPlanCommon.service.callsInbound?startDate=" +
				yyyy + "-" + mm + "-" + startDay +
				"&endDate=" +
				yyyy + "-" + mm + "-" + startDay + "&owner=" + this.userid;
			//	yyyy + "-" + mm + "-" + startDay + "&owner=RMCTACKE";
			//	endDate.getFullYear() + "-" + (endDate.getMonth() + 1) + "-" + endDate.getDate() + "&owner=RMCTACKE";

			//sap.ui.commons.MessageBox.alert(query);
			//	that.setModel(this._setDummyXML(), "day" + day);

			oModel.read(
				query,
				null, null, true,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					var oXML = new sap.ui.model.xml.XMLModel();

					oXML.setXML(obody);
					//	sap.ui.commons.MessageBox.alert("day:" + day + JSON.stringify(response, null, 4));										
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));					
					//	if (oXML.getProperty("/xsdLocal1:InStoreVisit") !== "") {
					//		sap.ui.commons.MessageBox.alert("here:day"+day);
					//	}
					that.setModel(oXML, "day" + day);
					//	sap.ui.commons.MessageBox.alert("here:day"+day);												
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oXML, null, 4));						
					//	}
					list.setBusy(false);

				},
				function(oError) {
					list.setBusy(false);
					//		sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				});
		},

		_getNotes: function(view, account) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();

			// TODO: hard coded for testing
			//account = "1-PLAI5Q";

			var query = "/rest/callPlanCommon.service.accountNotes?accountId=" + account;

			//	sap.ui.commons.MessageBox.alert(query);
			that.setModel("accountnotes");

			oModel.read(
				query,
				null, null, true,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					var oXML = new sap.ui.model.xml.XMLModel();

					oXML.setXML(obody);
					that.setModel(oXML, "accountnotes");
					//		sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));

					//	list.setBusy(false);
				},
				function(oError) {
					//	list.setBusy(false);
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				});
		},
		/*
		  Update Market Intel
		*/
		_updateNotes: function(comments) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			/*
			accountNumber=16250
			accountStatus=Active
			integrationId= SBLAU16250
			location= LNAU16250
			name= Coogee Bay Hotel
			primaryOrganization= Lion Nathan Australia
			primaryOrganizationId=1-LUF
			accountId=1-2MZTDK
			createdByName= FMIEL
			note= Blah Blah Blah Sheep
			noteType= Note
lnCategory= Note
private=N
			*/
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			var opcdetails = this.getModel("opcdetails");

			var that = this;
			var oCustomer = this._getCustomer();
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var oEntry = {};

			// Create update payload
			oEntry.userId = this.userid;
			oEntry.password = this.password;

			oEntry.accountId = oCustomer.getAccountId();
			oEntry.accountNumber = opcdetails.accountnumber;
			oEntry.integrationId = opcdetails.integrationid;
			oEntry.location = opcdetails.location;
			oEntry.name = opcdetails.name;
			oEntry.primaryOrganization = opcdetails.organisation;
			oEntry.primaryOrganizationId = "1-LUF";
			oEntry.lnCategory = "Note";
			oEntry.createdByName = this.userid;
			oEntry.note = comments;
			oEntry.noteType = "Note";
			oEntry.private = "N";
			oEntry.accountStatus = "Active";

			var query = "/rest/callPlanCommon.service.accountNotes";

			//	sap.ui.commons.MessageBox.alert(activityId+"/"+assessId + "/"+data.retailReviews[0].id +"/"+data.retailReviews[0].value +"/"+data.retailReviews[0].score+"/"+data.retailReviews[0].comments+"/"+data.retailReviews[0].attributeName+"/"+data.retailReviews[0].attribId);

			//			jQuery.sap.delayedCall(300, this, function() {
			oModel.update(query, oEntry, null,
				function(oData, response) {
					//			sap.ui.commons.MessageBox.alert(JSON.stringify(response, null, 4));
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					var oXML = new sap.ui.model.xml.XMLModel();
					//sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));
					/* no Error occured */

					if (oXML.getProperty("/reasons") === "" || oXML.getProperty("/reasons") === null) {
						//return true;
						//	sap.m.MessageToast.show("Market Intel Updated Successfully");
						//that._navigateTo("plan");
						//sap.ui.core.BusyIndicator.hide();
					} else {
						//	sap.ui.core.BusyIndicator.hide();
						//	oXML.setXML(obody);
						//	that.setModel(oXML, "error");
						//	that._showSiebelError("/reasons");
					}
					//	that.setModel(oXML, "error");
				},
				function(oError) {
					//	return false;
					sap.ui.core.BusyIndicator.hide();
					sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				});

			//			});
			//			sap.ui.core.BusyIndicator.show(100);

		},
		_getKamNotes: function(view, account) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();

			// TODO: hard coded for testing
			//account = "1-PLAI5Q";

			var query = "/rest/callPlanCommon.service.accountKAMNotes?accountId=" + account;

			//	sap.ui.commons.MessageBox.alert(query);
			that.setModel("kamnotes");

			oModel.read(
				query,
				null, null, true,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					var oXML = new sap.ui.model.xml.XMLModel();

					oXML.setXML(obody);
					that.setModel(oXML, "kamnotes");
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));

					//	list.setBusy(false);
				},
				function(oError) {
					//	list.setBusy(false);
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				});
		},

		_getOPCNotes: function(view, account) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();

			// TODO: hard coded for testing
			//	account = "1-150URKA";

			var query = "/rest/callPlanCommon.service.accountOPCNotes?accountId=" + account;

			//	sap.ui.commons.MessageBox.alert(query);
			that.setModel("opcnotes");

			oModel.read(
				query,
				null, null, true,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					var oXML = new sap.ui.model.xml.XMLModel();

					oXML.setXML(obody);
					that.setModel(oXML, "opcnotes");

					var opcdetails = {};
					opcdetails.accountnumber = oXML.getProperty("/xsdLocal1:Account/xsdLocal1:AccountNumber");
					opcdetails.integrationid = oXML.getProperty("/xsdLocal1:Account/xsdLocal1:IntegrationId");
					opcdetails.name = oXML.getProperty("/xsdLocal1:Account/xsdLocal1:Name");
					opcdetails.location = oXML.getProperty("/xsdLocal1:Account/xsdLocal1:Location");
					opcdetails.organisation = oXML.getProperty("/xsdLocal1:Account/xsdLocal1:PrimaryOrganization");

					that.setModel(opcdetails, "opcdetails");

					//	sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));

					//	list.setBusy(false);
				},
				function(oError) {
					//	list.setBusy(false);
					//		sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				});
		},

		_createOPCNotes: function(accountId, note, enddate, startdate) {
			/*
		accountId=1-2MZTDK
		accountNumber=16250
		integrationId= SBLAU16250
		location= LNAU16250
		name=Coogee Bay Hotel
		primaryOrganization= Lion Nathan Australia
		lnCategory= PAC Note
		createdByName= FMIEL
		note= Third Blah1234567 Blah12345
		noteType= Note
		private=N
		startDate=12/11/2016
		endDate=12/18/2016
	*/
			//	alert(endDate);
			var customer = this._getCustomer();
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			var that = this;
			var oEntry = {};

			var timeStamp = new Date().getTime();
			var opcdetails = this.getModel("opcdetails");

			//   yyyy/mm/dd
			var today = new Date();

			//			var startDate = ("0" + (today.getMonth() + 1)).slice(-2) + "/" +
			//				("0" + today.getDate()).slice(-2) + "/" +
			//				today.getFullYear();
			var startDate = startdate;
			var endDate = enddate;

			//alert(endDate);

			oEntry.userId = this.userid;
			oEntry.password = this.password;

			oEntry.accountId = accountId;
			oEntry.accountNumber = opcdetails.accountnumber;
			oEntry.integrationId = opcdetails.integrationid;
			oEntry.location = opcdetails.location;
			oEntry.name = opcdetails.name;
			oEntry.primaryOrganization = opcdetails.organisation;
			oEntry.lnCategory = "PAC Note";
			oEntry.createdByName = this.userid;
			oEntry.note = note;
			oEntry.noteType = "Note";
			oEntry.private = "N";
			oEntry.startDate = startDate;
			oEntry.endDate = endDate;

			var oDataJSONModel = new sap.ui.model.json.JSONModel();

			var query = "/rest/callPlanCommon.service.accountOPCNotes";

			//	alert(startDate + "|" + endDate);
			//	sap.ui.commons.MessageBox.alert(query);
			jQuery.sap.delayedCall(500, this, function() {
				oModel.create(query, oEntry, null,
					function(oData, response) {
						//			sap.ui.commons.MessageBox.alert(JSON.stringify(response, null, 4));
						oDataJSONModel.setData(response);
						var obody = oDataJSONModel.getProperty("/body");
						var oXML = new sap.ui.model.xml.XMLModel();
						oXML.setXML(obody);

						//	sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));
						/* no Error occured */
						if (oXML.getProperty("/reasons") === "" || oXML.getProperty("/reasons") === null) {
							that._getOPCNotes(that, customer.getAccountId());
							//sap.ui.getCore().byId("opcnote").getValue(),
							that._createAdhocReport(customer.getActivityId(), "OPC");
							that._createAdhocReport(customer.getActivityId(), "BPC");
							//return true;
						} else {
							oXML.setXML(obody);
							//return false;
						}
						sap.ui.core.BusyIndicator.hide();
						that.setModel(oXML, "error");
					},
					function(oError) {
						sap.ui.core.BusyIndicator.hide();
						//	return false;
						//		sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
					});
			});
			sap.ui.core.BusyIndicator.show(100);

		},

		_updateOPCNotes: function(accountId, note, enddate, noteid, startdate) {
			/*
		accountId=1-2MZTDK
		accountNumber=16250
		integrationId= SBLAU16250
		location= LNAU16250
		name=Coogee Bay Hotel
		primaryOrganization= Lion Nathan Australia
		lnCategory= PAC Note
		createdByName= FMIEL
		note= Third Blah1234567 Blah12345
		noteType= Note
		private=N
		startDate=12/11/2016
		endDate=12/18/2016
	*/
			//	alert(noteid);
			var sServiceUrl = "/destinations/WebMethods";
			var customer = this._getCustomer();
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			var that = this;
			var oEntry = {};

			var timeStamp = new Date().getTime();
			var opcdetails = this.getModel("opcdetails");

			//   yyyy/mm/dd
			var today = new Date();

			//			var startDate = ("0" + (today.getMonth() + 1)).slice(-2) + "/" +
			//				("0" + today.getDate()).slice(-2) + "/" +
			//				today.getFullYear();

			var startDate = startdate;
			var endDate = enddate;

			oEntry.userId = this.userid;
			oEntry.password = this.password;
			//alert(endDate);
			oEntry.noteId = noteid;
			oEntry.accountId = accountId;
			oEntry.accountNumber = opcdetails.accountnumber;
			oEntry.integrationId = opcdetails.integrationid;
			oEntry.location = opcdetails.location;
			oEntry.name = opcdetails.name;
			//	oEntry.primaryOrganization = opcdetails.organisation;
			oEntry.lnCategory = "PAC Note";
			oEntry.createdByName = this.userid;
			oEntry.note = note;
			oEntry.noteType = "Note";
			oEntry.private = "N";
			oEntry.startDate = startDate;
			oEntry.endDate = endDate;

			var oDataJSONModel = new sap.ui.model.json.JSONModel();

			var query = "/rest/callPlanCommon.service.accountOPCNotes";

			//	alert(startDate + "|" + endDate);
			//	sap.ui.commons.MessageBox.alert(query);
			jQuery.sap.delayedCall(500, this, function() {
				oModel.update(query, oEntry, null,
					function(oData, response) {
						//			sap.ui.commons.MessageBox.alert(JSON.stringify(response, null, 4));
						oDataJSONModel.setData(response);
						var obody = oDataJSONModel.getProperty("/body");
						var oXML = new sap.ui.model.xml.XMLModel();
						oXML.setXML(obody);
						//sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));
						/* no Error occured */
						if (oXML.getProperty("/reasons") === "" || oXML.getProperty("/reasons") === null) {
							//return true;
							that._getOPCNotes(that, customer.getAccountId());
							//	that._createAdhocReport(customer.getActivityId(), "OPC");
							//	that._createAdhocReport(customer.getActivityId(), "BPC");
						} else {
							oXML.setXML(obody);
							that.setModel(oXML, "error");
							that._showSiebelError("/reasons");

						}
						sap.ui.core.BusyIndicator.hide();
						that.setModel(oXML, "error");
					},
					function(oError) {
						sap.ui.core.BusyIndicator.hide();
						//	return false;
						//	sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
					});
			});
			sap.ui.core.BusyIndicator.show(100);

		},

		_getSellIns: function(view, startDate) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			//	sap.ui.commons.MessageBox.alert("day:"+dd+"month:"+mm+"year:"+yyyy);
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();

			var list = view.byId("sellinsList");
			list.setBusy(true);

			startDate = new Date(this.startdate);
			var endDate = new Date(this.enddate);
			//var endDate = new Date(startDate);
			//endDate.setDate(endDate.getDate() + 4);
			var query = "/rest/callPlanCommon.service.sellInRead?startDate=" +
				startDate.getFullYear() + "-" + (startDate.getMonth() + 1) + "-" + startDate.getDate() +
				"&endDate=" +
				//	yyyy + "-" + mm + "-" + startDay + "&owner=RMCTACKE";
				endDate.getFullYear() + "-" + (endDate.getMonth() + 1) + "-" + endDate.getDate() + "&owner=" + this.userid;
			//endDate.getFullYear() + "-" + (endDate.getMonth() + 1) + "-" + endDate.getDate() + "&owner=RMCTACKE";				

			//	sap.ui.commons.MessageBox.alert(query);
			that.setModel("sellins");

			oModel.read(
				query,
				null, null, true,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					var oXML = new sap.ui.model.xml.XMLModel();

					oXML.setXML(obody);
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));

					// get each business priortitycall business priorties
					var i = 0;
					var bindingPath;
					var sellinPromotionName = "b";
					var _true = true;

					while (_true) {
						bindingPath = "/accountPromotionList/" + i;
						//console.log(that.getOwnerComponent().getModel("sellins"));

						//DO NOT CALL BUSINESS PRIORITY WHEN NO PROMOTION NAME WAS FOUND
						try {
							sellinPromotionName = oXML.getProperty(bindingPath + "/promotionNumber");
							if (sellinPromotionName !== "" && sellinPromotionName != null) {
								that.getBusinessPriorityData(sellinPromotionName, oXML, bindingPath);
							}
							i = i + 1;
						} catch (e) {
							break;

						}
					}
					oXML.refresh();
					that.setModel(oXML, "sellins");

					list.setBusy(false);
				},
				function(oError) {
					list.setBusy(false);
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				});
		},

		_getActivations: function(view, startDate) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			//	sap.ui.commons.MessageBox.alert("day:"+dd+"month:"+mm+"year:"+yyyy);
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();

			var list = view.byId("activationList");
			list.setBusy(true);

			startDate = new Date(this.startdate);
			var endDate = new Date(this.enddate);

			var query = "/rest/callPlanCommon.service.activateRead?startDate=" +
				startDate.getFullYear() + "-" + (startDate.getMonth() + 1) + "-" + startDate.getDate() +
				"&endDate=" +
				//	yyyy + "-" + mm + "-" + startDay + "&owner=RMCTACKE";
				endDate.getFullYear() + "-" + (endDate.getMonth() + 1) + "-" + endDate.getDate() + "&owner=" + this.userid;

			//	sap.ui.commons.MessageBox.alert(query);
			that.setModel("activations");

			oModel.read(
				query,
				null, null, true,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					var oXML = new sap.ui.model.xml.XMLModel();

					oXML.setXML(obody);
					var i = 0;
					var bindingPath;
					var activationID = "b";
					var _true = true;
					while (_true) {
						bindingPath = "/actionList/" + i;
						//console.log(that.getOwnerComponent().getModel("sellins"));

						//DO NOT CALL BUSINESS PRIORITY WHEN NO PROMOTION NAME WAS FOUND
						try {
							activationID = oXML.getProperty(bindingPath + "/activationID");
							if (activationID !== "" && activationID != null) {
								that.getBusinessPriorityData(activationID, oXML, bindingPath);
							}
							i = i + 1;
						} catch (e) {
							break;

						}
					}
					oXML.refresh();
					that.setModel(oXML, "activations");
					list.setBusy(false);
				},
				function(oError) {
					list.setBusy(false);
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));					
				});
		},

		_setTitles: function(view, operation) {
			jQuery.sap.require("sap.ui.commons.MessageBox");

			var today = new Date();
			var weekdays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
			var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "June",
				"July", "Aug", "Sep", "Oct", "Nov", "Dec"
			];

			var date = this.getModel("CURRENTDATE");
			var day = date.getDay();

		//	var diff = date.getDate() - day + (day == 0 ? -6 : 1); // adjust when day is sunday
		//	Date(date.setDate(diff));
			this.setModel(null, "CURRENTDATE");

			if (operation === "-") {
				var newDate = new Date(date.setDate(date.getDate() - 1));
			} else if (operation === "+") {
				var newDate = new Date(date.setDate(date.getDate() + 1));
			} else {
				var newDate = new Date(date.setDate(date.getDate()));
			}

			if (this.getModel && this.getModel("salesdrive")) {
				var sdStartDate = new Date(this.getModel("salesdrive").getProperty("/StartDate"));
				var sdEndDate = new Date(this.getModel("salesdrive").getProperty("/EndDate"));
				var weeksFromStart = this.getWeekDifference(sdStartDate, date) + 1;
				if (weeksFromStart <= 0 || sdEndDate < date) {
					weeksFromStart = "N.A.";
				}
				this.getModel("weekNo").setProperty("/number", weeksFromStart);
			}

			//			sap.ui.commons.MessageBox.alert("here");

			for (var i = 0; i < 1; i++) {
				var fieldId = "day" + i + "Title";
				var list = view.byId(fieldId);
				var headingDate = date.getDate() + "/" + date.getMonth() + "/" + date.getFullYear();
				var currentDate = new sap.ui.core.CustomData({
					key: "date",
					value: headingDate,
					writeToDom: true
				});
				//alert(date);
				//list.addCustomData(currentDate);
				list.destroyCustomData();
				list.addCustomData(currentDate);
				//	sap.ui.commons.MessageBox.alert("field:" + headingDate);
				list.setHeaderText(weekdays[date.getDay()] + " " + date.getDate() + '-' + monthNames[date.getMonth()]);
				if (today.getDate() === date.getDate() &&
					today.getMonth() === date.getMonth() &&
					today.getYear() === date.getYear()) {
					list.addStyleClass("today");
				} else {
					list.removeStyleClass("today");
				}
				this._getCalls(view, i, (view, "0" + date.getDate()).slice(-2), ("0" + (date.getMonth() + 1)).slice(-2), date.getUTCFullYear());
				//this._setDummyXML(i, date.getDate(), date.getMonth() + 1, date.getUTCFullYear());
				date.setDate(date.getDate() + 1);
			}
			//			this._getActivations(view, newDate);
			//			this._getSellIns(view, newDate);
			//				
			this.setModel(newDate, "CURRENTDATE");
			//sap.ui.commons.MessageBox.alert(JSON.stringify(newDate, null, 4));
		},

		_getMonth: function(month) {

			var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "June",
				"July", "Aug", "Sep", "Oct", "Nov", "Dec"
			];

			return monthNames.indexOf(month);

		},

		_getDay: function(day) {
			var weekdays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

			return weekdays.indexOf(day);
		},

		_setDummyXML: function(day, dd, mm, yyyy) {
			var oXML = '<?xml version="1.0"?>' +
				'<tns:LN_spcCalls_spcInbound_spcWorkflow_Output>' +
				'<xsdLocal1:ListOfLnCallsInbound>' +
				'<xsdLocal1:InStoreVisit>' +
				'</xsdLocal1:InStoreVisit>' +
				'</xsdLocal1:ListOfLnCallsInbound>' +
				'</tns:LN_spcCalls_spcInbound_spcWorkflow_Output>';
			var XML = new sap.ui.model.xml.XMLModel();
			XML.setXML(oXML);
			//sap.ui.commons.MessageBox.alert("day"+XML.getXML());
			//this.setModel(XML, "day" + day);
			return XML;
		},

		onCloseContactDialog: function(ev) {
			this.oContactDialog.close();
		},
		onSaveContactDetails: function() {

			var customer = this._getCustomer();
			var oError = false;
			var phonePrefix = "+61";
			var phone = sap.ui.getCore().byId("phone").getValue();

			if (sap.ui.getCore().byId("firstname").getValue() === "") {
				sap.ui.getCore().byId("firstname").setValueState(sap.ui.core.ValueState.Error);
				oError = true;
			} else {
				sap.ui.getCore().byId("firstname").setValueState(sap.ui.core.ValueState.None);
			}
			if (sap.ui.getCore().byId("lastname").getValue() === "") {
				sap.ui.getCore().byId("lastname").setValueState(sap.ui.core.ValueState.Error);
				oError = true;
			} else {
				sap.ui.getCore().byId("lastname").setValueState(sap.ui.core.ValueState.None);
			}

			if (phone.substr(0, 3) !== phonePrefix) {
				sap.ui.getCore().byId("phone").setValue(phonePrefix + phone);
			}
			//					_putAccountContacts: function(accountId, firstname, lastname, position, email, phone )
			if (oError) {
				sap.m.MessageToast.show("Please Enter all Mandatory Fields");
			} else {
				if (sap.ui.getCore().byId("contactid").getText() !== "") {
					//alert("update:" + sap.ui.getCore().byId("contactid").getText());
					this._updateAccountContacts(sap.ui.getCore().byId("contactid").getText(),
						sap.ui.getCore().byId("firstname").getValue(),
						sap.ui.getCore().byId("lastname").getValue(),
						sap.ui.getCore().byId("position").getValue(),
						sap.ui.getCore().byId("email").getValue(),
						sap.ui.getCore().byId("phone").getValue(),
						sap.ui.getCore().byId("hospitality").getSelected());
				} else {
					this._createAccountContacts(customer.getAccountId(),
						customer.getAccountName(),
						sap.ui.getCore().byId("firstname").getValue(),
						sap.ui.getCore().byId("lastname").getValue(),
						sap.ui.getCore().byId("position").getValue(),
						sap.ui.getCore().byId("email").getValue(),
						sap.ui.getCore().byId("phone").getValue(),
						sap.ui.getCore().byId("hospitality").getSelected());
				}
				this._getAccountContacts(this, customer.getAccountId());
				this.onCloseContactDialog();
			}
		},
		onDeleteContactDetails: function(ev) {
			var nThis = this;
			sap.m.MessageBox.show(
				"Are you sure you want to delete this contact?", {
					icon: sap.m.MessageBox.Icon.WARNING,
					title: "Warning",
					actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
					onClose: function(oAction) {
						if (oAction === sap.m.MessageBox.Action.YES) {
							var customer = nThis._getCustomer();
							nThis._deleteAccountContacts(sap.ui.getCore().byId("firstname").getValue(),
								sap.ui.getCore().byId("lastname").getValue(),
								sap.ui.getCore().byId("personuid").getText());

							nThis._getAccountContacts(nThis, customer.getAccountId());
							nThis.onCloseContactDialog();
						}
					}
				}
			);

			//_deleteAccountContacts: function(accountId, firstname, lastname, position, email, phone )

		},

		onCloseOPCNotesDialog: function(ev) {
			this.oOPCNotesDialog.close();
		},

		onSaveOPCNotes: function(ev) {
			var customer = this._getCustomer();
			var oError = false;

			if (sap.ui.getCore().byId("opcnote").getValue() === "") {
				sap.ui.getCore().byId("opcnote").setValueState(sap.ui.core.ValueState.Error);
				oError = true;
			} else {
				sap.ui.getCore().byId("opcnote").setValueState(sap.ui.core.ValueState.None);
			}
			if (sap.ui.getCore().byId("opcenddate").getValue() === "") {
				sap.ui.getCore().byId("opcenddate").setValueState(sap.ui.core.ValueState.Error);
				oError = true;
			} else {
				sap.ui.getCore().byId("opcenddate").setValueState(sap.ui.core.ValueState.None);
			}

			if (oError) {
				sap.m.MessageToast.show("Please Enter all Mandatory Fields");
			} else {
				//				alert(sap.ui.getCore().byId("opcenddate").getDateValue());
				//	sap.ui.getCore().byId("opcenddate").setValueFormat("yyyyMMdd");
				//alert(sap.ui.getCore().byId("opcenddate").getValue());
				this._createOPCNotes(customer.getAccountId(),
					sap.ui.getCore().byId("opcnote").getValue(),
					sap.ui.getCore().byId("opcenddate").getValue(),
					sap.ui.getCore().byId("opcstartdate").getValue());

				//this._getOPCNotes(this, customer.getAccountId());

				this.onCloseOPCNotesDialog();
			}
		},

		onUpdateOPCNotes: function(ev) {
			var customer = this._getCustomer();
			var oError = false;

			if (sap.ui.getCore().byId("opcnote").getValue() === "") {
				sap.ui.getCore().byId("opcnote").setValueState(sap.ui.core.ValueState.Error);
				oError = true;
			} else {
				sap.ui.getCore().byId("opcnote").setValueState(sap.ui.core.ValueState.None);
			}
			if (sap.ui.getCore().byId("opcenddate").getValue() === "") {
				sap.ui.getCore().byId("opcenddate").setValueState(sap.ui.core.ValueState.Error);
				oError = true;
			} else {
				sap.ui.getCore().byId("opcenddate").setValueState(sap.ui.core.ValueState.None);
			}

			if (oError) {
				sap.m.MessageToast.show("Please Enter all Mandatory Fields");
			} else {
				//				alert(sap.ui.getCore().byId("opcenddate").getDateValue());
				//	sap.ui.getCore().byId("opcenddate").setValueFormat("yyyyMMdd");
				//alert(sap.ui.getCore().byId("opcenddate").getValue());
				this._updateOPCNotes(customer.getAccountId(),
					sap.ui.getCore().byId("opcnote").getValue(),
					sap.ui.getCore().byId("opcenddate").getValue(),
					sap.ui.getCore().byId("opcnoteid").getText(),
					sap.ui.getCore().byId("opcstartdate").getValue());

				//this._getOPCNotes(this, customer.getAccountId());

				this.onCloseOPCNotesDialog();
			}
		},

		onSelectContactDetails: function(ev) {
			//alert("here"+sap.ui.getCore().byId("accountid").getText());
			this.setContact(sap.ui.getCore().byId("personuid").getText());
			this.onCloseContactDialog();
		},

		setContact: function(personuid) {
			var customer = this._getCustomer();
			var modelName = customer.getAccountId() + "CONTACT";
			this.setModel(personuid, modelName);
			$(document).ready(function() {
				$(".accountdetails ul li").removeClass("selected");
				$(".accountdetails ul").find("[data-personuid='" + personuid + "']").addClass("selected");
			});

		},

		getContact: function() {
			var customer = this._getCustomer();
			var modelName = customer.getAccountId() + "CONTACT";
			return this.getModel(modelName);
		},
		setRSM: function(selected) {
			var customer = this._getCustomer();
			var modelName = customer.getAccountId() + "RSM";
			this.setModel(selected, modelName);
		},

		getRSM: function() {
			var customer = this._getCustomer();
			var modelName = customer.getAccountId() + "RSM";
			return this.getModel(modelName);
		},

		onSelfReflection: function() {

			if (!this.oSelfDialog) {
				this.oSelfDialog = sap.ui.xmlfragment("callplanning.view.selfReflection", this);
			}

			sap.ui.getCore().byId("selfreflectionnote").setValue("");

			this.oSelfDialog.open();
		},
		// Close Dialog 
		onCloseSelfReflection: function(ev) {
			jQuery.sap.delayedCall(100, this, function() {
				this.oSelfDialog.close();
				this.getRouter().navTo("main", {}, false);
			});
			sap.ui.core.BusyIndicator.show(10);

		},

		onSaveSelfReflection: function(ev) {
			// save self reflection
			this.onCloseSelfReflection();
		},

		onCloseAgendaItemDialog: function(ev) {
			this.oAddAgendaItemDialog.close();
		},

		onAgendaItemTypeChange: function(ev) {
			//alert("change");	
			var subType = sap.ui.getCore().byId("agendasubtype");
			if (!subType) {
				subType = sap.ui.getCore().byId("changeagendasubtype");
			}

			subType.removeAllItems();
			subType.setValue("");

			switch (ev.getSource().getSelectedKey()) {
				case "1": //VIS
				case "VIS": //VIS
					this.addSubType(subType, "Ambient - Corridor to coolroom,Ambient - Other,Coolroom,Drive,Fridge,VIS Blitz");
					break;
				case "2": //Appointment
					this.addSubType(subType, "General");
					break;
				case "3": //BL Activity
					this.addSubType(subType, "Advocacy,Follow Up,National Activity,Pricing,Promotion,Quality,Sensology,Tasting,Visibility");
					break;
				case "4": //BL Activity
					this.addSubType(subType,
						"Bacardi Trademark,Bombay Spirit,DeKuyper Trademark,Dewars Trademark,Eristoff Spirit,Grey Goose,Bacardi Trademark,Bombay Spirit,DeKuyper Trademark,Dewars Trademark,Eristoff Spirit,Grey Goose"
					);
					break;
				case "5": //BL Activity
					this.addSubType(subType,
						"1st Choice - Beer World Fridge,1st Choice - Pallet,BWS - Fair Go,LL - Beer Prices Hammered,Lead Advertised Line Ambient,Lead Advertised Line Coolroom," +
						"Loose Beer Fridge,Other Adverstised Ambient,Other Adverstised Coolroom,WWL - Prices Knocked Down");
					break;
				case "6": //BL Activity
					this.addSubType(subType, "Letter Generation");
					break;
				case "7": //BL Activity
				case "Customer Opportunity": //BL Activity
					this.addSubType(subType, "Customer Led,Lion Led - CLG/WWG,Lion Led - Category,Lion Led - Centrally,Lion Led - SE");
					break;
				case "8": //BL Activity
					this.addSubType(subType, "DQSSub");
					break;
				case "9": //BL Activity
					this.addSubType(subType, "EDI Action");
					break;
				case "10": //BL Activity
					this.addSubType(subType, "General");
					break;
				case "11": //BL Activity
					this.addSubType(subType, "General");
					break;
				case "12": //BL Activity
				case "Follow Up":
					this.addSubType(subType, "Beer Systems,General,Inform customer,Merchandise,Pricing,Ranging,Sales Operations,Space/Facings");
					break;
				case "13": //BL Activity
					this.addSubType(subType, "Activation,Activation non-core,Bacardi Activation,Bacardi Sell-In,CLG/WWG Price Review," +
						"Core Activation,Customer Investment Plan,Inform customer,Market Insights,Price Review,Pricing,Product Takeover,Product sell-in," +
						"Ranging,Retail Review,Sampling / Tasting,Space/Facings,Tap Review,Tap Review - Non-Achieving");
					break;
				case "14": //LC Communication
				case "15": //LC Deal / Promotion
				case "16": //LC NPD
				case "17": //LC Recall
				case "18": //LC Withdrawal
					this.addSubType(subType, "Inbound Call,Outbound Call");
					break;
				case "19": //Marketplace
					this.addSubType(subType, "Core Activity");
					break;
				case "20": //Signup Agreement
					this.addSubType(subType, "Customer Investment Program,Outlet Activation Discount");
					break;
				case "21": //Telephone Call
					this.addSubType(subType, "Inbound Call,Outbound Call");
					break;
				case "22": //To Do
				case "To Do":
					this.addSubType(subType, "General");
					break;
			}
		},

		onAgendaChangeType: function(element, agendaType) {

			var subType = element;

			subType.removeAllItems();
			subType.setValue("");

			switch (agendaType) {
				case "1": //VIS
				case "VIS": //VIS
					this.addSubType(subType, "Ambient - Corridor to coolroom,Ambient - Other,Coolroom,Drive,Fridge,VIS Blitz");
					break;
				case "2": //Appointment
					this.addSubType(subType, "General");
					break;
				case "3": //BL Activity
					this.addSubType(subType, "Advocacy,Follow Up,National Activity,Pricing,Promotion,Quality,Sensology,Tasting,Visibility");
					break;
				case "4": //BL Activity
					this.addSubType(subType,
						"Bacardi Trademark,Bombay Spirit,DeKuyper Trademark,Dewars Trademark,Eristoff Spirit,Grey Goose,Bacardi Trademark,Bombay Spirit,DeKuyper Trademark,Dewars Trademark,Eristoff Spirit,Grey Goose"
					);
					break;
				case "5": //BL Activity
					this.addSubType(subType,
						"1st Choice - Beer World Fridge,1st Choice - Pallet,BWS - Fair Go,LL - Beer Prices Hammered,Lead Advertised Line Ambient,Lead Advertised Line Coolroom," +
						"Loose Beer Fridge,Other Adverstised Ambient,Other Adverstised Coolroom,WWL - Prices Knocked Down");
					break;
				case "6": //BL Activity
					this.addSubType(subType, "Letter Generation");
					break;
				case "7": //BL Activity
				case "Customer Opportunity": //BL Activity
					this.addSubType(subType, "Customer Led,Lion Led - CLG/WWG,Lion Led - Category,Lion Led - Centrally,Lion Led - SE");
					break;
				case "8": //BL Activity
					this.addSubType(subType, "DQSSub");
					break;
				case "9": //BL Activity
					this.addSubType(subType, "EDI Action");
					break;
				case "10": //BL Activity
					this.addSubType(subType, "General");
					break;
				case "11": //BL Activity
					this.addSubType(subType, "General");
					break;
				case "12": //BL Activity
				case "Follow Up":
					this.addSubType(subType, "Beer Systems,General,Inform customer,Merchandise,Pricing,Ranging,Sales Operations,Space/Facings");
					break;
				case "13": //BL Activity
					this.addSubType(subType, "Activation,Activation non-core,Bacardi Activation,Bacardi Sell-In,CLG/WWG Price Review," +
						"Core Activation,Customer Investment Plan,Inform customer,Market Insights,Price Review,Pricing,Product Takeover,Product sell-in," +
						"Ranging,Retail Review,Sampling / Tasting,Space/Facings,Tap Review,Tap Review - Non-Achieving");
					break;
				case "14": //LC Communication
				case "15": //LC Deal / Promotion
				case "16": //LC NPD
				case "17": //LC Recall
				case "18": //LC Withdrawal
					this.addSubType(subType, "Inbound Call,Outbound Call");
					break;
				case "19": //Marketplace
					this.addSubType(subType, "Core Activity");
					break;
				case "20": //Signup Agreement
					this.addSubType(subType, "Customer Investment Program,Outlet Activation Discount");
					break;
				case "21": //Telephone Call
					this.addSubType(subType, "Inbound Call,Outbound Call");
					break;
				case "22": //To Do
				case "To Do":
					this.addSubType(subType, "General");
					break;
			}
		},

		addSubType: function(combo, text) {
			var array = text.split(',');
			var i = 0;
			for (i = 0; i < array.length; i++) {
				combo.addItem(new sap.ui.core.ListItem({
					key: array[i],
					text: array[i]
				}));
			}

		},

		onSaveAgendaItem: function(ev) {
			var oError = false;
			var customer = this._getCustomer();
			ev.getSource().setEnabled(false);

			if (sap.ui.getCore().byId("agendadescription").getValue() === "") {
				sap.ui.getCore().byId("agendadescription").setValueState(sap.ui.core.ValueState.Error);
				oError = true;
			} else {
				sap.ui.getCore().byId("agendadescription").setValueState(sap.ui.core.ValueState.None);
			}

			if (sap.ui.getCore().byId("agendaenddate").getValue() === "") {
				sap.ui.getCore().byId("agendaenddate").setValueState(sap.ui.core.ValueState.Error);
				oError = true;
			} else {
				sap.ui.getCore().byId("agendaenddate").setValueState(sap.ui.core.ValueState.None);
			}

			if (oError) {
				sap.m.MessageToast.show("Please Enter all Mandatory Fields");
				ev.getSource().setEnabled(true);
			} else {
				//this.onCloseAgendaItemDialog();
				jQuery.sap.delayedCall(1, this, function() {
					this._createAgendaItem(customer.getActivityId(),
						sap.ui.getCore().byId("agendadescription").getValue(),
						sap.ui.getCore().byId("agendaenddate").getValue(),
						sap.ui.getCore().byId("agendatype").getValue(),
						sap.ui.getCore().byId("agendasubtype").getValue());
					//	this.onCloseAgendaItemDialog();   agendatype
				});

			}

		},

		/*
		  get Market Intel
		 */
		_getMarketIntel: function(element, activityId) {
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			//activityId = "1-4C9YYSX"; //-> test data
			//alert(callId);
			var query = "/rest/callPlanCommon.service.reviewMarketIntel?activityId=" + activityId;
			that.setModel("marketintel");

			//	alert(activityId);
			//sap.ui.commons.MessageBox.alert(query);
			element.setBusyIndicatorDelay(10);
			element.setBusy(true);

			oModel.read(
				query,
				null, null, true,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					var oXML = new sap.ui.model.xml.XMLModel();
					//sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));

					oXML.setXML(obody);

					//sap.ui.commons.MessageBox.alert(oXML.getProperty("/xsdLocal4:listOfLnCallPlanGenericAgendaItemsIo/xsdLocal4:agendaItems/xsdLocal4:ownedBy"));
					that.setModel(oXML, "marketintel");
					element.setBusy(false);
				},
				function(oError) {
					element.setBusy(false);
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				});
		},
		/*
		  Update Market Intel
		*/
		_updateMarketIntel: function(activityId, assessId, items, outletActivity) {
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);

			var that = this;
			var oCustomer = this._getCustomer();
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var data = {};

			// Create update payload

			data.activityId = activityId;
			data.assessId = assessId;
			data.marketIntels = items;

			var query = "/rest/callPlanCommon.service.reviewMarketIntel";

			//	sap.ui.commons.MessageBox.alert(activityId+"/"+assessId + "/"+data.retailReviews[0].id +"/"+data.retailReviews[0].value +"/"+data.retailReviews[0].score+"/"+data.retailReviews[0].comments+"/"+data.retailReviews[0].attributeName+"/"+data.retailReviews[0].attribId);

			jQuery.sap.delayedCall(300, this, function() {
				oModel.update(query, data, null,
					function(oData, response) {
						//			sap.ui.commons.MessageBox.alert(JSON.stringify(response, null, 4));
						oDataJSONModel.setData(response);
						var obody = oDataJSONModel.getProperty("/body");
						var oXML = new sap.ui.model.xml.XMLModel();
						//sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));
						/* no Error occured */

						if (oXML.getProperty("/reasons") === "" || oXML.getProperty("/reasons") === null) {
							//return true;
							sap.m.MessageToast.show("Market Intel Updated Successfully");
							that._updateAccountactivations(outletActivity,
								"Achieved",
								"", "", "", "Y");
							//that._navigateTo("plan");
							//sap.ui.core.BusyIndicator.hide();
						} else {
							sap.ui.core.BusyIndicator.hide();
							oXML.setXML(obody);
							that.setModel(oXML, "error");
							that._showSiebelError("/reasons");
						}
						that.setModel(oXML, "error");
					},
					function(oError) {
						//	return false;
						sap.ui.core.BusyIndicator.hide();
						//	sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
					});

			});
			sap.ui.core.BusyIndicator.show(100);

		},
		/*
		  get Agenda Items
		 */
		_getAgendaItems: function(view, callId) {
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			//1-4BETKNQ"  -> test data
			//alert(callId);
			var query = "/rest/callPlanCommon.service.agendaItems?callId=" + callId;
			that.setModel("agendaitems");

			//sap.ui.commons.MessageBox.alert(query);

			oModel.read(
				query,
				null, null, true,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					var oXML = new sap.ui.model.xml.XMLModel();
					//sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));
					sap.ui.core.BusyIndicator.hide();
					oXML.setXML(obody);

					//sap.ui.commons.MessageBox.alert(oXML.getProperty("/xsdLocal4:listOfLnCallPlanGenericAgendaItemsIo/xsdLocal4:agendaItems/xsdLocal4:ownedBy"));
					that.setModel(oXML, "agendaitems");

				},
				function(oError) {

				});
		},

		/*
		  Create Agenda Items
		*/
		_createAgendaItem: function(callId, description, endDate, type, subtype) {
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);

			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var oEntry = {};

			var date = new Date(endDate);

			oEntry.userId = this.userid;
			oEntry.password = this.password;

			oEntry.agendaItemIds = "DUMMY";
			oEntry.callId = callId;
			oEntry.visitId = callId;
			oEntry.type = type;
			oEntry.subType = subtype;
			oEntry.description = description;
			oEntry.plannedCompletion = (date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getFullYear(); //  -> format mm/dd/yyyy

			//			if (that.prevView === 'finish') {
			//				oEntry.status = "Rescheduled - Rep";
			//			}
			var query = "/rest/callPlanCommon.service.agendaItems";

			//	sap.ui.commons.MessageBox.alert(query);

			jQuery.sap.delayedCall(100, this, function() {
				oModel.create(query, oEntry, null,
					function(oData, response) {
						//				sap.ui.commons.MessageBox.alert(JSON.stringify(response, null, 4));
						oDataJSONModel.setData(response);
						var obody = oDataJSONModel.getProperty("/body");
						var oXML = new sap.ui.model.xml.XMLModel();
						oXML.setXML(obody);
						//sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));
						/* no Error occured */
						//	sap.ui.commons.MessageBox.alert(oXML.getProperty("/tns:Result"));

						if (oXML.getProperty("/tns:Result") === "SUCCESS" || !oXML.getProperty("/tns:Result")) {
							//	alert("success");

							if (that.prevView === 'finish') {
								that._updateAgendaItem(oXML.getProperty("/tns:Output_spcRow_spcId"),
									"Rescheduled - Rep",
									"",
									"", "Y");
							}

							that._getAgendaItems(that, callId);

							that.onCloseAgendaItemDialog();
						} else {
							sap.ui.core.BusyIndicator.hide();
							oXML.setXML(obody);
							that.setModel(oXML, "error");
							that._showSiebelError("/tns:Error_spcMessage");
							//return false;
						}
						sap.ui.getCore().byId("addagendasave").setEnabled(true);

					},
					function(oError) {
						sap.ui.core.BusyIndicator.hide();
						//	return false;
						//				sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
					});

			});
			sap.ui.core.BusyIndicator.show(10);

		},

		/*
		  Create Agenda Items
		*/
		_updateAgendaItem: function(activityId, status, comment, reason, rescheduleFlag) {
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);

			var that = this;
			var oCustomer = this._getCustomer();
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var oEntry = {};

			oEntry.activityUID = activityId;
			oEntry.status = status;
			//oEntry.reason = reason;
			oEntry.comment = reason;
			if (rescheduleFlag !== "Y") {
				rescheduleFlag = "N";
			}
			oEntry.rescheduledFlag = rescheduleFlag;

			/*
			    valid values : Achieved, ...
			*/

			//	oEntry.comment = comment;

			var query = "/rest/callPlanCommon.service.activity";

			//	sap.ui.commons.MessageBox.alert(activityId+status);

			jQuery.sap.delayedCall(300, this, function() {
				oModel.update(query, oEntry, null,
					function(oData, response) {
						//			sap.ui.commons.MessageBox.alert(JSON.stringify(response, null, 4));
						oDataJSONModel.setData(response);
						var obody = oDataJSONModel.getProperty("/body");
						var oXML = new sap.ui.model.xml.XMLModel();
						//sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));
						/* no Error occured */
						//sap.ui.core.BusyIndicator.hide();
						oXML.setXML(obody);
						if (oXML.getProperty("/reasons") === "" || oXML.getProperty("/reasons") === null) {
							//return true;

							sap.m.MessageToast.show("Status Updated Successfully");
							that._getAgendaItems(that, oCustomer.getActivityId());

						} else {
							that._getAgendaItems(that, oCustomer.getActivityId());
							sap.ui.core.BusyIndicator.hide();
							oXML.setXML(obody);
							that.setModel(oXML, "error");
							that._showSiebelError("/reasons");
							//return false;
						}
						that.setModel(oXML, "error");
					},
					function(oError) {
						//	return false;
						sap.ui.core.BusyIndicator.hide();
						//	sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
					});

			});
			sap.ui.core.BusyIndicator.show(100);

		},

		/*
		  Create Agenda Items
		*/
		_changeAgendaItem: function(activityId, type, subtype, description, enddate) {
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);

			var that = this;
			var oCustomer = this._getCustomer();
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var oEntry = {};

			oEntry.userId = this.userid;
			oEntry.password = this.password;

			oEntry.activityUID = activityId;
			oEntry.type = type;
			oEntry.subType = subtype;
			oEntry.plannedCompletion = enddate;
			oEntry.description = description;

			//	oEntry.comment = comment;

			var query = "/rest/callPlanCommon.service.agendaItems";

			//	sap.ui.commons.MessageBox.alert(activityId+status);

			jQuery.sap.delayedCall(300, this, function() {
				oModel.update(query, oEntry, null,
					function(oData, response) {
						//			sap.ui.commons.MessageBox.alert(JSON.stringify(response, null, 4));
						oDataJSONModel.setData(response);
						var obody = oDataJSONModel.getProperty("/body");
						var oXML = new sap.ui.model.xml.XMLModel();
						//sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));
						/* no Error occured */
						//sap.ui.core.BusyIndicator.hide();
						oXML.setXML(obody);
						if (oXML.getProperty("/reasons") === "" || oXML.getProperty("/reasons") === null) {
							//return true;
							sap.m.MessageToast.show("Agenda Updated Successfully");
							that._getAgendaItems(that, oCustomer.getActivityId());
							that.onCloseAgenda();

						} else {
							sap.ui.core.BusyIndicator.hide();
							oXML.setXML(obody);
							that.setModel(oXML, "error");
							that._showSiebelError("/reasons");
							//return false;
						}
						that.setModel(oXML, "error");
					},
					function(oError) {
						//	return false;
						sap.ui.core.BusyIndicator.hide();
						//	sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
					});
				//	that._getAgendaItems(that, oCustomer.getActivityId());
			});
			sap.ui.core.BusyIndicator.show(100);

		},

		_deleteAgendaItem: function(callid, itemId) {
			// Update Tap Review
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();

			var query = "/rest/callPlanCommon.service.agendaItems?callId=" + callid + "&agendaItemIds=" + itemId + "&userId=" + this.userid +
				"&password=" + this.password;

			oModel.remove(query, null,
				function(oData, response) {
					//			sap.ui.commons.MessageBox.alert(JSON.stringify(response, null, 4));
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					var oXML = new sap.ui.model.xml.XMLModel();
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));
					/* no Error occured */
					oXML.setXML(obody);
					if (oXML.getProperty("/reasons") === "") {
						sap.m.MessageToast.show("Agenda Item Deleted");
						that._getAgendaItems(that, callid);
						that.onCloseAgenda();
						//return true;
					} else {
						oXML.setXML(obody);
						that.setModel(oXML, "error");
						//return false;
					}

				},
				function(oError) {
					//	return false;
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				});
		},

		/*
		  get Agenda Items
		 */
		_getOutletCheck: function(element, callId) {
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var activity = {};
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			//1-4BETKNQ"  -> test data
			//alert(callId);
			var query = "/rest/callPlanCommon.service.outletChecks?hierarchy=Y&callId=" + callId;
			that.setModel(callId);
			that.setModel("outlet");

			//sap.ui.commons.MessageBox.alert(query);
			if (element !== null) {
				element.setBusyIndicatorDelay(10);
				element.setBusy(true);
			}

			oModel.read(
				query,
				null, null, true,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					var oXML = new sap.ui.model.xml.XMLModel();
					//sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));					

					oXML.setXML(obody);

					var outletCheck = oXML.getProperty("/tns:Review_spcSub_spcTypes");
					var outlets = outletCheck.split(',');

					activity.started = false;
					for (var i = 0; i < outlets.length; i++) {
						if (outlets[i] === "Tap Review") {
							activity.started = true;
							activity.tapreview = true;
							activity.tapreviewid = outlets[i + 1];
						}
						if (outlets[i] === "Retail Review") {
							activity.started = true;
							activity.retailreview = true;
							activity.retailreviewid = outlets[i + 1];
						}
						if (outlets[i] === "Price Review") {
							activity.started = true;
							activity.pricereview = true;
							activity.pricereviewid = outlets[i + 1];
						}
						if (outlets[i] === "Information Collection") {
							activity.started = true;
							activity.marketintel = true;
							activity.marketintelid = outlets[i + 1];
						}

					}
					/*
										if (outletCheck.toLowerCase().indexOf("tap review") !== -1) {
											//	view.byId("tapreview").setVisible(true);
											activity.tapreview = true;
											//	alert(outletCheck);						
										}
										if (outletCheck.toLowerCase().indexOf("retail review") !== -1) {
											//	view.byId("retailreview").setVisible(true);
											activity.retailreview = true;
										}
										if (outletCheck.toLowerCase().indexOf("price review") !== -1) {
											//	view.byId("pricecheck").setVisible(true);
											activity.pricecheck = true;
										}
										if (outletCheck.toLowerCase().indexOf("information collection") !== -1) {
											//	view.byId("pricecheck").setVisible(true);
											activity.marketintel = true;
										}
										if (activity.tapreview || activity.retailreview || activity.pricecheck) {
											that.setModel(activity, callId);
										}
					*/
					//sap.ui.core.BusyIndicator.hide();
					if (element !== null) {
						element.setBusy(false);
					}

					//sap.ui.commons.MessageBox.alert(oXML.getProperty("/xsdLocal4:listOfLnCallPlanGenericAgendaItemsIo/xsdLocal4:agendaItems/xsdLocal4:ownedBy"));

					//that.setModel(activity, callId);
					that.setModel(oXML, "outlet");
					//sap.ui.commons.MessageBox.alert(JSON.stringify(oXML.getXML(), null, 4));					

				},
				function(oError) {
					if (element !== null) {
						element.setBusy(false);
					}
					sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				});
		},

		_getRetailReviewData: function(element, accountId, callId, clgwwgFlag) {
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();

			if (!clgwwgFlag) {
				clgwwgFlag = "N";
			}

			//accountId="1-2N2UE5";
			//callId="1-4J26GMM";
			var query = "/rest/callPlanCommon.service.reviewRetail?accountId=" + accountId + "&callId=" + callId + "&clgwwgFlag=" + clgwwgFlag;
			that.setModel("RetailReview");

			element.setBusyIndicatorDelay(10);
			element.setBusy(true);

			oModel.read(
				query,
				null, null, true,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					var oXML = new sap.ui.model.xml.XMLModel();
					oXML.setXML(obody);
					that.setModel(oXML, "RetailReview");
					element.setBusy(false);
					//		sap.ui.commons.MessageBox.alert(oXML.getProperty("/retailReview:listOfLnCallPlanRetailReviewFrameworkThinIo/retailReview:account/retailReview:id"));
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oXML.getXML(), null, 4));	
				},
				function(oError) {
					element.setBusy(false);
				});
		},
		_setRetailReviewData: function(view, accountId, assessId, items, acctivityId, clgwwgFlag) {
			// Update Retail Review
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();

			var data = {};

			if (!clgwwgFlag) {
				clgwwgFlag = "N";
			}
			// Create update payload
			data.userId = this.userid;
			data.password = this.password;

			data.accountId = accountId;
			data.assessId = assessId;
			data.clgwwgFlag = clgwwgFlag;
			data.retailReviews = items;
			//alert("update - "+ acctivityId);

			var query = "/rest/callPlanCommon.service.reviewRetail";
			oModel.update(query, data, null,
				function(oData, response) {
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					var oXML = new sap.ui.model.xml.XMLModel();
					oXML.setXML(obody);
					//					sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));
					/* no Error occured */
					if (oXML.getProperty("/reasons") === "" || oXML.getProperty("/reasons") === null) {
						// Navigate to Outlet Check.
						that._updateAccountactivations(acctivityId,
							"Achieved",
							"", "", "", "Y");
						//that._onProcessFlowPress(that.prevView);
						//that._navigateTo("plan");
					} else {

						that.setModel(oXML, "error");
						that._showSiebelError("/reasons");
					}
				},
				function(oError) {
					that._handleUnknownError(oError);
				});
		},

		_getTapReviewData: function(element, accountId, callId) {
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();

			//accountId="1-2N361U";
			//callId="1-4BETNAW";
			sap.ui.core.BusyIndicator.show(100);
			var query = "/rest/callPlanCommon.service.reviewTap?accountId=" + accountId + "&callId=" + callId;
			that.setModel("TapReview");

			if (element !== null) {
				element.setBusyIndicatorDelay(10);
				element.setBusy(true);
			} else {
				sap.ui.core.BusyIndicator.show(100);
			}

			oModel.read(
				query,
				null, null, false,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					var oXML = new sap.ui.model.xml.XMLModel();
					oXML.setXML(obody);

					that.setModel(oXML, "TapReview");
					if (element !== null) {
						element.setBusy(false);
					} else {
						sap.ui.core.BusyIndicator.hide();
					}
					//		sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));
				},
				function(oError) {
					if (element !== null) {
						element.setBusy(false);
					} else {
						sap.ui.core.BusyIndicator.hide();
					}
					sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				});
		},
		_getTapData: function(element, accountId) {
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();

			//	alert(accountId);
			//accountId="1-2N361U";
			//callId="1-4BETNAW";
			sap.ui.core.BusyIndicator.show(100);
			var query = "/rest/callPlanCommon.service.tapData?accountId=" + accountId;
			that.setModel("TapData");

			if (element !== null) {
				element.setBusyIndicatorDelay(10);
				element.setBusy(true);
			} else {
				sap.ui.core.BusyIndicator.show(100);
			}

			oModel.read(
				query,
				null, null, true,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					var oXML = new sap.ui.model.xml.XMLModel();
					oXML.setXML(obody);

					that.setModel(oXML, "TapData");
					if (element !== null) {
						element.setBusy(false);
					} else {
						sap.ui.core.BusyIndicator.hide();
					}
					//		sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));
				},
				function(oError) {
					if (element !== null) {
						element.setBusy(false);
					} else {
						sap.ui.core.BusyIndicator.hide();
					}
					sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				});
		},

		handleTapSearch: function(oEvent) {

			var sValue = oEvent.getParameter("value");

			var oFilterName = new sap.ui.model.Filter("xsdLocal1:Abbreviation", sap.ui.model.FilterOperator.Contains, sValue);
			var oFilterAccount = new sap.ui.model.Filter("xsdLocal1:Name", sap.ui.model.FilterOperator.Contains, sValue);
			var oFilter = new sap.ui.model.Filter({
				filters: [oFilterName, oFilterAccount],
				and: false
			});
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		},

		handleTapClose: function(oEvent) {

			var aContexts = oEvent.getParameter("selectedContexts");
			var sel = oEvent.getParameter("selectedItem").getCells();
			//  invisible text
			//	sap.m.MessageToast.show("Adding CAll"+sel[1].getText());
			if (aContexts && aContexts.length) {
				//	alert(this.tap+":"+sel[0].getTitle());
				this.tap.setValue(sel[0].getTitle());
			}
			oEvent.getSource().getBinding("items").filter([]);
		},

		_setTapReviewData: function(view, accountId, items, glassware, activityId, navigate, comments) {
			// Update Tap Review
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var oCustomer = this._getCustomer();
			var callId = oCustomer.getActivityId();

			var data = {};

			// Create update payload

			data.accountId = accountId;

			//		alert(accountId);

			//	data.userId = this.userid;
			//	data.password = this.password;				

			data.glassware1 = glassware.glassware1;
			data.glassware2 = glassware.glassware2;
			data.glassware3 = glassware.glassware3;
			data.glassware4 = glassware.glassware4;
			data.glassware5 = glassware.glassware5;
			data.glassware6 = glassware.glassware6;
			data.glassware7 = glassware.glassware7;
			data.glassware8 = glassware.glassware8;

			data.tapReviews = items;

			var query = "/rest/callPlanCommon.service.reviewTap";
			oModel.update(query, data, null,
				function(oData, response) {
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					var oXML = new sap.ui.model.xml.XMLModel();
					oXML.setXML(obody);
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));
					/* no Error occured */
					if (oXML.getProperty("/tns:Result") === "SUCCESS" || oXML.getProperty("/reasons").indexOf("Activity has been generated ") !== -1) {
						if (activityId !== null) {
							that._updateAccountactivations(activityId,
								"Achieved",
								"", comments, "");
							if (navigate) {
								that._onProcessFlowPress(that.prevView);
							}
							sap.m.MessageToast.show("Tap Review Updated");
							that._getTapReviewData(null, accountId, callId);
							if (oXML.getProperty("/reasons").indexOf("Activity has been generated ") !== -1) {
								that.setModel(oXML, "info");
								that._showSiebelInfo("/reasons");
							}
						}
					} else {
						oXML.setXML(obody);
						that.setModel(oXML, "error");
						that._showSiebelError("/reasons");
					}
				},
				function(oError) {
					that._handleUnknownError(oError);
				});
		},
		_deleteTapReviewData: function(itemId) {
			// Update Tap Review
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			//alert(itemId);
			var query = "/rest/callPlanCommon.service.reviewTap?itemId=" + itemId;
			oModel.remove(query, null,
				function(oData, response) {
					//			sap.ui.commons.MessageBox.alert(JSON.stringify(response, null, 4));
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					var oXML = new sap.ui.model.xml.XMLModel();
					sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));
					/* no Error occured */
					oXML.setXML(obody);
					if (oXML.getProperty("/reasons") === "") {
						sap.m.MessageToast.show("Tap Item Deleted");
						//return true;
					} else {
						oXML.setXML(obody);
						that.setModel(oXML, "error");
						that._showSiebelError("/reasons");
						sap.ui.core.BusyIndicator.hide();
						//return false;
					}

				},
				function(oError) {
					//	return false;
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				});
		},

		_getPriceReviewData: function(element, accountId, callId, clgwwgFlag) {
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();

			if (!clgwwgFlag) {
				clgwwgFlag = "N";
			}

			var query = "/rest/callPlanCommon.service.reviewPrice?accountId=" + accountId + "&callId=" + callId + "&clgwwgFlag=" + clgwwgFlag;
			that.setModel("PriceReview");
			//	alert(query);

			element.setBusyIndicatorDelay(10);
			element.setBusy(true);

			oModel.read(
				query,
				null, null, true,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					var oXML = new sap.ui.model.xml.XMLModel();
					oXML.setXML(obody);
					that.setModel(oXML, "PriceReview");
					element.setBusy(false);
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));
				},
				function(oError) {
					//		sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
					element.setBusy(false);
				});
		},
		_setPriceReviewData: function(view, accountId, callId, assessId, items, acctivityId, clgwwgFlag) {

			// Update Price Review
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var data = {};

			if (!clgwwgFlag) {
				clgwwgFlag = "N";
			}
			// Create update payload

			data.clgwwgFlag = clgwwgFlag;
			data.accountId = accountId;
			data.assessId = assessId;
			data.callId = callId;
			data.priceReviews = items;

			var query = "/rest/callPlanCommon.service.reviewPrice";
			oModel.update(query, data, null,
				function(oData, response) {
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					var oXML = new sap.ui.model.xml.XMLModel();
					oXML.setXML(obody);
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));
					/* no Error occured */
					if (oXML.getProperty("/reasons") === "" || oXML.getProperty("/reasons") === null) {
						// Navigate to Outlet Check.
						//alert("update ok");
						that._updateAccountactivations(acctivityId,
							"Achieved",
							"", "", "", "Y");
					} else {
						oXML.setXML(obody);
						that.setModel(oXML, "error");
						that._showSiebelError("/reasons");
						sap.ui.core.BusyIndicator.hide();
					}
				},
				function(oError) {
					sap.ui.core.BusyIndicator.hide();
					that._handleUnknownError(oError);
				});
		},

		handleAccountSearch: function(oEvent) {

			var sValue = oEvent.getParameter("value");

			var oFilterName = new sap.ui.model.Filter("xsdLocal1:Name", sap.ui.model.FilterOperator.Contains, sValue);
			var oFilterAccount = new sap.ui.model.Filter("xsdLocal1:AccountNumber", sap.ui.model.FilterOperator.Contains, sValue);
			var oFilter = new sap.ui.model.Filter({
				filters: [oFilterName, oFilterAccount],
				and: false
			});
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		},
		handleEmployeeSearch: function(oEvent) {

			var sValue = oEvent.getParameter("value");

			var oFilterName = new sap.ui.model.Filter("xsdLocal1:Name", sap.ui.model.FilterOperator.Contains, sValue);
			var oFilterAccount = new sap.ui.model.Filter("xsdLocal1:AccountNumber", sap.ui.model.FilterOperator.Contains, sValue);
			var oFilter = new sap.ui.model.Filter({
				filters: [oFilterName, oFilterAccount],
				and: false
			});
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		},
		onReallocateCallCancel: function(ev) {
			var that = this;
			var oCustomer = this._getCustomer();

			var startDate = new Date(oCustomer.getCallDate());
			//	alert(startDate.getDate() + "/" + (startDate.getMonth() +1 ) + "/"+startDate.getFullYear());

			var End;
			var Start = End = startDate.getFullYear() + "-" + ("0" + (startDate.getMonth() + 1)).slice(-2) + "-" + startDate.getDate();

			jQuery.sap.delayedCall(100, this, function() {
				that._getAccountSellins(null,
					Start, End,
					//	that.getModel("salesdrive").getProperty("/StartDate"),
					//	that.getModel("salesdrive").getProperty("/EndDate"),
					that.userid,
					oCustomer.getAccountId());

				that._getAccountActivations(null,
					Start, End,
					//	that.getModel("salesdrive").getProperty("/StartDate"),
					//	that.getModel("salesdrive").getProperty("/EndDate"),
					that.userid,
					oCustomer.getAccountId());

				that._getAgendaItems(that, oCustomer.getActivityId());

				this.oReallocateDialog.close();
				sap.ui.core.BusyIndicator.hide();
			});
			sap.ui.core.BusyIndicator.show(100);
		},

		onReallocateDialog: function(customObject) {
			var status = "";
			var activityId = "";
			var description = "";
			var type = "";

			this.customObject = customObject;

			for (var i = 0; i < this.customObject.length; i++) {

				//alert(this.customObject[i].getValue());
				if (this.customObject[i].getKey() === "status") {
					status = this.customObject[i].getValue();
				}
				if (this.customObject[i].getKey() === "activityid") {
					activityId = this.customObject[i].getValue();
				}
				if (this.customObject[i].getKey() === "promoname") {
					description = this.customObject[i].getValue();
				}
				if (this.customObject[i].getKey() === "type") {
					type = this.customObject[i].getValue();
				}
			}

			if (!this.oReallocateDialog) {
				this.oReallocateDialog = sap.ui.xmlfragment("callplanning.view.reallocateCall", this); //	this.oContactDialog.setModel(this.getOwnerComponent().getModel("sellins"), "sellins");
			}

			this.oReallocateDialog.setModel(this.getModel("LN_ACCNT_PROMO_REASON_CD"), "LN_ACCNT_PROMO_REASON_CD");
			//LN_ACCNT_PROMO_REASON_CD
			sap.ui.getCore().byId("callaccountnumberL").setVisible(false);
			sap.ui.getCore().byId("callaccountnumber").setVisible(false);
			sap.ui.getCore().byId("callaccountnameL").setVisible(false);
			sap.ui.getCore().byId("callaccountname").setVisible(false);
			sap.ui.getCore().byId("updatestatusreason").setVisible(true);
			sap.ui.getCore().byId("callreallocatersmL").setVisible(false);
			sap.ui.getCore().byId("callreallocatersm").setVisible(false);
			sap.ui.getCore().byId("callreallocatersmC").setVisible(false);

			//	alert(status);
			if (status === "Reallocate") {
				sap.ui.getCore().byId("callaccountnumberL").setVisible(true);
				sap.ui.getCore().byId("callaccountnumber").setVisible(true);
				sap.ui.getCore().byId("callaccountnameL").setVisible(true);
				sap.ui.getCore().byId("callaccountname").setVisible(true);
				sap.ui.getCore().byId("updatestatusreason").setVisible(true);
				sap.ui.getCore().byId("callreallocatersmL").setVisible(true);
				sap.ui.getCore().byId("callreallocatersm").setVisible(true);
				sap.ui.getCore().byId("callreallocatersmC").setVisible(true);

			}
			sap.ui.getCore().byId("callaccountnumber").setValue();
			sap.ui.getCore().byId("callaccountname").setValue();
			sap.ui.getCore().byId("updatestatusreason").setValue();
			sap.ui.getCore().byId("updatestatuscomment").setValue();

			this.oReallocateDialog.setModel(this.getModel("accountteam"), "accountteam");

			//
			this.oReallocateDialog.open();
		},

		onReallocateCallSave: function() {
			var oCustomer = this._getCustomer();
			//var accountId = sap.ui.getCore().byId("callaccountid").getText();
			var status = "";
			var activityId = "";
			var description = "";
			var type = "";

			for (var i = 0; i < this.customObject.length; i++) {
				//alert(this.customObject[i].getValue());
				if (this.customObject[i].getKey() === "status") {
					status = this.customObject[i].getValue();
				}
				if (this.customObject[i].getKey() === "activityid") {
					activityId = this.customObject[i].getValue();
				}
				if (this.customObject[i].getKey() === "promoname") {
					description = this.customObject[i].getValue();
				}
				if (this.customObject[i].getKey() === "type") {
					type = this.customObject[i].getValue();
				}
			}

			// update status - sellins
			if (type === "sellins") {
				//alert("update sellins"+sap.ui.getCore().byId("callaccountid").getText());
				if (status === "Reallocate") {
					this._updateAccountSellins(activityId,
						"Reallocate",
						sap.ui.getCore().byId("updatestatuscomment").getValue(),
						description,
						sap.ui.getCore().byId("updatestatusreason").getSelectedKey(),
						"",
						"");

					if (sap.ui.getCore().byId("callreallocatersmC").getSelected()) {
						this._updateAccountSellinsRSM(activityId,
							"Reallocated",
							sap.ui.getCore().byId("updatestatuscomment").getValue(),
							description,
							sap.ui.getCore().byId("updatestatusreason").getSelectedKey(),
							sap.ui.getCore().byId("reallocateposition").getText(),
							sap.ui.getCore().byId("reallocateassignedposition").getText());
					} else {
						this._updateAccountSellins(activityId,
							"Reallocated",
							sap.ui.getCore().byId("updatestatuscomment").getValue(),
							description,
							sap.ui.getCore().byId("updatestatusreason").getSelectedKey(),
							"",
							sap.ui.getCore().byId("callaccountid").getText());
					}
				} else {
					this._updateAccountSellins(activityId,
						status,
						sap.ui.getCore().byId("updatestatuscomment").getValue(),
						description,
						sap.ui.getCore().byId("updatestatusreason").getSelectedKey(),
						"",
						"");
					//
				}
			} else if (type === "agenda") {
				this._updateAgendaItem(activityId,
					status,
					sap.ui.getCore().byId("updatestatuscomment").getValue(),
					sap.ui.getCore().byId("updatestatusreason").getSelectedKey());
			} else if (type === "activate") {

				this._updateAccountactivations(activityId,
					status,
					sap.ui.getCore().byId("updatestatusreason").getSelectedKey());
			}

			this.oReallocateDialog.close();
		},
		onEmployeeHelpRequest: function() {

			if (!this.oEmployeeHelpDialog) {
				// create dialog via fragment factory
				this.oEmployeeHelpDialog = sap.ui.xmlfragment("callplanning.view.employeeHelp", this);
			}
			// clear the old search filter
			this.oEmployeeHelpDialog.setModel(this.getModel("accountteamall"), "accountteamall");
			//		this.oAccountHelpDialog.getBinding("items").filter([]);
			this.oEmployeeHelpDialog.open();
		},
		onAccountHelpRequest: function() {

			if (!this.oAccountHelpDialog) {
				// create dialog via fragment factory
				this.oAccountHelpDialog = sap.ui.xmlfragment("callplanning.view.accountHelp", this);
				this.oAccountHelpDialog.setModel(this.getModel("accountlist"), "accountlist");
			}
			// clear the old search filter
			this.oAccountHelpDialog.setModel(this.getModel("accountlist"), "accountlist");
			//		this.oAccountHelpDialog.getBinding("items").filter([]);
			this.oAccountHelpDialog.open();
		},

		handleAccountClose: function(oEvent) {

			var aContexts = oEvent.getParameter("selectedContexts");
			var sel = oEvent.getParameter("selectedItem").getCells();
			//  invisible text
			//	sap.m.MessageToast.show("Adding CAll"+sel[1].getText());
			if (aContexts && aContexts.length) {
				sap.ui.getCore().byId("callaccountnumber").setValue(sel[0].getTitle());
				sap.ui.getCore().byId("callaccountname").setValue(sel[0].getText());
				sap.ui.getCore().byId("callaccountid").setText(sel[1].getText());
				//alert("accountId"+sel[1].getText());
			}
			oEvent.getSource().getBinding("items").filter([]);
		},

		handleEmployeeClose: function(oEvent) {

			var aContexts = oEvent.getParameter("selectedContexts");
			var sel = oEvent.getParameter("selectedItem").getCells();
			//  invisible text
			//	sap.m.MessageToast.show("Adding CAll"+sel[1].getText()+sel[2].getText());
			if (aContexts && aContexts.length) {
				sap.ui.getCore().byId("callreallocatersm").setValue(sel[0].getTitle());
				sap.ui.getCore().byId("reallocateposition").setValue(sel[1].getText());
				sap.ui.getCore().byId("reallocateassignedposition").setValue(sel[2].getText());				
			//	sap.ui.getCore().byId("callaccountid").setText(sel[1].getText());
				//alert("accountId"+sel[1].getText());
			}
			oEvent.getSource().getBinding("items").filter([]);
		},
		onContactHelpRequest: function() {

			if (!this.oContactHelpDialog) {
				// create dialog via fragment factory
				this.oContactHelpDialog = sap.ui.xmlfragment("callplanning.view.contactHelp", this);
				this.oContactHelpDialog.setModel(this.getModel("accountlist"), "accountlist");
			}
			// clear the old search filter
			this.oContactHelpDialog.setModel(this.getModel("accountcontact"), "accountcontact");
			//		this.oAccountHelpDialog.getBinding("items").filter([]);
			this.oContactHelpDialog.open();
		},
		handleContactClose: function(oEvent) {

			var aContexts = oEvent.getParameter("selectedContexts");
			var sel = oEvent.getParameter("selectedItem").getCells();
			//  invisible text
			//	sap.m.MessageToast.show("Adding CAll"+sel[1].getText());
			if (aContexts && aContexts.length) {
				//	sap.ui.getCore().byId("callaccountnumber").setValue(sel[0].getTitle());
				sap.ui.getCore().byId("d_email_to").setValue(sel[0].getText());
			}
			oEvent.getSource().getBinding("items").filter([]);
		},

		handleContactSearch: function(oEvent) {

			var sValue = oEvent.getParameter("value");

			var oFilterEmail = new sap.ui.model.Filter("xsdLocal1:EmailAddress", sap.ui.model.FilterOperator.Contains, sValue);
			var oFilterFirstName = new sap.ui.model.Filter("xsdLocal1:FirstName", sap.ui.model.FilterOperator.Contains, sValue);
			var oFilterLastName = new sap.ui.model.Filter("xsdLocal1:LastName", sap.ui.model.FilterOperator.Contains, sValue);
			var oFilter = new sap.ui.model.Filter({
				filters: [oFilterEmail, oFilterFirstName, oFilterLastName],
				and: false
			});
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		},
		onCloseEmailDialog: function(oEvent) {

			this.oEmailReports.close();
		},

		onEmailReport: function(ev) {
			var list = sap.ui.getCore().byId("emailreportlist");
			var customer = this._getCustomer();
			var emailTo = sap.ui.getCore().byId("d_email_to").getValue();
			var emailSubject = sap.ui.getCore().byId("d_email_subject").getValue();

			var emailFrom = this.email;
			var emailCC = sap.ui.getCore().byId("d_email_cc").getValue();
			//var emailCC = "SHROSE";

			var emailBody = sap.ui.getCore().byId("d_email_body").getValue();

			var reports = [];

			var items = list.getItems();
			//alert(items.length);
			for (var i = 0; i < items.length; i++) {
				if (items[i].getSelected()) {
					//		alert(items[i].getInfo());
					reports.push({
						"report": items[i].getInfo()
					});

				}
			}
			jQuery.sap.delayedCall(200, this, function() {
				this._emailReports(customer.getActivityId(),
					customer.getAccountNumber(),
					emailTo,
					emailFrom,
					emailCC,
					emailSubject,
					emailBody,
					reports);
			});
			this.onCloseEmailDialog();
			sap.ui.core.BusyIndicator.show(100);
			sap.m.MessageToast.show("Your email is being generated");

		},
		_getAgreementPDF: function(agreementNumber, agreementName) {

			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();

			//agreementName = "RAP Promo F17 NSW - 44386";

			//accountId="1-2N361U";
			//callId="1-4BETNAW";
			//	agreementNumber='1-6628657384';
			sap.ui.core.BusyIndicator.show(100);
			var query = "/rest/callPlanCommon.service.agreementContract?agreementNumber=" + agreementNumber;
			//	alert(query);
			oModel.read(
				query,
				null, null, true,
				function(oData, response) {

					sap.ui.core.BusyIndicator.hide();
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					var oXML = new sap.ui.model.xml.XMLModel();
					oXML.setXML(obody);
					//		sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));
					var pdfString = oXML.getProperty(
						"/xsdLocal1:ServiceAgreement/xsdLocal1:ListOfServiceAgreement_AgreementAttachments/xsdLocal1:ServiceAgreement_AgreementAttachments/xsdLocal1:ActivityFileBuffer"
					);
					var fileExt = oXML.getProperty(
						"/xsdLocal1:ServiceAgreement/xsdLocal1:ListOfServiceAgreement_AgreementAttachments/xsdLocal1:ServiceAgreement_AgreementAttachments/xsdLocal1:ActivityFileExt"
					);
					var fileName = oXML.getProperty(
						"/xsdLocal1:ServiceAgreement/xsdLocal1:ListOfServiceAgreement_AgreementAttachments/xsdLocal1:ServiceAgreement_AgreementAttachments/xsdLocal1:ActivityFileName"
					);

					//	alert(pdfString);
					if (pdfString) {
						var content = pdfString.slice(pdfString.indexOf("base64") + 7);
						//content = "data:ms-powerpoint;base64," + content;
						//	alert(content);
						var blob = that.b64toBlob(content, "application/vnd.openxmlformats-officedocument.presentationml.presentation", 512);
						//	alert(blob);
						var blobUrl = URL.createObjectURL(blob);
						//						window.open(blobUrl);
						download(blob, fileName + "." + fileExt);

					} else {
						that._showInfo("No Agreement Found");
						//sap.ui.commons.MessageBox.alert("No Agreement Found");
					}

				},
				function(oError) {
					sap.ui.core.BusyIndicator.hide();
					sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				});
		},

		/*
		    Add New Tap 
		*/
		onAddTapSave: function(ev) {
			//call set tap review
			var customer = this._getCustomer();
			var items = [];
			var glassware = {};
			var main = "";
			glassware.glassware1 = "";
			glassware.glassware2 = "";
			glassware.glassware3 = "";
			glassware.glassware4 = "";
			glassware.glassware5 = "";
			glassware.glassware6 = "";
			glassware.glassware7 = "";
			glassware.glassware8 = "";

			if (sap.ui.getCore().byId("addtapmainbar").getSelected()) {
				main = "Y";
			} else {
				main = "N";
			}

			items.push({
				"id": "DUMMY",
				"barName": sap.ui.getCore().byId("addtapbarname").getValue(),
				"barType": sap.ui.getCore().byId("addtapbartype").getValue(),
				"mainBar": main,
				"bankFont": sap.ui.getCore().byId("addtapbank").getValue(),
				"tapDecal": sap.ui.getCore().byId("addtapdecal").getValue(),

				"tap1": sap.ui.getCore().byId("addtap1").getValue(),
				"tap2": sap.ui.getCore().byId("addtap2").getValue(),
				"tap3": sap.ui.getCore().byId("addtap3").getValue(),
				"tap4": sap.ui.getCore().byId("addtap4").getValue(),
				"tap5": sap.ui.getCore().byId("addtap5").getValue(),
				"tap6": sap.ui.getCore().byId("addtap6").getValue(),
				"tap7": sap.ui.getCore().byId("addtap7").getValue(),
				"tap8": sap.ui.getCore().byId("addtap8").getValue()
			});

			this._setTapReviewData(this, customer.getAccountId(), items, glassware, null);
			this._getTapReviewData(null, customer.getAccountId(), customer.getActivityId());

			//this._getTapData(null, customer.getAccountId());

			this.oAddTap.close();
		},
		// TODO: 
		onAddTapClose: function(ev) {
			this.oAddTap.close();
		},
		/*
		   return the week number
		*/
		getWeekNumber: function(d) {
			// Copy date so don't modify original
			d = new Date(d);
			d.setHours(0, 0, 0, 0);
			// Set to nearest Thursday: current date + 4 - current day number
			// Make Sunday's day number 7
			d.setDate(d.getDate() + 4 - (d.getDay() || 7));
			// Get first day of year
			var yearStart = new Date(d.getFullYear(), 0, 1);
			// Calculate full weeks to nearest Thursday
			var weekNo = Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
			// Return array of year and week number
			return weekNo;
		},

		/*
		   return the week difference. 
		   Cannot use weeknumber of the year as the dates can be in different years
		*/
		getWeekDifference: function(start, end) {
			return Math.round((end - start) / 604800000);
		},

		/*
		  Generate - OPC Report
		
		
		*/

		_createAdhocReport: function(callId, reportType) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);

			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var oEntry = {};

			oEntry.callId = callId;
			oEntry.adhocReportType = reportType;

			var query = "/rest/callPlanCommon.service.adhocReport";

			//	sap.ui.commons.MessageBox.alert(query);

			oModel.create(query, oEntry, null,
				function(oData, response) {
					//			sap.ui.commons.MessageBox.alert(JSON.stringify(response, null, 4));
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					var oXML = new sap.ui.model.xml.XMLModel();
					oXML.setXML(obody);

					//	sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));

				},
				function(oError) {

					//sap.ui.core.BusyIndicator.hide();
					//	return false;
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				});

		},
		// update agenda item	
		onSaveAgenda: function(ev) {
			// Save agenda item (4 fields - type, subtype, description, enddate)
			//	_changeAgendaItem: function(activityId, type, subtype,description,enddate) {
			this._changeAgendaItem(sap.ui.getCore().byId("changeagendaactivityid").getText(),
				sap.ui.getCore().byId("changeagendatype").getValue(),
				sap.ui.getCore().byId("changeagendasubtype").getValue(),
				sap.ui.getCore().byId("changeagendadescription").getValue(),
				sap.ui.getCore().byId("changeagendaenddate").getValue()

			);

		},
		// delete an agenda item	
		onDeleteAgenda: function(ev) {
			//	_deleteAgendaItem: function(callid, itemId) {	
			var customer = this._getCustomer();
			this._deleteAgendaItem(customer.getActivityId(), sap.ui.getCore().byId("changeagendaactivityid").getText());

		},
		onCloseAgenda: function() {
			this.oChangeAgendaItemDialog.close();
		},
		getDealSummary: function(accountId, week, oControls) {
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;

			var oTableControl = oControls.table;
			var oCalculatorControl = oControls.calc;
			var oItemTableControl = oControls.item;

			if (oTableControl != null) {
				oTableControl.setBusy(true);
			}

			if (oCalculatorControl != null) {
				oCalculatorControl.setBusy(true);
			}

			if (oItemTableControl != null) {
				oItemTableControl.setBusy(true);
			}

			var summaryCalcModel = new sap.ui.model.json.JSONModel({
				listPrice: 0,
				fpb: 0,
				dluc: 0,
				unit: 0,
				psd: 0,
				otherDiscount: 0,
				freight: 0,
				rrp: 0,
				tpr: 0,
				wet: 0,
				netLuc: 0,
				gp: 0,
				gpPc: 0,
				otherTpr: 0,
				cdl: 0,
				oc: 0,
				totalDiscount: 0,
				bc: 0
			});

			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var query = "/rest/callPlanCommon.service.dealSummary?accountId=" + accountId + "&week=" + week;
			that.setModel("dealSummary");

			oModel.read(
				query,
				null, null, true,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					var oXML = new sap.ui.model.xml.XMLModel();
					//sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));
					oXML.setXML(obody);
					that.setModel(oXML, "dealSummary");
					var sDefaultBindingPath = "/xsdLocal1:Account/xsdLocal1:ListOfLnAccountDealsSummary/xsdLocal1:LnAccountDealsSummary/0";
					var sPathSegment = sDefaultBindingPath + '/xsdLocal1:ListOfLnAccountDeals-Week0/xsdLocal1:LnAccountDeals-Week0';
					var sCalcPathSegment = sPathSegment +
						"/xsdLocal1:ListOfLnAccountDealsProfitCalcWeek0Vbc/0/xsdLocal1:LnAccountDealsProfitCalcWeek0Vbc";
					var listPrice = oXML.getProperty(sCalcPathSegment + "/0/xsdLocal1:ListPrice");
					var fpb = oXML.getProperty(sCalcPathSegment + "/0/xsdLocal1:FullPalletBenefit");
					var dluc = oXML.getProperty(sCalcPathSegment + "/0/xsdLocal1:DiscountLUCWeek0");
					var unit = oXML.getProperty(sCalcPathSegment + "/0/xsdLocal1:LNUnit2");
					var psd = oXML.getProperty(sCalcPathSegment + "/0/xsdLocal1:PSDWeek" + week + "2");
					var otherDiscount = oXML.getProperty(sCalcPathSegment + "/0/xsdLocal1:Other");
					var rrp = oXML.getProperty(sCalcPathSegment + "/0/xsdLocal1:RRP");
					var tpr = oXML.getProperty(sCalcPathSegment + "/0/xsdLocal1:TPR");
					var wet = oXML.getProperty(sCalcPathSegment + "/0/xsdLocal1:WETWeek0");
					var netLuc = oXML.getProperty(sCalcPathSegment + "/0/xsdLocal1:LUCWeek0");
					var freight = oXML.getProperty(sCalcPathSegment + "/0/xsdLocal1:Freight");
					var gp = oXML.getProperty(sCalcPathSegment + "/0/xsdLocal1:GrossProfitAmtWeek0");
					var gpPc = oXML.getProperty(sCalcPathSegment + "/0/xsdLocal1:GrossProfitPercentWeek0");
					var otherTpr = oXML.getProperty(sCalcPathSegment + "/0/xsdLocal1:OtherTPRAmountWeek0");
					var cdl = oXML.getProperty(sCalcPathSegment + "/0/xsdLocal1:CDL");
					//var oc = oModel.getProperty(sPathSegment + "/Calculated");
					var totalDiscount = oXML.getProperty(sCalcPathSegment + "/0/xsdLocal1:TotalDiscountAmtWeek0");
					//var bc = oModel.getProperty(sPathSegment + "/Calculated");

					var oCalcModelData = {
						listPrice: listPrice,
						fpb: fpb,
						dluc: dluc,
						unit: unit,
						psd: psd,
						otherDiscount: otherDiscount,
						freight: freight,
						rrp: rrp,
						tpr: tpr,
						wet: wet,
						netLuc: netLuc,
						gp: gp,
						gpPc: gpPc,
						otherTpr: otherTpr,
						cdl: cdl,
						totalDiscount: totalDiscount
					};

					oTableControl.setBusy(false);
					oCalculatorControl.setBusy(false);
					oItemTableControl.setBusy(false);
					summaryCalcModel.setData(oCalcModelData);
					that.setModel(summaryCalcModel, "dealSummaryCalc");
				},
				function(oError) {
					oTableControl.setBusy(false);
					// sap.ui.commons.MessageBox.alert(JSON.stringify(oError));
					//RESET Model to Empty when an error occurs
					var oXML = new sap.ui.model.xml.XMLModel();
					oXML.setXML("");
					that.setModel(oXML, "dealSummary");
					that.setModel(summaryCalcModel, "dealSummaryCalc");

				});
		},

		getBusinessPriorityData: function(promotionName, model, bindingPath) {
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var converter = {
				'1': 'High',
				'2': 'Medium',
				'3': 'Low',
				'4': 'None'
			};

			var query = "/rest/callPlanCommon.service.businessPriority?sourceCode=" + promotionName;
			that.setModel(promotionName);
			oModel.read(
				query,
				null, null, false,
				function(oData, response) {
					// create JSON model
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					var oXML = new sap.ui.model.xml.XMLModel();
					oXML.setXML(obody);
					var priority = oXML.getProperty("/xsdLocal1:Campaign/xsdLocal1:LNCATGrade");
					var res = converter[priority[0]];
					var priorityNumber = Number(priority[0]);
					// force priority 
					// if(priorityNumber > 4) {
					// 	priorityNumber = 4;
					// }
					priorityNumber = isNaN(priorityNumber) ? 4 : priorityNumber;
					res = (res == null || res === "") ? 'None' : res;
					var priorityNumNode = model.oData.createElement("priorityNumber");
					var priorityNode = model.oData.createElement("priority");
					var oNode = model.getObject(bindingPath);
					priorityNumNode.innerHTML = priorityNumber;
					priorityNode.innerHTML = res;
					oNode.appendChild(priorityNode);
					oNode.appendChild(priorityNumNode);
					model.refresh();
				},
				function(oError) {
					console.log(oError);
				});
		},

		getBusinessPriority: function(element, promotionName) {
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var converter = {
				'1': 'High',
				'2': 'Medium',
				'3': 'Low',
				'4': 'None'
			};

			var query = "/rest/callPlanCommon.service.businessPriority?sourceCode=" + promotionName;
			that.setModel(promotionName);

			//		sap.ui.commons.MessageBox.alert(query);
			//alert(query);
			element.setBusy(true);
			oModel.read(
				query,
				null, null, true,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					var oXML = new sap.ui.model.xml.XMLModel();
					//			sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));

					oXML.setXML(obody);
					var priority = oXML.getProperty("/xsdLocal1:Campaign/xsdLocal1:LNCATGrade");
					//alert(priority);
					var res = converter[priority[0]];
					res = res == null ? 'Low' : res;
					//alert(res);
					element.setPriority(res);
					element.setBusy(false);
					//	that.setModel(res, promotionName);
					//	callback(priority[0]);

				},
				function(oError) {});
		},

		formatDate: function(val) {
			//	alert(val);
			var date = new Date(val);
			var year = date.getFullYear();

			return date.getDate() + " " + date.toLocaleString("en-us", {
				month: "short"
			}) + " " + String(year).substr(2, 2);
		},

		/*
		 * Helper function that decorates a given control with a RichTooltip showing a quick help text
		 */
		quickhelp: function(oControl, sText, bCustomize, title) {
			// create the RichTooltip control
			var oRichTooltip = new sap.ui.commons.RichTooltip({
				text: sText,
				title: title,
				imageSrc: "images/notes.jpeg"
			});
			//Change position and durations if required
			if (bCustomize) {
				oRichTooltip.setMyPosition("begin top");
				oRichTooltip.setAtPosition("end top");
				oRichTooltip.setOpenDuration(300);
				oRichTooltip.setCloseDuration(300);
			}
			// add it to the control
			oControl.setTooltip(oRichTooltip);
			// return the control itself (makes this function a decorator function)
			return oControl;
		},

		/*
		
		internal error 
		*/
		_handleUnknownError: function(oError) {
			//TODO
			sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
		}

	});
});