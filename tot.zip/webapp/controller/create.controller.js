sap.ui.define(["sap/ui/core/mvc/Controller"], function(Controller) {
	"use strict";
	return Controller.extend("tot.controller.create", {
		/*
		 *  initial - prior to page load
		 */
		onInit: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			
			this.theTokenInput = this.getView().byId("location");
			this.theTokenInputid = this.getView().byId("locationid");

			
			this.setDropDown("na", "FragApplication_YesNoNAObject", "Caption", false);
			this.setDropDown("yesno", "PermitReview_YesNo10Object", "Caption", false);
			//	alert("yesno:"+this.getView().getModel("yesno").getProperty("/getRecord/fieldValue/0/"));
			if (this.getView().getModel("yesno").getProperty("/getRecord/0/fieldValue/") === "Yes") {
				this.yesGuid = this.getView().getModel("yesno").getProperty("/getRecord/0/idValue/");
			} else {
				this.noGuid = this.getView().getModel("yesno").getProperty("/getRecord/0/idValue/");
			}

			if (this.getView().getModel("yesno").getProperty("/getRecord/1/fieldValue/") === "Yes") {
				this.yesGuid = this.getView().getModel("yesno").getProperty("/getRecord/1/idValue/");
			} else {
				this.noGuid = this.getView().getModel("yesno").getProperty("/getRecord/1/idValue/");
			}
			this.getOwnerComponent().setDropDownFilter("reportedby", "SysEmployeeEntity", "FullName", "Email",this.getOwnerComponent().userid, "", "", true);
			this.getOwnerComponent().setLocation("location", "SysEmployeeEntity", "Location", "Email", this.getOwnerComponent().userid, "", "", true);			
		},
		
		onBack: function() {
			this.getOwnerComponent().getRouter().navTo("main", {}, false);
		},

		onBeforeRendering: function() {
			//var oReportedBy = new sap.m.Input();
			//oReportedBy = this.byId("reportedby");
			//oReportedBy.setValue(this.getOwnerComponent().getModel("userInfo").getProperty("/displayName"));
			var today = new Date();
			var dd = today.getDate();
			var MM = today.getMonth() + 1;
			if (MM < 10) {
				MM = "0" + MM;
			}
			var yyyy = today.getFullYear();
			var hh = today.getHours();
			var mm = today.getMinutes();
			var ss = today.getSeconds();
			this.byId("date").setDateValue(new Date());
			//			this.byId("reviewdate").setDateValue(new Date());
			//			this.byId("time").setDateValue(new Date());

		},
		//this.onReportTypeChange();
		//sap.ui.commons.MessageBox.alert("after: " + this.getOwnerComponent().getModel("userInfo").getProperty("/displayName"));				
		onAfterRendering: function() {

			var oLocationInput = new sap.m.Input();
			oLocationInput = this.byId("location");

			//this.getView().byId("locationid").setValue()				
		},

		onExternalListFinished: function(ev) {
			var oFilterName = new sap.ui.model.Filter("content/m:properties/d:Section",
				sap.ui.model.FilterOperator.Contains, "External");
			var oFilter = new sap.ui.model.Filter({
				filters: [oFilterName],
				and: false
			});
			var oBinding = this.byId("external").getBinding("items");
			oBinding.filter([oFilter]);
		},

		onInternalListFinished: function(ev) {
			var oFilterName = new sap.ui.model.Filter("content/m:properties/d:Section",
				sap.ui.model.FilterOperator.Contains, "Internal");
			var oFilter = new sap.ui.model.Filter({
				filters: [oFilterName],
				and: false
			});
			var oBinding = this.byId("internal").getBinding("items");
			oBinding.filter([oFilter]);
		},

		onTrailerListFinished: function(ev) {
			var oFilterName = new sap.ui.model.Filter("content/m:properties/d:Section",
				sap.ui.model.FilterOperator.Contains, "Trailer");
			var oFilter = new sap.ui.model.Filter({
				filters: [oFilterName],
				and: false
			});
			var oBinding = this.byId("trailer").getBinding("items");
			oBinding.filter([oFilter]);
		},
		/**
		 *@memberOf nearmiss.controller.main
		 */
		onLocationChange: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
		},

		/*
		 *
		 * Set drop down values (coming from Sequis database Via WebMethods)
		 *
		 */
		setDropDown: function(field, systemname, fieldname, async) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			oModel.read("/rest/commonIntelex/restIntelex/getRecords?systemName=" + systemname + "&Field=" + fieldname, //				"/odata/commonIntelex.odata:ointelex/getRecords?$filter=systemName eq '" + systemname + "' and field eq '" + fieldname + "'",
				null, null, async,
				function(oData, oResponse) {
					// create JSON model  
					oDataJSONModel.setData(oResponse);
					var obody = oDataJSONModel.getProperty("/body");
					//	sap.ui.commons.MessageBox.alert(JSON.stringify("field:"+field + obody, null, 4));
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					var oXMLModel = new sap.ui.model.xml.XMLModel();
					oXMLModel.setXML(obody);
					that.getView().setModel(oXMLModel, field);
				},
				function(oError) {});
		},
		/*
		 *
		 * Set drop down values (coming from Sequis database Via WebMethods)
		 *
		 */
		setDropDownFilter: function(field, systemname, fieldname, filterName1, filterValue1, filterName2, filterValue2, async) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var query = "/rest/commonIntelex/restIntelex/getRecordsByFilter?systemName=" + systemname + "&Field=" + fieldname + "&filterName=" +
				filterName1 + "&filterValue=" + filterValue1;
			// + "&filterName=" + filterName2 + "&filterValue=" + filterValue2,;
			if (filterName2 !== "") {
				query += "&filterName=" + filterName2 + "&filterValue=" + filterValue2;
			}

			var oXML = new sap.ui.model.xml.XMLModel();
			that.getView().setModel(oXML, field);

			oModel.read(query, null, null, async, function(oData, oResponse) {
				oDataJSONModel.setData(oResponse);
				var obody = oDataJSONModel.getProperty("/body");
				//	sap.ui.commons.MessageBox.alert(JSON.stringify("field:"+field + obody, null, 4));
				//
				//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
				//
				var oXMLModel = new sap.ui.model.xml.XMLModel();
				oXMLModel.setXML(obody);
				that.getView().setModel(oXMLModel, field);
			}, function(oError) {
				//		sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
			});
		},
		onSubmit2: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			jQuery.sap.require("sap.m.MessageToast");
			//sap.m.MessageToast.show("start");
			var that = this;
			var returnguid;
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			oModel.setHeaders({
				"X-Requested-With": "X"
			});
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var oXMLModel = new sap.ui.model.xml.XMLModel();
			var oRecord = {};
			var nameVal = [];
			var systemName = "VehicInspection_ToTVehicInspectObject";
			var objectId = "30d61d40-ec9d-4626-ac31-1b3442506ad1";
			/*
			  Set the AUDIT fields
			*/
			if (!this.byId("confirm").getState()){
				sap.m.MessageToast.show("Please confirm before submitting");
				return;
			}
			/*
			   set the sequis field names and values
			*/

			nameVal = this._setAuditRecord();

			/***********************************************************************************************************/
			sap.m.MessageToast.show("submitting Tools of trade record");

			oRecord.nameVal = nameVal;
			//oRecord.systemName = "SafetyIncident_SafetyIncidentObject"; // for safety
			oRecord.systemName = systemName;
			// for safety				
			//sap.m.MessageToast.show("About to save Recorded");
			sap.m.MessageToast.show("Preparing Audit Record ...");
			this._createAudit(oRecord, objectId, systemName);

		},
		_createAudit: function(oRecord, objectId, systemName) {
			jQuery.sap.require("sap.ui.core.BusyIndicator");
			var that = this;
			var returnguid;
			var sServiceUrl = "/destinations/WebMethods";
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var oXMLModel = new sap.ui.model.xml.XMLModel();
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			oModel.setHeaders({
				"X-Requested-With": "X"
			});

			//that.getRouter().navTo("result", {}, false);

			jQuery.sap.delayedCall(1000, this, function() {
				var query = "/rest/commonIntelex/restIntelex/dataManagerServices";
				oModel.create(query, oRecord, null, function(oData, oResult) {
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oResult, null, 4));
					oDataJSONModel.setData(oResult);
					var obody = oDataJSONModel.getProperty("/body");
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					oXMLModel.setXML(obody);

					//sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));

					that.getView().setModel(oXMLModel.getProperty("/"), "guid");
					returnguid = oXMLModel.getProperty("/");
					debugger


					sap.ui.core.BusyIndicator.hide();

					//that._setRisk();
					that.getOwnerComponent().getRouter().navTo("result", {}, false);

				}, function(oError) {
					sap.ui.core.BusyIndicator.hide();
					sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				}, true);

			});

			sap.ui.core.BusyIndicator.show(100);

		},
		_setInterlexField: function(record, field, value, id) {
			if (!id === null && !id === "") {
				if (this.byId(id).getVisible()) {
					record[record.length] = this._addField(field, value);
				}
			} else {
				record[record.length] = this._addField(field, value);
			}
		},

		/*
		   add field for Save 
		*/
		_addField: function(field, value) {
			var name = {};
			name.name = field;
			name.value = value;
			return name;
		},
		/*
		 * handle search for location field
		 *
		 */
		handleLocationPress: function(oEvent) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var oXMLModel = new sap.ui.model.xml.XMLModel();
			var showBusy = false;
			if (!this._oDialog) {
				oModel.read("/rest/commonIntelex/restIntelex/getRecords?systemName=SysLocationEntity&Field=Name", null, null, true, function(oData,
					oResponse) {
					// create JSON model  
					oDataJSONModel.setData(oResponse);
					var obody = oDataJSONModel.getProperty("/body");
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					oXMLModel.setXML(obody);
					sap.ui.core.BusyIndicator.hide();
				}, function(oError) {
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				});
				this._oDialog = sap.ui.xmlfragment("tot.view.locationSelect", this);
				//this._oDialog.setModel(this.getView().getModel());
				this._oDialog.setModel(oXMLModel);
				showBusy = true;
			}
			// clear the old search filter
			this._oDialog.getBinding("items").filter([]);
			// toggle compact style
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog);
			this._oDialog.open();
			if (showBusy) {
				sap.ui.core.BusyIndicator.show();
			}
		},
		handleLocationSearch: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilterName = new sap.ui.model.Filter("fieldValue", sap.ui.model.FilterOperator.Contains, sValue);
			var oFilter = new sap.ui.model.Filter({
				filters: [oFilterName],
				and: false
			});
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		},
		handleLocationClose: function(oEvent) {
			var that = this;
			debugger
			var aContexts = oEvent.getParameter("selectedContexts");
			if (aContexts && aContexts.length) {
				that.theTokenInput.setValue(aContexts.map(function(oContext) {
					//return oContext.getObject().fieldValue;
					return oContext.getModel().getProperty(oContext.getPath() + "/fieldValue");
				}));
				that.theTokenInputid.setText(aContexts.map(function(oContext) {
					//return oContext.getObject().fieldValue;
					return oContext.getModel().getProperty(oContext.getPath() + "/idValue");
				}));
				//that.onLocationChange();
			}
			oEvent.getSource().getBinding("items").filter([]);
		},

		onMismatch: function(e) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			sap.ui.commons.MessageBox.alert("mismatch");
		},
		onExceed: function(e) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			sap.ui.commons.MessageBox.alert("file name exceed");
		},
		onUploadCompleteFUP: function(e) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			//	sap.ui.commons.MessageBox.alert("Photo added");
			this.byId("photo1").clear();
		},
		onUploadCompleteFUP1: function(e) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			//	sap.ui.commons.MessageBox.alert("Photo added");
			//	this.byId("photo2").clear();
		},
		onSizeExceed: function(e) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			sap.ui.commons.MessageBox.alert("size exceed");
		},
		onChangeFUP: function(e) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			//			sap.ui.commons.MessageBox.alert("uploading");
			//			this.byId("photo1").clear();
			var output = this.byId("myImage");
			this._import(e.getParameter("files") && e.getParameter("files")[0], "myImage"); //this.byId("fileupload").attachChange("onChangeFUP");
		},
		onChangeFUP1: function(e) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			//			this.byId("photo2").clear();
			var output = this.byId("myImage1");
			this._import(e.getParameter("files") && e.getParameter("files")[0], "myImage1");
		},
		_import: function(file, id) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;

			if (file) {
				var reader = new FileReader();
				//	var reader = new FileReader();
				reader.onload = function() {
					var dataURL = reader.result;
					var output = that.byId(id);
					output.setSrc(dataURL);
				};
				reader.readAsDataURL(file);
			}
		},
		/**
		 *@memberOf nearmiss.controller.main
		 */
		onClearImage: function() {
			//This code was generated by the layout editor.
			var output = this.byId("myImage");
			output.setSrc();
		},

		onUndoPhoto: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			sap.m.MessageToast.show("reset");
			var output = this.byId("myImage");
			output.setSrc("./images/noimage.png");
			this.byId("photo1").clear();
		},
		/*
		  validate form
		*/
		_validateForm: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			//this._validateField("reportedby");
			var valid = true;
			if (this.byId("onsitejob").getState()) {
				if (!this._validateField("location"))
					valid = false;
			}

			if (!this.byId("lionemployee").getState()) {
				this._validateField("contractorcompany");
				this._validateField("contractorname");
			}

			if (!this._validateField("exactlocation"))
				valid = false;

			if (!this._validateField("exactlocation"))
				valid = false;

			if (!this._validateField("detailofwork"))
				valid = false;
			//	if (!this._validateField("additionalcontrols"))
			//		valid = false;
			if (!this._validateField("reviewdate"))
				valid = false;

			if (this.byId("isolations").getValue() !== "N/A") {
				if (!this._validateField("isolationpoints"))
					valid = false;
			} else {
				this.byId("isolationpoints").setValueState(sap.ui.core.ValueState.None);
			}

			if (!this._validateField("equipment"))
				valid = false;

			if (this.byId("controlmeasures").getSelectedKey() === " ") {
				this.byId("controlmeasures").setValueState(sap.ui.core.ValueState.Error);
				valid = false;
			} else {
				this.byId("controlmeasures").setValueState(sap.ui.core.ValueState.None);
			}
			return valid;
		},
		/*
		Function: _validateDate
		Parameters: none
		
		Returns Boolean value based on the date being less than today or not
		True - if date/time is less than today
		False - if date/time in the future
		
		
		*/
		_validateDate: function() {
			var valid = true;
			var dd = this.byId("date").getValue()[6] + this.byId("date").getValue()[7];
			var MM = this.byId("date").getValue()[4] + this.byId("date").getValue()[5];
			MM = parseInt(MM) - 1;
			var yyyy = this.byId("date").getValue()[0] + this.byId("date").getValue()[1] + this.byId("date").getValue()[2] + this.byId("date").getValue()[
				3];
			var hh = "00";
			var mm = "00";
			var DateTime;
			DateTime = new Date(yyyy, MM, dd, hh, mm, 0);
			var today = new Date();
			var DateTime_ms = DateTime.getTime();
			var today_ms = today.getTime();
			if (DateTime_ms > today_ms) {
				this.byId("date").setValueState(sap.ui.core.ValueState.Error);
				valid = false;
			}
			return valid;
		},
		/*
		  Function: _validateField
		  Parameters: 
			field - field name to perform validation on, currently checks if there is a value or not
			
		  Returns Boolean value
		*/
		_validateField: function(field) {
			var oInput = new sap.m.Input();
			oInput = this.byId(field);
			if (oInput.getVisible()) {
				if (oInput.getValue() === "") {
					oInput.setValueState(sap.ui.core.ValueState.Error);
					return false;
				} else {
					oInput.setValueState(sap.ui.core.ValueState.None);
				}
			}
			return true;
		},
		/**
		 *@memberOf nearmiss.controller.main
		 */
		onCategoryChange: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var oCategorySelect = new sap.m.Select();
			oCategorySelect = this.byId("category");
			var osubcategorySelect = new sap.m.Select();
			osubcategorySelect = this.byId("subcategory");
			if (osubcategorySelect.getVisible()) {
				this.setDropDownFilter("subcategory", "QualiIncidentV6_QualityCat2Object", "QualitCategory2", "QualityCat1", oCategorySelect.getValue(),
					"", "", false);
			}
		},
		/**
		 *@memberOf nearmiss.controller.main
		 */
		onCapitonWorksChange: function() {
			//This code was generated by the layout editor.
			this.byId("projectname").setVisible(false);
			this.byId("__labelprojectname").setVisible(false);
			if (!this.byId("capital").getState() && this.byId("capital").getVisible()) {
				this.byId("projectname").setVisible(true);
				this.byId("__labelprojectname").setVisible(true);
			}
		},
		onSiteChange: function() {},
		onControlChange: function() {
			//This code was generated by the layout editor.
			this.byId("__labelexp").setVisible(false);
			this.byId("notcontrolled").setVisible(false);
			if (this.byId("reporttype").getValue() === "Environment") {
				if (this.byId("controlled").getState()) {
					this.byId("__labelexp").setVisible(true);
					this.byId("notcontrolled").setVisible(true);
				}
			}
		},
		/*
		  Function: _issueWorkflow
		  Parameters: 
			SystemName - Name of the system in Sequis
			actionId - guid of the next workflow item
			guid - Guid of the record in sequis that workflow is for 
		
		*/
		_issueWorkflow: function(SystemName, actionId, guid) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			oModel.setHeaders({
				"X-Requested-With": "X"
			});
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var oXMLModel = new sap.ui.model.xml.XMLModel();
			var oRecord = {};
			oRecord.systemName = SystemName;
			oRecord.actionId = actionId;
			oRecord.guid = guid;
			//sap.ui.commons.MessageBox.alert("workFlow");
			var query = "/rest/commonIntelex/restIntelex/workflowService";
			oModel.create(query, oRecord, null, function(oData, oResult) {
				//sap.ui.commons.MessageBox.alert(JSON.stringify(oResult, null, 4));
				oDataJSONModel.setData(oResult);
				var obody = oDataJSONModel.getProperty("/body"); //sap.ui.commons.MessageBox.alert(JSON.stringify(oResult, null, 4));
				//
				//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
				//
				//oXMLModel.setXML(obody);
				//sap.ui.commons.MessageBox.alert("guid:"+oXMLModel.getProperty("/"));
				//that.getView().setModel(oXMLModel.getProperty("/"), "guid");
				//sap.ui.commons.MessageBox.alert("Incident Success Recorded");
			}, function(oError) {
				//	sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
			});
		},
		/*
		  Function: _uploadImage
		  Parameters: 
		   Filename - Name of the file when attching to sequis
		   RecordId - the guid of the record in sequis where the attachment will be 
		   ObjectId - the guid of the sequis type
		   Source - the source base64 of the image
		   
		*/
		_uploadImage: function(Filename, RecordId, ObjectId, Source) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			oModel.setHeaders({
				"X-Requested-With": "X"
			});
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var oXMLModel = new sap.ui.model.xml.XMLModel();
			var oRecord = {};
			oRecord.Filename = Filename;
			// for safety
			oRecord.RecordId = RecordId;
			oRecord.ObjectId = ObjectId;
			oRecord.Source = Source;
			//	sap.ui.commons.MessageBox.alert("JSRA RecordID:" + oRecord.RecordId + "Obj:" + oRecord.ObjectId);								
			//sap.ui.commons.MessageBox.alert("workFlow");
			var query = "/rest/commonIntelex/restIntelex/PrivateDocumentAttachmentService";
			oModel.create(query, oRecord, null, function(oData, oResult) {
				//sap.ui.commons.MessageBox.alert(JSON.stringify(oResult, null, 4));
				oDataJSONModel.setData(oResult);
				var obody = oDataJSONModel.getProperty("/body"); //	sap.ui.commons.MessageBox.alert(JSON.stringify(oResult, null, 4));
			}, function(oError) {
				//	sap.ui.commons.MessageBox.alert("Image Error:" + JSON.stringify(oError, null, 4));
			});
		},
		/*
		  @todo 
		  This will set all fields for JSRA in sequis.
		*/
		_setAuditRecord: function() {
			var nameVal = [];
			var now = new Date();
			// date 
			var dd = this.byId("date").getValue()[6] + this.byId("date").getValue()[7];
			var MM = this.byId("date").getValue()[4] + this.byId("date").getValue()[5];
			//	MM = parseInt(MM) - 1;
			var yyyy = this.byId("date").getValue()[0] + this.byId("date").getValue()[1] + this.byId("date").getValue()[2] + this.byId("date").getValue()[
				3];

			var hh = now.getHours();
			var mm = now.getMinutes();
			//	alert(hh +":" + mm);

			var myDate = new Date(MM + '/' + dd + '/' + yyyy + ' ' + hh + ':' + mm + ':00');

			//			var newDate = dd + '/' + MM + '/' + yyyy + ' ' + hh + ':' + mm + ':00';
			//var myDate = new Date(MM + "/" + dd + "/" + yyyy);
			//var myDate = new Date(MM + "/" + dd + "/" + yyyy + " " + hh + ":" + mm + ":00");			
			var month = myDate.getUTCMonth() + 1;
			//Month is between 0 - 11
			var newDate = myDate.getUTCDate() + "/" + month + "/" + myDate.getUTCFullYear() + " " + myDate.getUTCHours() + ":" + myDate.getUTCMinutes() +
				":00";

			var i = 0;

			nameVal[i] = this._addField("DriverName", this.byId("reportedby").getSelectedKey());
			i++;
			nameVal[i] = this._addField("Location", this.byId("locationid").getText());
			i++;
			nameVal[i] = this._addField("Date", newDate);
			/**************************************************************************************************/
			var external = this.byId("external");
			debugger
			var items = external.getItems();
			for (var j = 0; j < items.length; j++) {
				var content = items[j].getContent();
				i++; //object yesno10Object
				nameVal[i] = this._addField(content[3].getText(), content[1].getState() ? this.yesGuid : this.noGuid);
				i++; //object yesno10Object
				nameVal[i] = this._addField(content[4].getText(), content[2].getValue());				
			}

			var internal = this.byId("internal");
			var items = internal.getItems();
			for (var j = 0; j < items.length; j++) {
				var content = items[j].getContent();
				i++; //object yesno10Object
				nameVal[i] = this._addField(content[3].getText(), content[1].getState() ? this.yesGuid : this.noGuid);
				i++; //object yesno10Object
				nameVal[i] = this._addField(content[4].getText(), content[2].getValue());					
			}

			var trailer = this.byId("trailer");
			var items = trailer.getItems();
			for (var j = 0; j < items.length; j++) {
				var content = items[j].getContent();
				i++; //object yesno10Object
				nameVal[i] = this._addField(content[3].getText(), content[1].getState() ? this.yesGuid : this.noGuid);
				i++; //object yesno10Object
				nameVal[i] = this._addField(content[4].getText(), content[2].getValue());					
			}
			/**************************************************************************************************/

			return nameVal;
		},
		/**
		 *@memberOf jsra.controller.main
		 */
		onClearSignature: function() {
			//This code was generated by the layout editor.
			//sap.ui.commons.MessageBox.alert(this.byId("reviewedby").save());
			this.byId("reviewedby").clear();
		},
		undoSig: function() {
			//This code was generated by the layout editor.
			//sap.ui.commons.MessageBox.alert(this.byId("reviewedby").save());
			this.byId("reviewedby").clear();

		},
		undoSig1: function() {
			//This code was generated by the layout editor.
			//sap.ui.commons.MessageBox.alert(this.byId("reviewedby").save());
			this.byId("reviewedby1").clear();
		},

		undoPhoto: function() {
			this.byId("myImage").setSrc();
		},

		onSwitchChange: function(ev) {
			//	alert("change(no guid)"+this.noGuid + "yes:"+this.yesGuid);
			//		alert("yesno:"+this.getView().getModel("yesno").getProperty("/getRecord/fieldValue/0/"));
			var comment = ev.getSource().getParent().getContent()[2];
			var toggleSwitch =  ev.getSource().getParent().getContent()[1];
			debugger
			if (toggleSwitch.getState()) {
				comment.setVisible(false);
			} else {
				comment.setVisible(true);
			}

		},
		_validateComments: function() {
			var valid = true;
			for (var i = 1; i < 23; i++) {

				var commentId = "q" + i + "comment";
				if (this.byId(commentId).getVisible() && this.byId(commentId).getValue() === "") {
					this.byId(commentId).setValueState(sap.ui.core.ValueState.Error);
					valid = false;
				} else {
					this.byId(commentId).setValueState(sap.ui.core.ValueState.None);
				}
			}

			if (this.byId("exactlocation").getValue() === "") {
				this.byId("exactlocation").setValueState(sap.ui.core.ValueState.Error);
				valid = false;
			} else {
				this.byId("exactlocation").setValueState(sap.ui.core.ValueState.None);
			}

			if (this.byId("permitnumber").getValue() === "") {
				this.byId("permitnumber").setValueState(sap.ui.core.ValueState.Error);
				valid = false;
			} else {
				this.byId("permitnumber").setValueState(sap.ui.core.ValueState.None);
			}

			return valid;

		},

		onChangeDropdown: function(ev) {
			var commentId = ev.getSource().getId() + 'comment';
			var messageId = ev.getSource().getId() + 'message';

			if (ev.getSource().getValue() === "No") {
				this.byId(commentId).setVisible(true);
				this.byId(messageId).setVisible(true);
			} else {
				this.byId(commentId).setVisible(false);
				this.byId(messageId).setVisible(false);
			}
		}

	});
});