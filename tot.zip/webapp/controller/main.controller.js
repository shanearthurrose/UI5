sap.ui.define(["sap/ui/core/mvc/Controller"], function(Controller) {
	"use strict";
	return Controller.extend("tot.controller.main", {
		/*
		 *  initial - prior to page load
		 */
		onInit: function() {},

		onBeforeRendering: function() {

		},
		//this.onReportTypeChange();
		//sap.ui.commons.MessageBox.alert("after: " + this.getOwnerComponent().getModel("userInfo").getProperty("/displayName"));				
		onAfterRendering: function() {
			//this.getView().byId("locationid").setValue()				
		},
		onCreate: function(ev) {
			this.getOwnerComponent().getRouter().navTo("create", {}, false);
		},
		
		onHistory: function(ev) {
			debugger;
			this.getOwnerComponent().getRouter().navTo("history", {}, false);
		}		

	});
});