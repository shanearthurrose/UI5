sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"tot/model/models"
], function(UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("tot.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			var oModel = new sap.ui.model.json.JSONModel();
			var userModel = new sap.ui.model.json.JSONModel("/services/userapi/currentUser");
			userModel.loadData("/services/userapi/currentUser", null, false);

			this.setModel(userModel, "userInfo");			
			this.userid = localStorage.userid;			
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);
			this.callIntelex("questions", "accebfae-d168-420f-90da-30abdb59b2aa",false); //get Questions			
			
			this.setModel(false,"risk");
			
			this.getRouter().initialize();
		
			
			if (!this.userid) {
				if (!this.logon) {
					this.logon = sap.ui.xmlfragment("tot.view.login", this); //	this.oContactDialog.setModel(this.getOwnerComponent().getModel("sellins"), "sellins");
				}
				this.logon.open();
			} else {
				this.getRouter().navTo("main", {}, false);
			}			

		//	this .getRouter().navTo("result", {}, false);

			
			// set the device model
			this.setModel(models.createDeviceModel(), "device");
		},
		
		onLogin: function(ev) {

			this.userid = sap.ui.getCore().byId("username").getValue().toUpperCase();
			this.password = sap.ui.getCore().byId("password").getValue();

			


			//	alert($('.password input').val());

			if (this.userid === "") {
				sap.ui.getCore().byId("username").setValueState(sap.ui.core.ValueState.Error);
				sap.m.MessageToast.show("Please Enter all Mandatory Fields(Userame)");
			} else if (this.password === "") {
				sap.ui.getCore().byId("password").setValueState(sap.ui.core.ValueState.Error);
				sap.m.MessageToast.show("Please Enter all Mandatory Fields(passord)");
			} else {
				var valid = this._checkLogin(this.userid, this.password);
				if (valid === "true") {
					localStorage.userid = this.userid;
					//localStorage.password = this.password;
					this.logon.close();
					this.setDropDownFilter("reportedby", "SysEmployeeEntity", "FullName", "Email", this.userid, "", "", true, false);
					this.setLocation("location", "SysEmployeeEntity", "Location", "Email", this.userid, "", "", true);								
				} else {
					sap.m.MessageToast.show("Invalid Credentials");
				}
				//sap.ui.core.BusyIndicator.show(10);
			}

		},
		
		/*
		 *
		 * Set drop down values (coming from Sequis database Via WebMethods)
		 *
		 */
		setDropDownFilter: function(field, systemname, fieldname, filterName1, filterValue1, filterName2, filterValue2, async, busy) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var query = "/rest/commonIntelex/restIntelex/getRecordsByFilter?systemName=" + systemname + "&Field=" + fieldname + "&filterName=" +
				filterName1 + "&filterValue=" + filterValue1;
			// + "&filterName=" + filterName2 + "&filterValue=" + filterValue2,;
			if (filterName2 !== "") {
				query += "&filterName=" + filterName2 + "&filterValue=" + filterValue2;
			}

			var oXML = new sap.ui.model.xml.XMLModel();
			that.setModel(null, field);

			sap.ui.core.BusyIndicator.show(10);
			//	sap.ui.commons.MessageBox.alert("field:"+field+"query:"+query);

			oModel.read(query, null, null, async, function(oData, oResponse) {
				oDataJSONModel.setData(oResponse);
				var obody = oDataJSONModel.getProperty("/body");
				//	sap.ui.commons.MessageBox.alert(JSON.stringify("field:"+field + obody, null, 4));
				//
				//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
				//
				var oXMLModel = new sap.ui.model.xml.XMLModel();
				oXMLModel.setXML(obody);
				that.setModel(oXMLModel, field);
				sap.ui.core.BusyIndicator.hide();

			}, function(oError) {
				sap.ui.core.BusyIndicator.hide();
			});
		},	
		
		setLocation: function(field, systemname, fieldname, filterName1, filterValue1, filterName2, filterValue2, async) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var query = "/rest/commonIntelex/restIntelex/getRecordsByFilter?systemName=" + systemname + "&Field=" + fieldname + "&filterName=" +
				filterName1 + "&filterValue=" + filterValue1;
			// + "&filterName=" + filterName2 + "&filterValue=" + filterValue2,;
			if (filterName2 !== "") {
				query += "&filterName=" + filterName2 + "&filterValue=" + filterValue2;
			}

			var oXML = new sap.ui.model.xml.XMLModel();
			that.setModel(oXML, field);


			oModel.read(query, null, null, async, function(oData, oResponse) {
				oDataJSONModel.setData(oResponse);
				var obody = oDataJSONModel.getProperty("/body");
				//	sap.ui.commons.MessageBox.alert(JSON.stringify("field:"+field + obody, null, 4));
				//
				//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
				//
				var oXMLModel = new sap.ui.model.xml.XMLModel();
				oXMLModel.setXML(obody);
				that.setModel(oXMLModel, field);

				if (oXMLModel.getProperty("/getRecordsByFilter/fieldValue")) {
					that.setDropDownFilter("locationid", "SysLocationEntity", "Name", "Name", oXMLModel.getProperty("/getRecordsByFilter/fieldValue"), "", "", true, false);
				}
				
				
			}, function(oError) {
				//that.byId(field).setBusy(false);
				//		sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
			});
		},		
		
		callIntelex: function(model, guid, debug, filterField, filterValue) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var query = "/rest/commonIntelex.restIntelex.formsDataDefinition?guid=" + guid;
			if (filterField){
				query=query+'&filterField='+filterField+'&filterValue='+filterValue;
			}

			var oXML = new sap.ui.model.xml.XMLModel();
			this.setModel(oXML, model);

			//sap.ui.core.BusyIndicator.show(10);

			oModel.read(query, null, null, true, function(oData, oResponse) {
				oDataJSONModel.setData(oResponse);
				var obody = oDataJSONModel.getProperty("/body");
				if (debug) {
					sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));
				}
				//
				//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
				//
				var oXMLModel = new sap.ui.model.xml.XMLModel();
				oXMLModel.setXML(obody);
				that.setModel(oXMLModel, model);

				//sap.ui.core.BusyIndicator.hide();

			}, function(oError) {
				//sap.ui.core.BusyIndicator.hide();
				//		sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
			});

		},
		_checkLogin: function(user, password) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			var sServiceUrl = "/destinations/WebMethods";
			//var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
			//	"Content-Type": "application/xml; charset=utf-8"
			//});
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, user, password, {}, false, true);
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
		//	password = encodeURI(password);
			//var query = "/rest/ldapCommon.service.ldapAuth?userId=" + user + "&password=" + password ;
			var query = "/rest/ldapCommon.service.ldapAuth";			

			var oXML = new sap.ui.model.xml.XMLModel();

			var valid = false;

			oModel.read(query, null, {"userId": user, "password":password}, false,
				function(oData, oResponse) {
					oDataJSONModel.setData(oResponse);
					var obody = oDataJSONModel.getProperty("/body");
					//sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));

					var oXMLModel = new sap.ui.model.xml.XMLModel();
					oXMLModel.setXML(obody);

					valid = oXMLModel.getProperty("/status");
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oXMLModel.getProperty("/status"), null, 4));

				},
				function(oError) {

				});

			return valid;
		}		
		
	});
});