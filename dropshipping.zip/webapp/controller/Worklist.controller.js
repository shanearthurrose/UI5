sap.ui.define([
	"masterdetail/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/xml/XMLModel",
	"masterdetail/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(BaseController, JSONModel, XMLModel, formatter, Filter, FilterOperator) {
	"use strict";
	return BaseController.extend("masterdetail.controller.Worklist", {
		formatter: formatter,
		_mFilters: {
			All: [new sap.ui.model.Filter("OrderHeader/Status", "NE", "Dispatched")],
			New1: [new sap.ui.model.Filter("OrderHeader/Status", "EQ", "New")],
			Picking: [new sap.ui.model.Filter("OrderHeader/Status", "EQ", "Picking")],
			Invoiced: [new sap.ui.model.Filter("OrderHeader/Status", "EQ", "Invoiced")],
			Ticketed: [new sap.ui.model.Filter("OrderHeader/Status", "EQ", "Ticketed")],
			Dispatched: [new sap.ui.model.Filter("OrderHeader/Status", "EQ", "Dispatched")]
		},
		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */
		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {

			//this._getUserDetails();

			var that = this;
			//	this.getView().setModel(oUserModel);
			var oViewModel, iOriginalBusyDelay, oTable = this.byId("table");
			// Put down worklist table's original value for busy indicator delay,
			// so it can be restored later on. Busy handling on the table is
			// taken care of by the table itself.
			iOriginalBusyDelay = oTable.getBusyIndicatorDelay();
			// keeps the search state
			this._oTableSearchState = [];
			// Model used to manipulate control states
			oViewModel = new JSONModel({
				worklistTableTitle: this.getResourceBundle().getText("worklistTableTitle"),
				saveAsTileTitle: this.getResourceBundle().getText("worklistViewTitle"),
				tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
				tableBusyDelay: 0,
				New1: 0,
				Picking: 0,
				Invoiced: 0,
				Ticketed: 0,
				Dispatched: 0
			});
			this.setModel(oViewModel, "worklistView");
			// Make sure, busy indication is showing immediately so there is no
			// break after the busy indication for loading the view's meta data is
			// ended (see promise 'oWhenMetadataIsLoaded' in AppController)
			oTable.attachEventOnce("updateFinished", function() {
				// Apply the All Filter
				var sKey = "All",
					oFilter = that._mFilters[sKey],
					oTable = that.byId("table"),
					oBinding = oTable.getBinding("items");
				if (oFilter) {
					that.getOwnerComponent().globalFilter = oFilter;
					oBinding.filter(oFilter);
				} else {
					that.getOwnerComponent().globalFilter = [];
					oBinding.filter([]);
				}
				// Restore original busy indicator delay for worklist's table
				oViewModel.setProperty("/tableBusyDelay", iOriginalBusyDelay);
			});
			sap.ui.Device.resize.attachHandler(function() {
				that.resetContainer();

			});
			
			//Session timeout
			
			
					// Handler for Session Timeout
			$(document).ajaxComplete(function(e, jqXHR) {
				if (jqXHR.getResponseHeader("com.sap.cloud.security.login")) {
			//	var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;

				sap.m.MessageBox.information(
					"Your Session is expired, page shall be reloaded..", {
						icon: sap.m.MessageBox.Icon.INFORMATION,
						//title: "My message box title",
						actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
						onClose: function(oAction) {
							if (oAction === sap.m.MessageBox.Action.YES)
								window.location.reload();
						}
					}
				);
				//		alert("Your Session is expired, page shall be reloaded..");
			
					}
			});

			
			
			
			////
			
			
			
			
		},
		onAfterRendering: function() {
			this.resetContainer();

		},
		resetContainer: function() {
			var heightOfPage = parseInt(this.getView().byId("page").$().css('height'));
			var heightOfIconTabBar = parseInt(this.getView().byId("iconTabBar").$().css('height'));
			var initailHeightOfIconTabBar = parseInt(this.getView().byId("scroll_details").$().css('height'));
			var heightOfScrollContainer = heightOfPage + initailHeightOfIconTabBar - heightOfIconTabBar - 100;
			this.getView().byId("scroll_details").setHeight(heightOfScrollContainer + "px");
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */
		/**
		 * Triggered by the table's 'updateFinished' event: after new table
		 * data is available, this handler method updates the table counter.
		 * This should only happen if the update was successful, which is
		 * why this handler is attached to 'updateFinished' and not to the
		 * table's list binding's 'dataReceived' method.
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
		onQuickFilter: function(oEvent) {
			var sKey = oEvent.getParameter("key"),
				oFilter = this._mFilters[sKey],
				oTable = this.byId("table"),
				oBinding = oTable.getBinding("items");
			if (oFilter) {
				this.getOwnerComponent().globalFilter = oFilter;
				oBinding.filter(oFilter);
			} else {
				this.getOwnerComponent().globalFilter = [];
				oBinding.filter([]);
			}
		},
		onTableSettings: function(oEvent) {
			// Open the Table Setting dialog
			this._oDialog = sap.ui.xmlfragment("masterdetail/view/WorklistTableSort", this);
			//sap.ui.xmlfragment(oView.getId(), "view.WorklistTableSort");
			this._oDialog.open();
		},
		onSortConfirm: function(oEvent) {
			var oTable = this.getView().byId("table");
			var mParams = oEvent.getParameters();
			//	var modelPath = oTable.getBindingPath("SalesOrderSet");
			var oBinding = oTable.getBinding("items");
			//	var oBinding =	oTable.getModel().getProperty(modelPath);
			// apply grouping

			var aSorters = [];
			// apply sorter
			var sPath = mParams.sortItem.getKey();
			var bDescending = mParams.sortDescending;
			aSorters.push(new sap.ui.model.Sorter(sPath, bDescending));
			oBinding.sort(aSorters);
			// apply filters
			oBinding.filter(this.getOwnerComponent().globalFilter);
		},
		onUpdateFinished: function(oEvent) {
			// update the worklist's object counter after the table update
			var sTitle, oTable = oEvent.getSource(),
				oModel = this.getModel(),
				oViewModel = this.getModel("worklistView"),
				iTotalItems = oEvent.getParameter("total");
			// only update the counter if the length is final and
			// the table is not empty
			if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("worklistTableTitleCount", [iTotalItems]);
				// iterate the filters and request the count from the server
				jQuery.each(this._mFilters, function(sFilterKey, oFilter) {
					oModel.read("/SalesOrderSet/$count", {
						filters: oFilter,
						success: function(oData) {
							var sPath = "/" + sFilterKey;
							oViewModel.setProperty(sPath, oData);
						}
					});
				});
			} else {
				sTitle = this.getResourceBundle().getText("worklistTableTitle");
			}
			this.getModel("worklistView").setProperty("/worklistTableTitle", sTitle);
		},
		/**
		 * Event handler when a table item gets pressed
		 * @param {sap.ui.base.Event} oEvent the table selectionChange event
		 * @public
		 */
		onPress: function(oEvent) {
			// The source is the list item that got pressed
			this._showObject(oEvent.getSource());
		},
		/**
		 * Event handler for navigating back.
		 * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
		 * If not, it will navigate to the shell home
		 * @public
		 */
		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
				history.go(-1);
			} else {
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#Shell-home"
					}
				});
			}
		},
		/**
		 * Event handler when the share in JAM button has been clicked
		 * @public
		 */
		onSearch: function(oEvent) {
			if (oEvent.getParameters().refreshButtonPressed) {
				// Search field's 'refresh' button has been pressed.
				// This is visible if you select any master list item.
				// In this case no new search is triggered, we only
				// refresh the list binding.
				this.onRefresh();
			} else {
				var oTableSearchState = [];
				var sQuery = oEvent.getParameter("query");
				if (sQuery && sQuery.length > 0) {
					oTableSearchState = [new Filter("OrderHeader/DocNbr", FilterOperator.Contains, sQuery)];
				}
				this._applySearch(oTableSearchState);
			}
		},
		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */
		onRefresh: function() {
			var oTable = this.byId("table");
			oTable.getBinding("items").refresh();
		},
		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */
		/**
		 * Shows the selected item on the object page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		_showObject: function(oItem) {
			
			
			// check if session is still valid by calling user appi. This will fire ajax complete event to ask for refresh.
			this._loadUSerDetails();
			
			this.getRouter().navTo("object", {
				objectId: oItem.getBindingContext().getPath().substr(oItem.getBindingContext().getPath().lastIndexOf("/") + 1)
			});
		},
		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @param {object} oTableSearchState an array of filters for the search
		 * @private
		 */
		_applySearch: function(oTableSearchState) {
			var oTable = this.byId("table"),
				oViewModel = this.getModel("worklistView");
			oTable.getBinding("items").filter(oTableSearchState, "Application");
			// changes the noDataText of the list in case there are no filter results
			if (oTableSearchState.length !== 0) {
				oViewModel.setProperty("/tableNoDataText", this.getResourceBundle().getText("worklistNoDataWithSearchText"));
			}
		},
		_loadUSerDetails: function() {
			$.ajax({
				"url": "/services/userapi/currentUser",
				"success": function() {
				
				},
			});
		},

		logoutUser: function() {
			$.ajax({
				"url": "/services/userapi/logout",
				"success": function() {
					sap.m.URLHelper.redirect("../webapp/logout.html", false);
				},
				"complete": function() {
					sap.m.URLHelper.redirect("../webapp/logout.html", false);
				},
			});

		//
		}

	});
});