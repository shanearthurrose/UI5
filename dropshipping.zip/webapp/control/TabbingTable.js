// Prevent error "failed to load 'bgerth/components/TabbingTableRenderer.js'"
jQuery.sap.require("sap.ui.core.Renderer");
jQuery.sap.require("sap.m.TableRenderer");
sap.ui.core.Renderer.extend("masterdetail.control.TabbingTableRenderer", sap.m.TableRenderer);

jQuery.sap.declare('masterdetail.control.TabbingTable');
sap.m.Table.extend("masterdetail.control.TabbingTable", {
  init: function() {
    sap.m.Table.prototype.init.apply(this, arguments);
    this.addEventDelegate({
      onAfterRendering: this.setupTabHandling
    }, this)
  },

  setupTabHandling: function() {
    var that = this,
      oDomTable = this.$(),
      aRows = this.getItems(),
      i;

    oDomTable.focusin(function() {
      // remember current focused cell
      jQuery.sap.delayedCall(100, null, function() {
        // find the focused input field
        var oField = oDomTable.find('.sapMInputFocused')[0];
        if (oField) {
          // store ID of focused cell
          that._FieldID = oField.id;
        }
      });
    });

    // on TAB press - navigate one field forward
    oDomTable.on("keydown", function(oEvt) {
      $.sap.log.debug("Table keydown", [oEvt.which, that._FieldID]);
      if (oEvt.which != jQuery.sap.KeyCodes.TAB || !that._FieldID) {
        // Not a tab key or no field focused
        return;
      }

      var oSelectedField = sap.ui.getCore().byId(that._FieldID);
      var oRow = oSelectedField.getParent();
      var oCells = oRow.getCells();
      var iItems = aRows.length;

      var mInputInfo = that.getInputFieldIndices(oCells);

      var oTargetCell, thisInput, thisRow;
      thisInput = oRow.indexOfCell(oSelectedField);
      var bIsFirstEditableCell = thisInput <= mInputInfo.iFirstInput;
      var bIsLastEditableCell = thisInput >= mInputInfo.iLastInput;
      thisRow = that.indexOfItem(oRow);
      var bIsFirstRow = thisRow <= 0;
      var bIsLastRow = thisRow >= iItems - 1;

      if (!oEvt.shiftKey) {
        if (!bIsLastEditableCell || bIsLastRow) {
          // 1. Tabbing to next input field within a row works, no need to handle it here
          // 2. last row: Let default handling take care of focusing the next element after the table
          return;
        }

        // jump to next row
        oTargetCell = aRows[thisRow + 1].getCells()[mInputInfo.iFirstInput];

      } else {
        if (!bIsFirstEditableCell || bIsFirstRow) {
          // 1. Tabbing to previous input field within a row works, no need to handle it here
          // 2. First row: Let default handling take care of focusing the previous element before the table
          return;
        }

        // jump to previous row
        oTargetCell = aRows[thisRow - 1].getCells()[mInputInfo.iLastInput];
      }
      oTargetCell.focus();
      // Prevent any subsequent handling of this key press
      oEvt.preventDefault();
      oEvt.stopPropagation();
    });
  },

  getInputFieldIndices: function(aCells) {
    var mInputInfo = {
      aIndices: []
    };

    // get index of first and last input fields of table row
    for (var i = 0; i < aCells.length; i++) {
      if (aCells[i]._$input) {
      	if(aCells[i].getEditable())
      	{
      	
        mInputInfo.aIndices.push(i);
        if (typeof mInputInfo.iFirstInput === "undefined") {
          mInputInfo.iFirstInput = i;
        }
        mInputInfo.iLastInput = i;
      	}
      }
    }
    return mInputInfo;
  }
});


