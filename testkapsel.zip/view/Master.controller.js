jQuery.sap.require("test.util.Formatter");
jQuery.sap.require("test.util.Controller");
jQuery.sap.require("test.Component");
test.util.Controller.extend("test.view.Master", {
	/**
	 * Called when the master list controller is instantiated. 
	 * It sets up the event handling for the master/detail communication and other lifecycle tasks.
	 */
	onInit: function() {
		jQuery.sap.require("sap.ui.commons.MessageBox");
	},
	capturePhoto: function() {
		var that = this;
		var oNav = navigator.camera;
		oNav.getPicture(function cameraSuccess(imageUri) {
			var myImage = that.byId("myImage");
			myImage.setSrc("data:image/jpeg;base64," + imageUri);
		}, function onFail(error) {}, {
			quality: 20,
			destinationType: oNav.DestinationType.DATA_URL
		});
		this.getPosition();
	},
	/**
	 * Master view RoutePatternMatched event handler 
	 * @param{sap.ui.base.Event} oEvent router pattern matched event object
	 */
	onBeforeRendering: function() {
		//	sap.ui.commons.MessageBox.alert(JSON.stringify("before render", null, 4));
		this.setDropDown("category", "SafetyIncident_NeaMissCategoryObject", "Caption");
		this.setDropDown("reporttype", "CAPAV6_SystemTypeObject", "Caption");
		this.setDropDown("location", "SysLocationEntity", "Name");
		this.setDropDown("projectname", "SafetyIncident_CapitalProjectsObject", "Caption");
	},
	/**
	 *@memberOf nearmiss.controller.main
	 */
	onLocationChange: function() {
		jQuery.sap.require("sap.ui.commons.MessageBox");
		var oLocationSelect = new sap.m.Select();
		oLocationSelect = this.byId("location");
		var oAreaSelect = new sap.m.Select();
		var oDepartmentSelect = new sap.m.Select();
		oDepartmentSelect = this.byId("department");

		oAreaSelect = this.byId("area");
		oAreaSelect.removeAllItems();
		this.setDropDownFilter("department", "hciMastIncdntv6_IMDepartmentObject", "DepartmentName", "location", oLocationSelect.getSelectedItem()
			.getText(), "", "");
			
		this.setDropDownFilter("area", "FragApplication_SubDepartmentObject", "SDepartmentName", "department", oDepartmentSelect.getSelectedItem()
			.getText(), "location", oLocationSelect.getSelectedItem().getText());
	},
	/*
		  when the Department changes 
		*/
	onDepartmentChange: function() {
		jQuery.sap.require("sap.ui.commons.MessageBox");
		var oLocationSelect = new sap.m.Select();
		oLocationSelect = this.byId("location");
		var oDepartmentSelect = new sap.m.Select();
		oDepartmentSelect = this.byId("department");
		this.setDropDownFilter("area", "FragApplication_SubDepartmentObject", "SDepartmentName", "department", oDepartmentSelect.getSelectedItem()
			.getText(), "location", oLocationSelect.getSelectedItem().getText());
	},
	/**
	 * wait until this.oInitialLoadFinishedDeferred is resolved, and list view updated
	 * @param{function} fnToExecute the function will be executed if this.oInitialLoadFinishedDeferred is resolved
	 */
	setDropDown: function(field, systemname, fieldname) {
		jQuery.sap.require("sap.ui.commons.MessageBox");
		var oModel = this.getOwnerComponent().getModel();
		var oDataJSONModel = new sap.ui.model.json.JSONModel();
		//var sServiceUrl = "/destinations/WebMethods";
		//var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl);
		//var oDataJSONModel = new sap.ui.model.json.JSONModel();	
		var oSelect = new sap.m.Select();
		var oItem = new sap.ui.core.Item();
		oSelect = this.byId(field);
		oModel.read("getRecords?$filter=systemName eq '" + systemname + "' and field eq '" + fieldname + "'", null, null, false, function(
			oData, oResponse) {
			//	sap.ui.commons.MessageBox.alert(JSON.stringify(oData, null, 4));
			// create JSON model  
			oDataJSONModel.setData(oData);
			var object = oDataJSONModel.getProperty("/results");
			for (var i = 0; i < object.length; i++) {
				var obj = object[i];
				//sap.ui.commons.MessageBox.alert(JSON.stringify(obj.fieldValue, null, 4));
				var oItem = new sap.ui.core.Item();
				oItem.setKey(obj.idValue);
				oItem.setText(obj.fieldValue);
				oSelect.addItem(oItem);
			}
		}, function(oError) {
			sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
		});
	},
	/*
	 *
	 * Set drop down values (coming from Sequis database Via WebMethods)
	 *
	 */
	setDropDownFilter: function(field, systemname, fieldname, filterName1, filterValue1, filterName2, filterValue2) {
		jQuery.sap.require("sap.ui.commons.MessageBox");
		var oModel = this.getOwnerComponent().getModel();

		//var oModel = new sap.ui.model.odata.ODataModel(this.getOwnerComponent().getModel("URL"));

		var oDataJSONModel = new sap.ui.model.json.JSONModel();
		var oSelect = new sap.m.Select();
		var oItem = new sap.ui.core.Item();

		oSelect = this.byId(field);
		oModel.read("getRecordsByFilters?$filter=systemName eq '" + systemname + "' and field eq '" + fieldname + "'" +
			" and filterName1 eq '" + filterName1 + "'" + " and filterValue1 eq '" + filterValue1 + "'", null, null, false,
			function(oData, oResponse) {
				//sap.ui.commons.MessageBox.alert(JSON.stringify(oData, null, 4));
				// create JSON model  
				oSelect.removeAllItems();
				oDataJSONModel.setData(oData);
				var object = oDataJSONModel.getProperty("/results");
				for (var i = 0; i < object.length; i++) {
					var obj = object[i];
					//sap.ui.commons.MessageBox.alert(JSON.stringify(obj.fieldValue, null, 4));
					var oItem = new sap.ui.core.Item();
					oItem.setKey(obj.idValue);
					oItem.setText(obj.fieldValue);
					oSelect.addItem(oItem);
				}
				oSelect.setSelectedItem(oItem);
			},
			function(oError) {
				sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
			});
	},
	/**
	 *@memberOf test.view.Master
	 */
	onSubmit: function() {
		//var oModel = new sap.ui.model.odata.ODataModel( this.getOwnerComponent().getModel("URL"),false);
		sap.ui.commons.MessageBox.alert("start submit:"+this.getOwnerComponent().getModel("URL"));
		var oModel = new  sap.ui.model.odata.ODataModel(this.getOwnerComponent().getModel("URL"), {
			json: true,
			contentType: "application/json"
		});
		//var oModel = this.getOwnerComponent().getModel();
		//var oDataJSONModel = new sap.ui.model.json.JSONModel();
		var oRecord = {};
		//sap.ui.commons.MessageBox.alert(JSON.stringify(this.getOwnerComponent().getModel("URL"), null, 4));
		oRecord.Description = "a";
		//oRecord.aTimeOfIncident = "a";
		//oRecord.causSeriousHarm = "a";
		//oRecord.situacontrolled = "a";
		/*
		oRecord.signifiIncident = "a";
		oRecord.offsiteincident = "a";
		oRecord.locationdetails = "a";
		oRecord.aCapitalProject = "a";
		oRecord.investiganeeded = "a";
		oRecord.WebfoSubmission = "a";
		oRecord.Location = "a";
		oRecord.SysType = "a";
		oRecord.NeaMissCategory = "a";
		oRecord.coMeasuresTaken = "a";
		oRecord.Department = "a";
		oRecord.subdepartment = "a";
		oRecord.Reporter = "a";
		oRecord.SafIncidentType = "a";
		oRecord.CapitalProject = "a";
		oRecord.SigIncConfirm = "a";
		oRecord.SystemName = "a";
*/
		oModel.create("dataManagerServices", oRecord, null, 
		function() {
			sap.ui.commons.MessageBox.alert("Success");
		}, function(oError) {
			sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
		});

	}
});