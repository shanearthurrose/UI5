sap.ui.define(["sap/ui/core/mvc/Controller"], function (Controller) {
	"use strict";
	return Controller.extend("testcamera.controller.View1", {
	
	getPosition: function() {
		var that = this;

		navigator.geolocation.getCurrentPosition(function onGeoSuccess(position){
			that.byId("txtLatitude").setText(position.coords.latitude);
			that.byId("txtLong").setText(position.coords.longitude);
			that.byId("txtAlt").setText(position.coords.altitude);
		}, function onGeoError(error){
			
		},
		{
			enableHighAccuracy: true
		});
	},
	
	onInit: function(){
		this.getPosition();
	},
	/*
	  call the kapsel barcode reader
	
	*/
	
	readBarcode: function(){
		 var that = this;  
    	var code = "";  
    cordova.plugins.barcodeScanner.scan(  
          function (result) {  
              code = result.text;  
              //this.console.log("This is the code: " + code);  
              that.byId("searchField").setText(code);  
              //that.onSearch();  
          },  
          function (error) {  
              //alert("Scanning failed: " + error);  
          }  
    );  
	},

	
	capturePhoto: function(){	
        var that = this;
 
		var oNav = navigator.camera;
		oNav.getPicture(function cameraSuccess(imageUri){
				var myImage = that.byId("myImage");
				myImage.setSrc("data:image/jpeg;base64," + imageUri);	
		}, function onFail(error){
		}, {
			quality: 20,
			destinationType: oNav.DestinationType.DATA_URL
		});
   
      this.getPosition();
  
	},
	

	
	getPhoto: function() {
		var that = this;
		var oNav = navigator.camera;
		oNav.getPicture(function onPhotoURISuccess(imageURI){
			var myImage = that.byId("myImage");
			myImage.setSrc(imageURI);
		}, function onFail(error){
			
		}, {
			quality: 20,
			destinationType: oNav.DestinationType.FILE_URI,
			sourceType: oNav.PictureSourceType.PHOTOLIBRARY
		});
	}

		
		
});
});