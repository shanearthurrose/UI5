sap.ui.define(["sap/ui/core/mvc/Controller"], function(Controller) {
	"use strict";
	return Controller.extend("permitAudit.controller.main", {
		/*
		 *  initial - prior to page load
		 */
		onInit: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			this.theTokenInput = this.getView().byId("location");
			this.theTokenInputid = this.getView().byId("locationid");
			this.setDropDown("na", "FragApplication_YesNoNAObject", "Caption", false);
			this.setDropDown("yesno", "PermitReview_YesNo10Object", "Caption", false);
			//	alert("yesno:"+this.getView().getModel("yesno").getProperty("/getRecord/fieldValue/0/"));
			if (this.getView().getModel("yesno").getProperty("/getRecord/0/fieldValue/") === "Yes") {
				this.yesGuid = this.getView().getModel("yesno").getProperty("/getRecord/0/idValue/");
			} else {
				this.noGuid = this.getView().getModel("yesno").getProperty("/getRecord/0/idValue/");
			}

			if (this.getView().getModel("yesno").getProperty("/getRecord/1/fieldValue/") === "Yes") {
				this.yesGuid = this.getView().getModel("yesno").getProperty("/getRecord/1/idValue/");
			} else {
				this.noGuid = this.getView().getModel("yesno").getProperty("/getRecord/1/idValue/");
			}
			
			var oRouter = this.getOwnerComponent().getRouter();

			oRouter.attachRouteMatched(function(oEvent) {
				if (oEvent.getParameter("name") !== "main") {
					return;
				}
				this._selectItemWithId(oEvent.getParameter("arguments"));
			}, this);			


		},
		
		_selectItemWithId: function(arg) {
		//	this.setDropDownFilter("reportedby", "SysEmployeeEntity", "FullName", "Email", this.getOwnerComponent().userid, "", "", true, true);
		},		

		onBeforeRendering: function() {
			//var oReportedBy = new sap.m.Input();
			//oReportedBy = this.byId("reportedby");
			//oReportedBy.setValue(this.getOwnerComponent().getModel("userInfo").getProperty("/displayName"));
			var today = new Date();
			var dd = today.getDate();
			var MM = today.getMonth() + 1;
			if (MM < 10) {
				MM = "0" + MM;
			}
			var yyyy = today.getFullYear();
			var hh = today.getHours();
			var mm = today.getMinutes();
			var ss = today.getSeconds();
			this.byId("date").setDateValue(new Date());
			//			this.byId("reviewdate").setDateValue(new Date());
			//			this.byId("time").setDateValue(new Date());

		},
		//this.onReportTypeChange();
		//sap.ui.commons.MessageBox.alert("after: " + this.getOwnerComponent().getModel("userInfo").getProperty("/displayName"));				
		onAfterRendering: function() {

			this.getOwnerComponent().setDropDownFilter("reportedby", "SysEmployeeEntity", "FullName", "Email", this.getOwnerComponent().userid, "", "", true, true);
			this.setLocation("location", "SysEmployeeEntity", "Location", "Email", this.getOwnerComponent().userid, "", "", true);


			//this.getView().byId("locationid").setValue()				
		},
		
		setLocation: function(field, systemname, fieldname, filterName1, filterValue1, filterName2, filterValue2, async) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var query = "/rest/commonIntelex/restIntelex/getRecordsByFilter?systemName=" + systemname + "&Field=" + fieldname + "&filterName=" +
				filterName1 + "&filterValue=" + filterValue1;
			// + "&filterName=" + filterName2 + "&filterValue=" + filterValue2,;
			if (filterName2 !== "") {
				query += "&filterName=" + filterName2 + "&filterValue=" + filterValue2;
			}

			var oXML = new sap.ui.model.xml.XMLModel();
			that.getView().setModel(oXML, field);

			this.byId(field).setBusy(true);

			//	sap.ui.commons.MessageBox.alert("field:"+field+"query:"+query);

			oModel.read(query, null, null, async, function(oData, oResponse) {
				oDataJSONModel.setData(oResponse);
				var obody = oDataJSONModel.getProperty("/body");
				//	sap.ui.commons.MessageBox.alert(JSON.stringify("field:"+field + obody, null, 4));
				//
				//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
				//
				var oXMLModel = new sap.ui.model.xml.XMLModel();
				oXMLModel.setXML(obody);
				that.getView().setModel(oXMLModel, field);
				that.byId(field).setBusy(false);

				var oLocationInput = new sap.m.Input();
				oLocationInput = that.byId("location");

				var oDepartmentSelect = new sap.ui.commons.ComboBox();

				oDepartmentSelect = that.byId("department");

				if (oLocationInput.getValue()) {
					that.setDropDownFilter("locationid", "SysLocationEntity", "Name", "Name", oLocationInput.getValue(), "", "", true, false);
					//oDepartmentSelect.removeAllItems();
					debugger
					that.setDepartment("department", "hciMastIncdntv6_IMDepartmentObject", "DepartmentName", "location", oLocationInput.getValue(),
						"", "", false);

				}
			}, function(oError) {
				that.byId(field).setBusy(false);
				//		sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
			});
		},
		setDepartment: function(field, systemname, fieldname, filterName1, filterValue1, filterName2, filterValue2, async) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var query = "/rest/commonIntelex/restIntelex/getRecordsByFilter?systemName=" + systemname + "&Field=" + fieldname + "&filterName=" +
				filterName1 + "&filterValue=" + filterValue1;
			// + "&filterName=" + filterName2 + "&filterValue=" + filterValue2,;
			if (filterName2 !== "") {
				query += "&filterName=" + filterName2 + "&filterValue=" + filterValue2;
			}

			var oXML = new sap.ui.model.xml.XMLModel();
			that.getView().setModel(oXML, field);

			this.byId(field).setBusy(true);

			//	sap.ui.commons.MessageBox.alert("field:"+field+"query:"+query);

			oModel.read(query, null, null, async, function(oData, oResponse) {
				oDataJSONModel.setData(oResponse);
				var obody = oDataJSONModel.getProperty("/body");
				//	sap.ui.commons.MessageBox.alert(JSON.stringify("field:"+field + obody, null, 4));
				//
				//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
				//
				var oXMLModel = new sap.ui.model.xml.XMLModel();
				oXMLModel.setXML(obody);
				that.getView().setModel(oXMLModel, field);
				that.byId(field).setBusy(false);
				var oLocationInput = new sap.m.Input();
				oLocationInput = that.byId("location");

				var oDepartmentSelect = new sap.ui.commons.ComboBox();

				oDepartmentSelect = that.byId("department");

				if (oDepartmentSelect.getItems().length > 0) {
					var items = oDepartmentSelect.getItems();
					//	sap.ui.commons.MessageBox.alert(items[0].getText());
					that.setDropDownFilter("area", "FragApplication_SubDepartmentObject", "SDepartmentName", "department", items[0].getText(),
						"location", oLocationInput.getValue(), false, true); //this.onDepartmentChange();
				}
			}, function(oError) {
				that.byId(field).setBusy(false);
				//		sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
			});
		},		
		/**
		 *@memberOf nearmiss.controller.main
		 */
		onLocationChange: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var oLocationInput = new sap.m.Input();
			oLocationInput = this.byId("location");
			var oDepartmentSelect = new sap.ui.commons.ComboBox();
			oDepartmentSelect = this.byId("department");
			//	oDepartmentSelect.removeAllItems();

			//sap.m.MessageToast.show("loc:"+oLocationInput.getValue());

			if (oLocationInput.getValue() !== "") {
				//oDepartmentSelect.removeAllItems();
				this.setDepartment("department", "hciMastIncdntv6_IMDepartmentObject", "DepartmentName", "location", oLocationInput.getValue(),
					"", "", true);
			}
		},
		/*
		  when the Department changes 
		*/
		/*
		  when the Department changes 
		*/
		onDepartmentChange: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var oLocationInput = new sap.m.Input();
			oLocationInput = this.byId("location");
			var oDepartmentSelect = new sap.ui.commons.ComboBox();
			oDepartmentSelect = this.byId("department");
			this.setDropDownFilter("area", "FragApplication_SubDepartmentObject", "SDepartmentName", "department", oDepartmentSelect.getValue(),
				"location", oLocationInput.getValue(), false, true);
		},
		/*
		 *
		 * Set drop down values (coming from Sequis database Via WebMethods)
		 *
		 */
		setDropDown: function(field, systemname, fieldname, async) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			oModel.read("/rest/commonIntelex/restIntelex/getRecords?systemName=" + systemname + "&Field=" + fieldname, //				"/odata/commonIntelex.odata:ointelex/getRecords?$filter=systemName eq '" + systemname + "' and field eq '" + fieldname + "'",
				null, null, async,
				function(oData, oResponse) {
					// create JSON model  
					oDataJSONModel.setData(oResponse);
					var obody = oDataJSONModel.getProperty("/body");
					//	sap.ui.commons.MessageBox.alert(JSON.stringify("field:"+field + obody, null, 4));
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					var oXMLModel = new sap.ui.model.xml.XMLModel();
					oXMLModel.setXML(obody);
					that.getView().setModel(oXMLModel, field);
				},
				function(oError) {});
		},
		/*
		 *
		 * Set drop down values (coming from Sequis database Via WebMethods)
		 *
		 */
		setDropDownFilter: function(field, systemname, fieldname, filterName1, filterValue1, filterName2, filterValue2, async) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var query = "/rest/commonIntelex/restIntelex/getRecordsByFilter?systemName=" + systemname + "&Field=" + fieldname + "&filterName=" +
				filterName1 + "&filterValue=" + filterValue1;
			// + "&filterName=" + filterName2 + "&filterValue=" + filterValue2,;
			if (filterName2 !== "") {
				query += "&filterName=" + filterName2 + "&filterValue=" + filterValue2;
			}

			var oXML = new sap.ui.model.xml.XMLModel();
			that.getView().setModel(oXML, field);

			oModel.read(query, null, null, async, function(oData, oResponse) {
				oDataJSONModel.setData(oResponse);
				var obody = oDataJSONModel.getProperty("/body");
				//	sap.ui.commons.MessageBox.alert(JSON.stringify("field:"+field + obody, null, 4));
				//
				//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
				//
				var oXMLModel = new sap.ui.model.xml.XMLModel();
				oXMLModel.setXML(obody);
				that.getView().setModel(oXMLModel, field);
			}, function(oError) {
				//		sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
			});
		},
		onSubmit2: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			jQuery.sap.require("sap.m.MessageToast");
			//sap.m.MessageToast.show("start");
			var that = this;
			var returnguid;
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			oModel.setHeaders({
				"X-Requested-With": "X"
			});
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var oXMLModel = new sap.ui.model.xml.XMLModel();
			var oRecord = {};
			var nameVal = [];
			var systemName = "PermitReview_PermitReviewObject";
			var objectId = "30d61d40-ec9d-4626-ac31-1b3442506ad1";
			/*
			  Set the AUDIT fields
			*/
			if (!this._validateComments()) {
				sap.m.MessageToast.show("Enter all mandatory fields");
				return;
			}
			/*
			   set the sequis field names and values
			*/
			nameVal = this._setAuditRecord();

			sap.m.MessageToast.show("submitting Audit record");

			oRecord.nameVal = nameVal;
			//oRecord.systemName = "SafetyIncident_SafetyIncidentObject"; // for safety
			oRecord.systemName = systemName;
			// for safety				
			//sap.m.MessageToast.show("About to save Recorded");
			sap.m.MessageToast.show("Preparing Audit Record ...");
			this._createAudit(oRecord, objectId, systemName);

		},
		_createAudit: function(oRecord, objectId, systemName) {
			jQuery.sap.require("sap.ui.core.BusyIndicator");
			var that = this;
			var returnguid;
			var sServiceUrl = "/destinations/WebMethods";
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var oXMLModel = new sap.ui.model.xml.XMLModel();
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			oModel.setHeaders({
				"X-Requested-With": "X"
			});

			//that.getRouter().navTo("result", {}, false);

			jQuery.sap.delayedCall(1000, this, function() {
				var query = "/rest/commonIntelex/restIntelex/dataManagerServices";
				oModel.create(query, oRecord, null, function(oData, oResult) {
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oResult, null, 4));
					oDataJSONModel.setData(oResult);
					var obody = oDataJSONModel.getProperty("/body");
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					oXMLModel.setXML(obody);

					//sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));

					that.getView().setModel(oXMLModel.getProperty("/"), "guid");
					returnguid = oXMLModel.getProperty("/");

					if (that.byId("myImage").getSrc() !== null && that.byId("myImage").getSrc() !== "") {
						//sap.ui.commons.MessageBox.alert("srce:" + this.byId("myImage").getSrc());
						that._uploadImage("audit.jpg", returnguid, objectId, that.byId("myImage").getSrc());
					}

					//					that.setDropDownFilter("workflow", systemName, "Workflow.CurrentStageId", "id", returnguid, "", "", false);
					//					that.setDropDownFilter("nextworkflow", "SysWorkflowStageActionEntity", "", "stageId", that.getView().getModel("workflow").getProperty(
					//						"/getRecordsByFilter/fieldValue"), "", "", false);
					//					that._issueWorkflow(systemName, that.getView().getModel("nextworkflow").getProperty("/getRecordsByFilter/idValue"),
					//						returnguid);

					sap.ui.core.BusyIndicator.hide();

					//that._setRisk();
					that.getOwnerComponent().getRouter().navTo("result", {}, false);

					//sap.ui.commons.MessageBox.alert("JSRA Successfully Submitted:");
					//sap.ui.commons.MessageBox.alert("JSRA Successfully Submitted:" + returnguid + "Obj:" + objectId);					
					//sap.m.MessageToast.show("JSRA Successfully Submitted");
				}, function(oError) {
					sap.ui.core.BusyIndicator.hide();
					sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				}, true);

			});

			sap.ui.core.BusyIndicator.show(100);

		},
		_setInterlexField: function(record, field, value, id) {
			if (!id === null && !id === "") {
				if (this.byId(id).getVisible()) {
					record[record.length] = this._addField(field, value);
				}
			} else {
				record[record.length] = this._addField(field, value);
			}
		},

		/*
		   add field for Save 
		*/
		_addField: function(field, value) {
			var name = {};
			name.name = field;
			name.value = value;
			return name;
		},
		/*
		 * handle search for location field
		 *
		 */
		handleLocationPress: function(oEvent) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var oXMLModel = new sap.ui.model.xml.XMLModel();
			var showBusy = false;
			if (!this._oDialog) {
				oModel.read("/rest/commonIntelex/restIntelex/getRecords?systemName=SysLocationEntity&Field=Name", null, null, true, function(oData,
					oResponse) {
					// create JSON model  
					oDataJSONModel.setData(oResponse);
					var obody = oDataJSONModel.getProperty("/body");
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					oXMLModel.setXML(obody);
					sap.ui.core.BusyIndicator.hide();
				}, function(oError) {
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				});
				this._oDialog = sap.ui.xmlfragment("permitAudit.view.locationSelect", this);
				//this._oDialog.setModel(this.getView().getModel());
				this._oDialog.setModel(oXMLModel);
				showBusy = true;
			}
			// clear the old search filter
			this._oDialog.getBinding("items").filter([]);
			// toggle compact style
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog);
			this._oDialog.open();
			if (showBusy) {
				sap.ui.core.BusyIndicator.show();
			}
		},
		handleLocationSearch: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilterName = new sap.ui.model.Filter("fieldValue", sap.ui.model.FilterOperator.Contains, sValue);
			var oFilter = new sap.ui.model.Filter({
				filters: [oFilterName],
				and: false
			});
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		},
		handleLocationClose: function(oEvent) {
			var that = this;
			var aContexts = oEvent.getParameter("selectedContexts");
			if (aContexts && aContexts.length) {
				that.theTokenInput.setValue(aContexts.map(function(oContext) {
					//return oContext.getObject().fieldValue;
					return oContext.getModel().getProperty(oContext.getPath() + "/fieldValue");
				}));
				that.theTokenInputid.setText(aContexts.map(function(oContext) {
					//return oContext.getObject().fieldValue;
					return oContext.getModel().getProperty(oContext.getPath() + "/idValue");
				}));
				that.onLocationChange();
			}
			oEvent.getSource().getBinding("items").filter([]);
		},

		onMismatch: function(e) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			sap.ui.commons.MessageBox.alert("mismatch");
		},
		onExceed: function(e) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			sap.ui.commons.MessageBox.alert("file name exceed");
		},
		onUploadCompleteFUP: function(e) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			//	sap.ui.commons.MessageBox.alert("Photo added");
			this.byId("photo1").clear();
		},
		onUploadCompleteFUP1: function(e) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			//	sap.ui.commons.MessageBox.alert("Photo added");
			//	this.byId("photo2").clear();
		},
		onSizeExceed: function(e) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			sap.ui.commons.MessageBox.alert("size exceed");
		},
		onChangeFUP: function(e) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			//			sap.ui.commons.MessageBox.alert("uploading");
			//			this.byId("photo1").clear();
			var output = this.byId("myImage");
			this._import(e.getParameter("files") && e.getParameter("files")[0], "myImage"); //this.byId("fileupload").attachChange("onChangeFUP");
		},
		onChangeFUP1: function(e) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			//			this.byId("photo2").clear();
			var output = this.byId("myImage1");
			this._import(e.getParameter("files") && e.getParameter("files")[0], "myImage1");
		},
		_import: function(file, id) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;

			if (file) {
				var reader = new FileReader();
				//	var reader = new FileReader();
				reader.onload = function() {
					var dataURL = reader.result;
					var output = that.byId(id);
					output.setSrc(dataURL);
				};
				reader.readAsDataURL(file);
			}
		},
		/**
		 *@memberOf nearmiss.controller.main
		 */
		onClearImage: function() {
			//This code was generated by the layout editor.
			var output = this.byId("myImage");
			output.setSrc();
		},

		onUndoPhoto: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			sap.m.MessageToast.show("reset");
			var output = this.byId("myImage");
			output.setSrc("./images/noimage.png");
			this.byId("photo1").clear();
		},
		/*
		  validate form
		*/
		_validateForm: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			//this._validateField("reportedby");
			var valid = true;
			if (this.byId("onsitejob").getState()) {
				if (!this._validateField("location"))
					valid = false;
			}

			if (!this.byId("lionemployee").getState()) {
				this._validateField("contractorcompany");
				this._validateField("contractorname");
			}

			if (!this._validateField("exactlocation"))
				valid = false;

			if (!this._validateField("exactlocation"))
				valid = false;

			if (!this._validateField("detailofwork"))
				valid = false;
			//	if (!this._validateField("additionalcontrols"))
			//		valid = false;
			if (!this._validateField("reviewdate"))
				valid = false;

			if (this.byId("isolations").getValue() !== "N/A") {
				if (!this._validateField("isolationpoints"))
					valid = false;
			} else {
				this.byId("isolationpoints").setValueState(sap.ui.core.ValueState.None);
			}

			if (!this._validateField("equipment"))
				valid = false;

			if (this.byId("controlmeasures").getSelectedKey() === " ") {
				this.byId("controlmeasures").setValueState(sap.ui.core.ValueState.Error);
				valid = false;
			} else {
				this.byId("controlmeasures").setValueState(sap.ui.core.ValueState.None);
			}
			return valid;
		},
		/*
		Function: _validateDate
		Parameters: none
		
		Returns Boolean value based on the date being less than today or not
		True - if date/time is less than today
		False - if date/time in the future
		
		
		*/
		_validateDate: function() {
			var valid = true;
			var dd = this.byId("date").getValue()[6] + this.byId("date").getValue()[7];
			var MM = this.byId("date").getValue()[4] + this.byId("date").getValue()[5];
			MM = parseInt(MM) - 1;
			var yyyy = this.byId("date").getValue()[0] + this.byId("date").getValue()[1] + this.byId("date").getValue()[2] + this.byId("date").getValue()[
				3];
			var hh = "00";
			var mm = "00";
			var DateTime;
			DateTime = new Date(yyyy, MM, dd, hh, mm, 0);
			var today = new Date();
			var DateTime_ms = DateTime.getTime();
			var today_ms = today.getTime();
			if (DateTime_ms > today_ms) {
				this.byId("date").setValueState(sap.ui.core.ValueState.Error);
				valid = false;
			}
			return valid;
		},
		/*
		  Function: _validateField
		  Parameters: 
			field - field name to perform validation on, currently checks if there is a value or not
			
		  Returns Boolean value
		*/
		_validateField: function(field) {
			var oInput = new sap.m.Input();
			oInput = this.byId(field);
			if (oInput.getVisible()) {
				if (oInput.getValue() === "") {
					oInput.setValueState(sap.ui.core.ValueState.Error);
					return false;
				} else {
					oInput.setValueState(sap.ui.core.ValueState.None);
				}
			}
			return true;
		},
		/**
		 *@memberOf nearmiss.controller.main
		 */
		onCategoryChange: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var oCategorySelect = new sap.m.Select();
			oCategorySelect = this.byId("category");
			var osubcategorySelect = new sap.m.Select();
			osubcategorySelect = this.byId("subcategory");
			if (osubcategorySelect.getVisible()) {
				this.setDropDownFilter("subcategory", "QualiIncidentV6_QualityCat2Object", "QualitCategory2", "QualityCat1", oCategorySelect.getValue(),
					"", "", false);
			}
		},
		/**
		 *@memberOf nearmiss.controller.main
		 */
		onCapitonWorksChange: function() {
			//This code was generated by the layout editor.
			this.byId("projectname").setVisible(false);
			this.byId("__labelprojectname").setVisible(false);
			if (!this.byId("capital").getState() && this.byId("capital").getVisible()) {
				this.byId("projectname").setVisible(true);
				this.byId("__labelprojectname").setVisible(true);
			}
		},
		onSiteChange: function() {
			//This code was generated by the layout editor.
			this.byId("location").setVisible(false);
			this.byId("__labellocation").setVisible(false);
			this.byId("department").setVisible(false);
			this.byId("__labeldepartment").setVisible(false);
			this.byId("area").setVisible(false);
			this.byId("__labelarea").setVisible(false);
			if (!this.byId("onsite").getState()) {
				this.byId("location").setVisible(true);
				this.byId("__labellocation").setVisible(true);
				this.byId("department").setVisible(true);
				this.byId("__labeldepartment").setVisible(true);
				this.byId("area").setVisible(true);
				this.byId("__labelarea").setVisible(true);
			}
		},
		onControlChange: function() {
			//This code was generated by the layout editor.
			this.byId("__labelexp").setVisible(false);
			this.byId("notcontrolled").setVisible(false);
			if (this.byId("reporttype").getValue() === "Environment") {
				if (this.byId("controlled").getState()) {
					this.byId("__labelexp").setVisible(true);
					this.byId("notcontrolled").setVisible(true);
				}
			}
		},
		/*
		  Function: _issueWorkflow
		  Parameters: 
			SystemName - Name of the system in Sequis
			actionId - guid of the next workflow item
			guid - Guid of the record in sequis that workflow is for 
		
		*/
		_issueWorkflow: function(SystemName, actionId, guid) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			oModel.setHeaders({
				"X-Requested-With": "X"
			});
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var oXMLModel = new sap.ui.model.xml.XMLModel();
			var oRecord = {};
			oRecord.systemName = SystemName;
			oRecord.actionId = actionId;
			oRecord.guid = guid;
			//sap.ui.commons.MessageBox.alert("workFlow");
			var query = "/rest/commonIntelex/restIntelex/workflowService";
			oModel.create(query, oRecord, null, function(oData, oResult) {
				//sap.ui.commons.MessageBox.alert(JSON.stringify(oResult, null, 4));
				oDataJSONModel.setData(oResult);
				var obody = oDataJSONModel.getProperty("/body"); //sap.ui.commons.MessageBox.alert(JSON.stringify(oResult, null, 4));
				//
				//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
				//
				//oXMLModel.setXML(obody);
				//sap.ui.commons.MessageBox.alert("guid:"+oXMLModel.getProperty("/"));
				//that.getView().setModel(oXMLModel.getProperty("/"), "guid");
				//sap.ui.commons.MessageBox.alert("Incident Success Recorded");
			}, function(oError) {
				//	sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
			});
		},
		/*
		  Function: _uploadImage
		  Parameters: 
		   Filename - Name of the file when attching to sequis
		   RecordId - the guid of the record in sequis where the attachment will be 
		   ObjectId - the guid of the sequis type
		   Source - the source base64 of the image
		   
		*/
		_uploadImage: function(Filename, RecordId, ObjectId, Source) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			oModel.setHeaders({
				"X-Requested-With": "X"
			});
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var oXMLModel = new sap.ui.model.xml.XMLModel();
			var oRecord = {};
			oRecord.Filename = Filename;
			// for safety
			oRecord.RecordId = RecordId;
			oRecord.ObjectId = ObjectId;
			oRecord.Source = Source;
			//	sap.ui.commons.MessageBox.alert("JSRA RecordID:" + oRecord.RecordId + "Obj:" + oRecord.ObjectId);								
			//sap.ui.commons.MessageBox.alert("workFlow");
			var query = "/rest/commonIntelex/restIntelex/PrivateDocumentAttachmentService";
			oModel.create(query, oRecord, null, function(oData, oResult) {
				//sap.ui.commons.MessageBox.alert(JSON.stringify(oResult, null, 4));
				oDataJSONModel.setData(oResult);
				var obody = oDataJSONModel.getProperty("/body"); //	sap.ui.commons.MessageBox.alert(JSON.stringify(oResult, null, 4));
			}, function(oError) {
				//	sap.ui.commons.MessageBox.alert("Image Error:" + JSON.stringify(oError, null, 4));
			});
		},
		/*
		  @todo 
		  This will set all fields for JSRA in sequis.
		*/
		_setAuditRecord: function() {
			var nameVal = [];
			var now = new Date();
			// date 
			var dd = this.byId("date").getValue()[6] + this.byId("date").getValue()[7];
			var MM = this.byId("date").getValue()[4] + this.byId("date").getValue()[5];
			//	MM = parseInt(MM) - 1;
			var yyyy = this.byId("date").getValue()[0] + this.byId("date").getValue()[1] + this.byId("date").getValue()[2] + this.byId("date").getValue()[
				3];

			var hh = now.getHours();
			var mm = now.getMinutes();
			//	alert(hh +":" + mm);

			var myDate = new Date(MM + '/' + dd + '/' + yyyy + ' ' + hh + ':' + mm + ':00');

			//			var newDate = dd + '/' + MM + '/' + yyyy + ' ' + hh + ':' + mm + ':00';
			//var myDate = new Date(MM + "/" + dd + "/" + yyyy);
			//var myDate = new Date(MM + "/" + dd + "/" + yyyy + " " + hh + ":" + mm + ":00");			
			var month = myDate.getUTCMonth() + 1;
			//Month is between 0 - 11
			var newDate = myDate.getUTCDate() + "/" + month + "/" + myDate.getUTCFullYear() + " " + myDate.getUTCHours() + ":" + myDate.getUTCMinutes() +
				":00";

			var i = 0;

			nameVal[i] = this._addField("Completedby", this.byId("reportedby").getSelectedKey());
			i++;
			nameVal[i] = this._addField("Location", this.byId("locationid").getText());
			i++;
			nameVal[i] = this._addField("Department", this.byId("department").getSelectedKey());
			i++;
			nameVal[i] = this._addField("subDepartment", this.byId("area").getSelectedKey());
			i++;
			nameVal[i] = this._addField("ExactLocation", this.byId("exactlocation").getValue());
			i++;
			nameVal[i] = this._addField("Date", newDate);
			i++;
			nameVal[i] = this._addField("PermittoWorkNo", this.byId("permitnumber").getValue());
			/**************************************************************************************************/

			//	alert("here");
			i++;
			nameVal[i] = this._addField("HotWork", this.byId("hotwork").getState() ? "yes" : "no");
			i++;
			nameVal[i] = this._addField("WorkinatHeights", this.byId("workingatheight").getState() ? "yes" : "no");
			i++;
			nameVal[i] = this._addField("LockOutTagOut", this.byId("lockouttagout").getState() ? "yes" : "no");
			i++;
			nameVal[i] = this._addField("Excavation", this.byId("excavation").getState() ? "yes" : "no");
			i++;
			nameVal[i] = this._addField("ContaiUnloading", this.byId("containerunloading").getState() ? "yes" : "no");
			i++;
			nameVal[i] = this._addField("SandwiPanelling", this.byId("sandwichpanelling").getState() ? "yes" : "no");
			i++;
			nameVal[i] = this._addField("JSRA", this.byId("jobstart").getState() ? "yes" : "no");
			i++;
			nameVal[i] = this._addField("ConfinedSpace", this.byId("confinedspace").getState() ? "yes" : "no");
			i++;
			nameVal[i] = this._addField("Penetration", this.byId("penetration").getState() ? "yes" : "no");
			i++;
			nameVal[i] = this._addField("SWMS", this.byId("swms").getState() ? "yes" : "no");

			/**************************************************************************************************/
			i++; //object yesno10Object
			nameVal[i] = this._addField("Documeavailable", this.byId("q1").getState() ? this.yesGuid : this.noGuid);
			i++; //object yesno10Object
			nameVal[i] = this._addField("CommDocAvail", this.byId("q1comment").getValue());

			i++; //object yesno10Object
			nameVal[i] = this._addField("Sectioncomplete", this.byId("q2").getState() ? this.yesGuid : this.noGuid);
			i++;
			nameVal[i] = this._addField("ComSectionscomp", this.byId("q2comment").getValue());

			i++; //object yesno10Object
			nameVal[i] = this._addField("ItemsNA", this.byId("q3").getState() ? this.yesGuid : this.noGuid);
			i++;
			nameVal[i] = this._addField("CommItemsNA", this.byId("q3comment").getValue());

			i++; //object yesno10Object
			nameVal[i] = this._addField("AssociatedDocs", this.byId("q4").getState() ? this.yesGuid : this.noGuid);
			i++;
			nameVal[i] = this._addField("CommAssoDocs", this.byId("q4comment").getValue());
			/**********************************************************************************************/

			i++; //object yesno10Object
			nameVal[i] = this._addField("PermitIssuer", this.byId("q5").getState() ? this.yesGuid : this.noGuid);
			i++;
			nameVal[i] = this._addField("ComPermitIssuer", this.byId("q5comment").getValue());

			i++; //object yesno10Object
			nameVal[i] = this._addField("Alpermitsissued", this.byId("q6").getState() ? this.yesGuid : this.noGuid);
			i++;
			nameVal[i] = this._addField("CommAppropPerm", this.byId("q6comment").getValue());

			i++; //object yesno10Object
			nameVal[i] = this._addField("PeUsersInducted", this.byId("q7").getState() ? this.yesGuid : this.noGuid);
			i++;
			nameVal[i] = this._addField("CommUsersInduct", this.byId("q7comment").getValue());

			i++; //object yesno10Object
			nameVal[i] = this._addField("Pdetailscorrect", this.byId("q8").getState() ? this.yesGuid : this.noGuid);
			i++;
			nameVal[i] = this._addField("ComPermitdetail", this.byId("q8comment").getValue());

			i++; //object yesno10Object
			nameVal[i] = this._addField("SWMSavailable", this.byId("q9").getState() ? this.yesGuid : this.noGuid);
			i++;
			nameVal[i] = this._addField("CommSWMS", this.byId("q9comment").getValue());

			i++; //object yesno10Object
			nameVal[i] = this._addField("PPEworn", this.byId("q10").getState() ? this.yesGuid : this.noGuid);
			i++;
			nameVal[i] = this._addField("CommPPE", this.byId("q10comment").getValue());

			i++; //object yesno10Object
			nameVal[i] = this._addField("Monitoriinplace", this.byId("q11").getState() ? this.yesGuid : this.noGuid);
			i++;
			nameVal[i] = this._addField("CommMonitoring", this.byId("q11comment").getValue());

			i++; //object yesno10Object
			nameVal[i] = this._addField("Gastestingdocum", this.byId("q12").getSelectedKey());
			i++;
			nameVal[i] = this._addField("CommGastesting", this.byId("q12comment").getValue());

			i++; //object yesno10Object
			nameVal[i] = this._addField("Noscopecreep", this.byId("q13").getState() ? this.yesGuid : this.noGuid);
			i++;
			nameVal[i] = this._addField("CommScopecreep", this.byId("q13comment").getValue());

			i++; //object yesno10Object
			nameVal[i] = this._addField("Controlsapplied", this.byId("q14").getState() ? this.yesGuid : this.noGuid);
			i++;
			nameVal[i] = this._addField("CommControlsapp", this.byId("q14comment").getValue());

			i++; //object yesno10Object
			nameVal[i] = this._addField("sourcesisolated", this.byId("q15").getSelectedKey());
			i++;
			nameVal[i] = this._addField("CommEnergyisola", this.byId("q15comment").getValue());

			i++; //object yesno10Object
			nameVal[i] = this._addField("Isolationtested", this.byId("q16").getSelectedKey());
			i++;
			nameVal[i] = this._addField("CommIsolattestd", this.byId("q16comment").getValue());

			i++; //object yesno10Object
			nameVal[i] = this._addField("JSRAused", this.byId("q17").getSelectedKey());
			//	nameVal[i] = this._addField("JSRAused", this.byId("q17").getState()  ? this.yesGuid : this.noGuid);
			i++;
			nameVal[i] = this._addField("CommJSRA", this.byId("q17comment").getValue());

			i++; //object yesno10Object
			nameVal[i] = this._addField("RescPlaninplace", this.byId("q18").getSelectedKey());
			i++;
			nameVal[i] = this._addField("CommRescuePlan", this.byId("q18comment").getValue());

			i++; //object yesno10Object
			nameVal[i] = this._addField("Workareassafe", this.byId("q19").getState() ? this.yesGuid : this.noGuid);
			i++;
			nameVal[i] = this._addField("CommAreasafe", this.byId("q19comment").getValue());

			i++; //object yesno10Object
			nameVal[i] = this._addField("Barrierandsigns", this.byId("q20").getSelectedKey());
			i++;
			nameVal[i] = this._addField("CommBarriers", this.byId("q20comment").getValue());

			i++; //object yesno10Object
			nameVal[i] = this._addField("EquipmentSafe", this.byId("q21").getState() ? this.yesGuid : this.noGuid);
			i++;
			nameVal[i] = this._addField("CommEquipSafe", this.byId("q21comment").getValue());

			i++; //object yesno10Object
			nameVal[i] = this._addField("Areaassessed", this.byId("q22").getState() ? this.yesGuid : this.noGuid);
			i++;
			nameVal[i] = this._addField("CommAreaassessd", this.byId("q22comment").getValue());

			i++;
			nameVal[i] = this._addField("CAPASrequired", this.byId("capa").getState() ? "yes" : "no");

			i++;
			nameVal[i] = this._addField("Generalcomments", this.byId("comments").getValue());

			return nameVal;
		},
		/**
		 *@memberOf jsra.controller.main
		 */
		onClearSignature: function() {
			//This code was generated by the layout editor.
			//sap.ui.commons.MessageBox.alert(this.byId("reviewedby").save());
			this.byId("reviewedby").clear();
		},
		undoSig: function() {
			//This code was generated by the layout editor.
			//sap.ui.commons.MessageBox.alert(this.byId("reviewedby").save());
			this.byId("reviewedby").clear();

		},
		undoSig1: function() {
			//This code was generated by the layout editor.
			//sap.ui.commons.MessageBox.alert(this.byId("reviewedby").save());
			this.byId("reviewedby1").clear();
		},

		undoPhoto: function() {
			this.byId("myImage").setSrc();
		},

		onSwitchChange: function(ev) {
			//	alert("change(no guid)"+this.noGuid + "yes:"+this.yesGuid);
			//		alert("yesno:"+this.getView().getModel("yesno").getProperty("/getRecord/fieldValue/0/"));
			var commentId = ev.getSource().getId() + 'comment';

			if (ev.getSource().getState()) {
				this.byId(commentId).setVisible(false);
			} else {
				this.byId(commentId).setVisible(true);
			}

		},
		_validateComments: function() {
			var valid = true;
			for (var i = 1; i < 23; i++) {

				var commentId = "q" + i + "comment";
				if (this.byId(commentId).getVisible() && this.byId(commentId).getValue() === "") {
					this.byId(commentId).setValueState(sap.ui.core.ValueState.Error);
					valid = false;
				} else {
					this.byId(commentId).setValueState(sap.ui.core.ValueState.None);
				}
			}

			if (this.byId("exactlocation").getValue() === "") {
				this.byId("exactlocation").setValueState(sap.ui.core.ValueState.Error);
				valid = false;
			} else {
				this.byId("exactlocation").setValueState(sap.ui.core.ValueState.None);
			}

			if (this.byId("permitnumber").getValue() === "") {
				this.byId("permitnumber").setValueState(sap.ui.core.ValueState.Error);
				valid = false;
			} else {
				this.byId("permitnumber").setValueState(sap.ui.core.ValueState.None);
			}

			return valid;

		},

		onChangeDropdown: function(ev) {
			var commentId = ev.getSource().getId() + 'comment';
			var messageId = ev.getSource().getId() + 'message';

			if (ev.getSource().getValue() === "No") {
				this.byId(commentId).setVisible(true);
				this.byId(messageId).setVisible(true);
			} else {
				this.byId(commentId).setVisible(false);
				this.byId(messageId).setVisible(false);
			}
		}

	});
});