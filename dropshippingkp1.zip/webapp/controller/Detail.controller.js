/*global location */
sap.ui.define([
	"masterdetail/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"masterdetail/model/formatter",
	"sap/ui/model/json/JSONModel",
	"jquery.sap.global",
	"sap/m/MessagePopover",
	"sap/m/MessagePopoverItem"
], function(BaseController, JSONModel, formatter, jQuery, MessagePopover, MessagePopoverItem, Link, MessageBox) {
	"use strict";
	var oLink = new sap.m.Link({
		text: "Show more information",
		href: "http://sap.com",
		target: "_blank"
	});

	var oMessageTemplate = new sap.m.MessagePopoverItem({
		type: '{type}',
		title: '{title}',
		description: '{description}',
		subtitle: '{subtitle}',
		counter: '{counter}',
		link: oLink
	});

	var oMessagePopover2 = new sap.m.MessagePopover({
		items: {
			path: '/',
			template: oMessageTemplate
		}
	});

	return BaseController.extend("masterdetail.controller.Detail", {

		formatter: formatter,
		_bText: {
			New: "Start Picking",
			Picking: "Invoice",
			Invoiced: "Create Label",
			Ticketed: "Dispatch"

		},

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit: function() {
			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data
			var oViewModel = new JSONModel({
				busy: false,
				delay: 0,
				lineItemListTitle: this.getResourceBundle().getText("detailLineItemTableHeading")
			});

			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

			this.setModel(oViewModel, "detailView");

			//this.getOwnerComponent().getModel().metadataLoaded().then(this._onMetadataLoaded.bind(this));
			this._onMetadataLoaded.bind(this);
			//this.setButtonStatus();
			var editModel = new sap.ui.model.json.JSONModel();
			editModel.setData({
				pqty: false
			});
			this.oTable = this.getView().byId("lineItemsList");
			this.oTable.setModel(editModel, 'editModel');

			/* Set the Global AJAX function to make the view busy whenever there is an AJAX call */

			$.ajaxSetup({
				beforeSend: function() {

					//	oViewModel.setProperty("/busy", true);
				},
				complete: function() {
					// hide gif here, eg:
					//oViewModel.setProperty("/busy", false);
				}

			});

			
		},
				TestClick:function(){
						//Copy Open Quantity to Picked Quantity
				this.populatePicking();
				// Make the Picked quantity field editable
				this.setEModel(true);
			
		},

		openInvoiceUrl: function() {
			/*
			var url = "ausalchemy.aunz.lncorp.net/AlchemyWeb/DownLoadFile.aspx?Database=New%20Zealand%20-%20Domestic&ID=26970";
			url = "/ausalchemy/application/uploads/2014/12/pdf-sample.pdf";

			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {

					var blob = new Blob([this.response], {
						type: "application/pdf"
					});
					var link = document.createElement('a');
					link.href = window.URL.createObjectURL(blob);
					link.download = "Invoice.pdf";
					link.click();
					xhr.responseType = 'arraybuffer';

				}
			};
			xhttp.open("GET", url, true);
			xhttp.responseType = 'arraybuffer';
			xhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
			xhttp.send();
			*/
		},

		openErrorDialog: function(errorMessage) {
			var dialog = new sap.m.Dialog({
				title: 'Error',
				type: 'Message',
				state: 'Error',
				content: new sap.m.Text({
					text: errorMessage
				}),
				beginButton: new sap.m.Button({
					text: 'OK',
					press: function() {
						dialog.close();
					}
				}),
				afterClose: function() {
					dialog.destroy();
				}
			});

			dialog.open();

		},

		onPdfExport: function(oEvent) {
			var that = this;
			var view = that.getView();

			var createHeaderData = function() {

				var emptyRow = [{
					text: "",
					style: 'superMargin'
				}, {
					text: "",
					style: 'superMargin'
				}, {
					text: "",
					style: 'superMargin'
				}, {
					text: "",
					style: 'superMargin'
				}, {
					text: "",
					style: 'superMargin'
				}, {
					text: "",
					style: 'superMargin'
				}, ];
				var row1 = [{
						text: "Order Date:",
						style: 'superMargin'
					}, {
						text: view.byId("orderDate").getText(),
						style: 'superMargin'
					}, {
						text: "Label:",
						style: 'superMargin'
					}, {
						text: view.byId("label").getText(),
						style: 'superMargin'
					}, {
						text: "Status:",
						style: 'superMargin'
					}, {
						text: view.byId("Status").getText(),
						style: 'superMargin'
					}

				];
				var row2 = [{
						text: "Delivery Date:",
						style: 'superMargin'
					}, {
						text: view.byId("deliveryDate").getText(),
						style: 'superMargin'
					}, {
						text: "Invoice:",
						style: 'superMargin'
					}, {
						text: view.byId("Invoice").getText(),
						style: 'superMargin'
					}, {
						text: "",
						style: 'superMargin'
					}, {
						text: "",
						style: 'superMargin'
					}

				];
				var row3 = [{
						text: "Delivery Address:",
						style: 'superMargin'
					}, {
						text: view.byId("deliveryAddress").getText(),
						style: 'superMargin'
					}, {
						text: "Tracking Number:",
						style: 'superMargin'
					}, {
						text: view.byId("trackingNumber").getText(),
						style: 'superMargin'
					}, {
						text: "",
						style: 'superMargin'
					}, {
						text: "",
						style: 'superMargin'
					}

				];
				var headerArray = [emptyRow, row1, emptyRow, row2, emptyRow, row3];
				return headerArray;

			};
			// map the bound data of the table to a pdfMake array
			var createTableData = function() {

				//this.oTable = this.getView().byId("lineItemsList");

				var mapArr = that.getView().byId("lineItemsList").getItems().map(function(obj) {

					var ret = [{
							text: obj.getCells()[0].getProperty("value")

						}, {
							text: obj.getCells()[1].getProperty("value")

						}, {
							text: obj.getCells()[2].getProperty("text")

						}, {
							text: obj.getCells()[3].getProperty("value")

						}, {
							text: obj.getCells()[4].getProperty("value")
						}, {
							text: obj.getCells()[5].getProperty("value"),
							//alignment: 'right'
						}, {
							text: obj.getCells()[6].getProperty("value")
						}

					];
					return ret;
				});
				// add a header to the pdf table
				mapArr.unshift(
					[

						{
							text: that.getResourceBundle().getText('LineColumn'),
							style: 'tableHeader'

						}, {
							text: that.getResourceBundle().getText('ItemColumn'),
							style: 'tableHeader'
						}, {
							text: that.getResourceBundle().getText('DescriptionColumn'),
							style: 'tableHeader'
						}, {
							text: that.getResourceBundle().getText('suppProdCodeColumn'),
							style: 'tableHeader'
						}, {
							text: that.getResourceBundle().getText('OrderedQtyColumn'),
							style: 'tableHeader'

						}, {
							text: that.getResourceBundle().getText('PickedQtyColumn'),
							style: 'tableHeader'
						}, {
							text: that.getResourceBundle().getText('UoMColumn'),
							style: 'tableHeader'
						}
					]
				);
				// add a summary row at the end
		
				return mapArr;
			};
			var docDefinition = {
				info: {
					title: "Items"
				},
				pageOrientation: 'landscape',
				footer: function(currentPage, pageCount) {
					return {
						text: currentPage.toString() + ' / ' + pageCount,
						alignment: 'center'
					};
				},
				content: [

					{
						text: view.byId("objectHeader").getTitle(),
						style: 'header'
					}, {
						table: {
							widths: [100, 150, 100, 150, 90, 40],
							body: createHeaderData()
						},
						layout: 'noBorders'
					}, {
						text: "",
						style: 'superMargin'
					},

					{
						text: "Delivery Note: " + view.byId("deliveryNote").getText(),
						style: 'superMargin'
					},

					{
						text: "",
						style: 'superMargin'
					},

					{
						text: "",
						style: 'superMargin'
					},

					{
						text: "Items",
						style: 'header'
					}, {
						table: {
							headerRows: 1,
							widths: [40, 60, 280, 90, 90, 80, 60],
							body: createTableData()
						}
						//layout: 'lightHorizontalLines'
					}
				],
				styles: {
					header: {
						fontSize: 18,
						bold: true,
						margin: [0, 0, 0, 10]
					},
					tableHeader: {
						bold: true,
						fontSize: 13,
						color: 'black'
					}
				}
			};
			//pdfMake.createPdf(docDefinition).open();
			sap.m.MessageToast.show("Picking list pdf will be downloaded", {
				duration: 6000
			});
			var fileName = view.byId("objectHeader").getTitle() + "_PickingList.pdf";
			pdfMake.createPdf(docDefinition).download(fileName);

		},

		setButtonStatus: function(oEvent) {

			var statusText = this.byId("Status").getText();

			var bText = this._bText[statusText];
			var aButton = this.byId("actionButtton");

			if (statusText === "Picking") {
				//Copy Open Quantity to Picked Quantity
				this.populatePicking();
				// Make the Picked quantity field editable
				this.setEModel(true);
			} else {
				this.setEModel(false);
			}
			if (statusText === "Invoiced") {
				
					if ("NZPostAPI" !== this.getView().getBindingContext().getProperty("OrderHeader/CarrierAPI")) {
						bText = "CreateLabelManually"
					}
				
			}
			aButton.setText(bText);

			// This would only be enable if createLabel fails
			this.getView().byId("actionButtton1").setVisible(false);
		},

		ActionButtonClick: function(oEvent) {
			var btnText = this.byId("actionButtton").getText();

			if (btnText === "Start Picking") {
				this.StartPickingClick(oEvent);

			}
			if (btnText === "Invoice") {
				this.InvoiceClick(oEvent);

				//	this.createLabel(oEvent);
			}
			if (btnText === "Create Label") {
				//this.createLabel(oEvent);
				this.showYesNoPopup(oEvent);

			}
			if (btnText === "CreateLabelManually") {

				//this.createLabelManually(oEvent);
				this.showYesNoPopup(oEvent);

			}

			if (btnText === "Dispatch" || btnText === "Complete") {
				this.completeClick(oEvent);
			}

		},
		showYesNoPopup: function(oEvent) {

			if (!this._ynDialog) {
				this._ynDialog = sap.ui.xmlfragment("masterdetail/view/YesNoDialog", this);
				this.getView().addDependent(this._ynDialog);

			}
			//this._lDialog.setModel(labelModel);

			this._ynDialog.open();

		},

		YesNoDialogOK: function(oEvent) {
			this._ynDialog.close();

			if ("Create Label" === this.byId("actionButtton").getText()) {

				this.createLabel(oEvent);
			} else {
				this.createLabelManually(oEvent);

			}

		},
		YesNoDialogCancel: function(oEvent) {
			this._ynDialog.close();

		},

		StartPickingClick: function(oEvent) {
			this.setStatus();

		},
		populatePicking: function(oEvent) {

			//var bindingContext = this.getView().getBindingContext();
			this.getView().byId("lineItemsList").getItems().some(function(oItem) {
				var openQuantity = oItem.getBindingContext().getProperty("OpenQty");
				var pathToPickedQuantity = oItem.getBindingContext().getPath() + "/SupplQty"
				oItem.getModel().setProperty(pathToPickedQuantity, openQuantity);
			});

		},

		setStatus: function() {

			var that = this;
			var bindingContext = this.getView().getBindingContext();

			var sData = {
				"DropShipStatus": {
					//	"Domain": bindingContext.getProperty("OrderHeader/Domain"),
					"Domain": "LNNZ",
					"SSID": "HCP",
					//	"SSID": bindingContext.getProperty("OrderHeader/SSID"),
					"DocNbr": bindingContext.getProperty("OrderHeader/DocNbr"),
					"Date": bindingContext.getProperty("OrderHeader/Date"),
					"Time": bindingContext.getProperty("OrderHeader/Time"),
					"SiteNbr": bindingContext.getProperty("OrderHeader/SiteNbr"),
					"InvNbr": bindingContext.getProperty("OrderHeader/InvNbr"),
					"DeliveryDate": bindingContext.getProperty("OrderHeader/DeliveryDate"),
					"CurrentStatus": bindingContext.getProperty("OrderHeader/Status"),
					"ConsignmentID": bindingContext.getProperty("OrderHeader/ConsignmentID"),
					"TrackingNumbers": bindingContext.getProperty("OrderHeader/TrackingNumbers")
				}
			};

			//	alert(sData);

			$.ajax({
				url: '/WebMethods/rest/directShipCommon.service.dropShipStatus',
				type: 'put',
				dataType: "xml",
				contentType: 'application/json; charset=utf-8',
				data: JSON.stringify(sData),
				success: function(response, status, xhr) {
					var xml = xhr.responseXML;
					if ($(xml).find("MessageStatus").text() === "OK") {
						that.byId("Status").setText($(xml).find("OrderStatus").text());
						//Make Picked Quantity Field Editable
						that.setButtonStatus();

					}
					if ($(xml).find("MessageStatus").text() === "FAIL") {
						that.openErrorDialog($(xml).find("Description").text());
					}

				},
				error: function(response, status, xhr) {
					that.openErrorDialog("Couldn't process request due to Error + " + response.statusText);
				},
				beforeSend: function() {

					that.getView().getModel("detailView").setProperty("/busy", true);
				},

				complete: function(response, status, xhr) {
					that.getView().getModel("detailView").setProperty("/busy", false);
				}

			});
		},

		setEModel: function(status) {

			var eModel = this.oTable.getModel("editModel")
			var eModelData = eModel.getData();
			eModelData.pqty = status;
			eModel.setData(eModelData);

		},

		_onUpdateCallback: function(message) {
			alert(message);
		},

		InvoiceClick: function(oEvent) {
			var that = this;
			var bindingContext = this.getView().getBindingContext();
			var lineItems = [];

			that.getView().byId("lineItemsList").getItems().some(function(oItem) {
				var item = {};
				var tBindingContext = oItem.getBindingContext();
				item["RecType"] = tBindingContext.getProperty("RecType");
				item["DocNbr"] = tBindingContext.getProperty("DocNbr");
				item["LineNbr"] = tBindingContext.getProperty("LineNbr");
				item["ProdCode"] = tBindingContext.getProperty("ProdCode");
				item["OpenQty"] = tBindingContext.getProperty("OpenQty");
				item["SupplQty"] = tBindingContext.getProperty("SupplQty");
				item["UOM"] = tBindingContext.getProperty("UOM");
				lineItems.push(item);
			});

			var sData = {
				"DropShipConfirm": {
					"ShipConfirmHeader": {
						"Domain": "LNNZ",
						"SSID": "HCP",
						//	"Domain": bindingContext.getProperty("OrderHeader/Domain"),
						//	"SSID": bindingContext.getProperty("OrderHeader/SSID"),
						"DocNbr": bindingContext.getProperty("OrderHeader/DocNbr"),
						"RecType": bindingContext.getProperty("OrderHeader/RecType"),
						"NoOfLines": bindingContext.getProperty("OrderHeader/NoOfLines"),
						"Date": bindingContext.getProperty("OrderHeader/Date"),
						"Time": bindingContext.getProperty("OrderHeader/Time"),
						"SiteNbr": bindingContext.getProperty("OrderHeader/SiteNbr"),
						"DeliveryDate": bindingContext.getProperty("OrderHeader/DeliveryDate")
					},
					"ShipConfirmLine": lineItems
				}

			};
			//var jsonSdata = JSON.stringify(sData);

			// Make an AJAX call

			$.ajax({
				url: '/WebMethods/rest/directShipCommon.service.dropShipConfirm',
				type: 'put',
				dataType: "xml",
				contentType: 'application/json; charset=utf-8',
				data: JSON.stringify(sData),
				success: function(response, status, xhr) {
					var xml = xhr.responseXML;
					if ($(xml).find("MessageStatus").text() === "OK") {
						that.byId("Status").setText($(xml).find("OrderStatus").text());
						that.byId("Invoice").setText($(xml).find("InvNbr").text());
						//Set Buutton status and Picked quantity field
						that.setButtonStatus();
						// Show Create Label Popup

						// Do not show create label popup automatically
						//	that.createLabel();

					}
					if ($(xml).find("MessageStatus").text() === "FAIL") {
						that.openErrorDialog($(xml).find("Description").text());
					}

				},
				error: function(response, status, xhr) {

					that.openErrorDialog("Couldn't process request due to Error + " + response.statusText);

				},
				beforeSend: function() {
					that.getView().getModel("detailView").setProperty("/busy", true);
				},
				complete: function(response, status, xhr) {
					that.getView().getModel("detailView").setProperty("/busy", false);
				}

			});

			//	console.Log(jsonSdata);

		},

		createLabel: function(oEvent) {

			// Open the Table Setting dialog
			//var tableModel = new JSONModel("model/data.json");
			var tableModel = new JSONModel({
				"CountLabels": "0"
			});

			if (!this._oDialog) {
				this._oDialog = sap.ui.xmlfragment("masterdetail/view/LabelPopup", this);
				this.getView().addDependent(this._oDialog);

			}
			this._oDialog.setModel(tableModel);

			this._oDialog.open();
			this.addRow(oEvent);

		},
		onCloseDialog: function() {
			var tableModel = this._oDialog.getModel();
			var count = parseInt(tableModel.getProperty("/CountLabels"));
			if (count > 0) {
				var parcel_details = [];
				tableModel.getProperty("/Labels").some(function(oLabel) {

					var parcel = {};
					var dimension = {};
					var dimensions = [];
					parcel["service_code"] = "CPOLP";
					parcel["return_indicator"] = "OUTBOUND";
					dimension["height_cm"] = parseFloat(oLabel.Height);
					dimension["width_cm"] = parseFloat(oLabel.Width);
					dimension["length_cm"] = parseFloat(oLabel.Length);
					dimension["weight_kg"] = parseFloat(oLabel.Weight);
					//dimensions.push(dimension);
					parcel["dimensions"] = dimension;
					parcel_details.push(parcel);

				});

				this._oDialog.close();
				//parcel_details;

				// Hope this will show busy indicator	
				//	 var oBusyDialog = new sap.m.BusyDialog();

				//	 oBusyDialog.open();
				this.callNZPostToCreatelabel(parcel_details);
				//	 oBusyDialog.close();
				/*	 jQuery.sap.delayedCall(3000, this, function () {
			
			
					 }) */

			} else {
				this._oDialog.close();
			}

		},
		onCancelDialog: function() {
			this._oDialog.close();
		},

		addRow: function(oEvent) {

			var tableModel = this._oDialog.getModel();
			var aLabels = [];
			var count = 0;

			count = parseInt(tableModel.getProperty("/CountLabels"));
			if (count !== 0) {
				aLabels = tableModel.getProperty("/Labels");
			}
			var bindingContext = this.getView().getBindingContext();
			var oNewLabel = {
				"Height": bindingContext.getProperty("OrderHeader/ParcelHeight"),
				"Width": bindingContext.getProperty("OrderHeader/ParcelWidth"),
				"Length": bindingContext.getProperty("OrderHeader/ParcelLength"),
				"Weight": bindingContext.getProperty("OrderHeader/ParcelWeight")
			};
			aLabels.push(oNewLabel);
			tableModel.setProperty("/Labels", aLabels);
			tableModel.setProperty("/CountLabels", count + 1);

		},

		deleteRow: function(oEvent) {
			var count = 0;
			var tableModel = this._oDialog.getModel();
			count = parseInt(tableModel.getProperty("/CountLabels"));
			var itemPath = oEvent.getParameter("listItem").getBindingContext().getPath();
			var lastSlash = itemPath.lastIndexOf("/");
			var itemIndex = parseInt(itemPath.substring(lastSlash + 1));
			var collectionPath = itemPath.substring(0, lastSlash);
			var tableModel = this._oDialog.getModel();
			var collection = tableModel.getObject(collectionPath);
			collection.splice(itemIndex, 1);
			tableModel.setProperty("/CountLabels", count - 1);
			tableModel.refresh();
		},

		callNZPostToCreatelabel: function(parcel_details) {

			var that = this;
			var token = ""; //this._getNZPostAuthcode();

			//var sURL = "https://api.uat.nzpost.co.nz/parcellabel/v3/labels";
			var sURL = "/WebMethods/rest/directShipCommon.service.parcelLabel";
			//var sURL = "/destinations/NZPostAPI/parcellabel/v3/labels";
			var bindingContext = this.getView().getBindingContext();
			var labelData = {

				"carrier": "COURIERPOST",
				"orientation": "LANDSCAPE",
				"format": "PDF",
				"sender_reference_1": bindingContext.getProperty("OrderHeader/DocNbr"),
				"sender_details": {
					"name": bindingContext.getProperty("OrderHeader/SiteName"),
					//	"phone": "6490000001",
					//	"email": "glenn.dodd@nzpost.co.nz",
					//	"company_name": "Test Sender Company",
					//	"site_code": bindingContext.getProperty("OrderHeader/SiteNbr")
					//"site_code": 52552
					"site_code": parseInt(bindingContext.getProperty("OrderHeader/SiteCode"))
				},
				"pickup_address": {

					"company_name": bindingContext.getProperty("OrderHeader/SiteName"),
					//"street_number": bindingContext.getProperty("OrderHeader/SiteAddress/AddrLine1"),
					/*
					"street_number": "Test",
					"street": "Test",
					"suburb": "East Tamaki",
					"city": "Waiuku",
					"postcode": "2684",
					*/
					"street": bindingContext.getProperty("OrderHeader/SiteAddress/AddrLine1"),
					"suburb": bindingContext.getProperty("OrderHeader/SiteAddress/AddrLine3"),
					"city": bindingContext.getProperty("OrderHeader/SiteAddress/City"),
					"postcode": bindingContext.getProperty("OrderHeader/SiteAddress/PostCode"),
					
					"instructions": "NONE",
					"country_code": "NZ"
				},
				"receiver_details": {
					"name": bindingContext.getProperty("OrderHeader/ShipToName")

				},
				"delivery_address": {
					"company_name": bindingContext.getProperty("OrderHeader/ShipToName"),
					/*
					"street_number": "Test",
					"street": "Test",
					"suburb": "East Tamaki",
					"city": "Waiuku",
					"postcode": "2684",
					*/
					//"street_number": bindingContext.getProperty("OrderHeader/ShipToAddress/AddrLine1"),
					
					"street": bindingContext.getProperty("OrderHeader/ShipToAddress/AddrLine1"),
					"suburb": bindingContext.getProperty("OrderHeader/ShipToAddress/AddrLine3"),
					"city": bindingContext.getProperty("OrderHeader/ShipToAddress/City"),
					"postcode": bindingContext.getProperty("OrderHeader/ShipToAddress/PostCode"),
					
					"instructions": bindingContext.getProperty("OrderHeader/DeliveryInstructions"),
					"country_code": "NZ"
				},
				"parcel_details": parcel_details

			};
			var labelID;
			$.ajax({
				type: "POST",
				url: sURL,
				//async: false,
				global: false,
				dataType: "json",
				contentType: 'application/json',
				data: JSON.stringify(labelData),

				headers: {
					'Authorization': 'Bearer ' + token,
					'client_id': '27c0ba357b544efa9d2e98b0e6497e5a'
				},
				success: function(response, status, xhr) {

					if (response.success) {
						//that.byId("label").setText($.parseJSON(xhr.responseText).consignment_id);  THis should only be set if label status is success
						sap.m.MessageToast.show("Label request sent to NZ Post");
						that.checkLabelStatus(token, $.parseJSON(xhr.responseText).consignment_id);
					} else {
						if (response.errors[0].details !== null)
							that.openErrorDialog(response.errors[0].details);
						that.getView().getModel("detailView").setProperty("/busy", false);
						// Enasbling msnual label creation option
						that.getView().byId("actionButtton1").setVisible(true);

					}

				},
				error: function(response, status, xhr) {
					that.openErrorDialog("Couldn't process request");
				},

				beforeSend: function() {
					that.getView().getModel("detailView").setProperty("/busy", true);
				},

				complete: function(response, status, xhr) {
					//that.getView().getModel("detailView").setProperty("/busy", false);
				}

			});

			//	return labelID;

		},

		_getNZPostAuthcode: function() {
			var token;
			//url: "https://oauth.nzpost.co.nz/as/token.oauth2?client_id=27c0ba357b544efa9d2e98b0e6497e5a&client_secret=d015E2483F9745a88de7Ed6670517528&grant_type=client_credentials&response_type=token",
			var request = $.ajax({

					type: "POST",
					url: "/NZPostToken/as/token.oauth2?client_id=27c0ba357b544efa9d2e98b0e6497e5a&client_secret=d015E2483F9745a88de7Ed6670517528&grant_type=client_credentials&response_type=token",
					async: false,
					crossDomain: true,
					dataType: "json",
					contentType: 'text/plain',
					data: {
						client_id: '27c0ba357b544efa9d2e98b0e6497e5a',
						client_secret: 'd015E2483F9745a88de7Ed6670517528',

						response_type: "token"
					}
				})
				.success(function(data) {
					//alert("I got token");
					//return data.access_token;

					token = data.access_token;
				})
				.done(function(results) {
					console.log(results);

					// return results.access_token;

				})
				.fail(function(err) {
					//oView.setBusy(false);

					alert(" Error in getting  authorisation codee" + err.statusText);
					if (err !== undefined) {
						var oErrorResponse = $.parseJSON(err.responseText);

						sap.m.MessageToast.show(oErrorResponse.message, {
							duration: 6000
						});
					} else {
						//alert("unknown error");
						sap.m.MessageToast.show("Unknown error!");
					}
				});

			return token;

		},

		_downloadLabel: function(token, LabelID) {

			var xhr = new XMLHttpRequest();
			//	var sURL = "https://api.uat.nzpost.co.nz/ParcelLabel/v3/labels/" + LabelID + "?format=PDF";
			var sURL = "/WebMethods/rest/directShipCommon.service.parcelLabel?label=" + LabelID;
			//	var sURL = "/NZPostAPI/ParcelLabel/v3/labels/" + LabelID + "?format=PDF";
			xhr.open('GET', sURL, true);
			xhr.responseType = 'arraybuffer';
			xhr.onload = function(e) {
				if (this.status == 200) {
					var blob = new Blob([this.response], {
						type: "application/pdf"
					});
					var link = document.createElement('a');
					link.href = window.URL.createObjectURL(blob);
					link.download = "Label_" + LabelID + ".pdf";
					link.click();
				}
			};
			xhr.setRequestHeader('Authorization', 'Bearer ' + token);
			xhr.setRequestHeader('client_id', '27c0ba357b544efa9d2e98b0e6497e5a');
			xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
			xhr.send();

		},

		_parcelTrack: function(token, trackingID) {
			//	alert(" I am here");
			//	var sURL = "/NZPostAPI/parceltrack/3.0/parcels/" + trackingID + "?access_token=" + token;
			//var sURL = "https://api.uat.nzpost.co.nz/parceltrack/3.0/parcels/" + trackingID + "?access_token=" + token;
			var sURL = "/WebMethods/rest/directShipCommon.service.parcelTrack/?trackingID=" + trackingID;
			//var sURL = "https://api.nzpost.co.nz/parceltrack/3.0/parcels/" + trackingID + "?access_token=" + token;
			var ticketStatus = "";
			var that = this;
			
			$.ajax({

				url: sURL,
				async: false,
				dataType: "json",
				contentType: 'text/plain',

				headers: {
					'client_id': '27c0ba357b544efa9d2e98b0e6497e5a',
					'Accept': 'application/json',
					'Content-Type': 'application/x-www-form-urlencoded'
				},
				success: function(response, status, xhr) {
					var data = $.parseJSON(xhr.responseText);
					if (data.success) {
						ticketStatus = data.results.tracking_events[0];
					} else {
						ticketStatus = data.errors[0].details;
					}

				},
				error: function(response, status, xhr) {
					ticketStatus = "Error connecting NZ Post API";
				},
				beforeSend: function() {
					//that.getView().getModel("detailView").setProperty("/busy", true);
				},

				complete: function(response, status, xhr) {
					//that.getView().getModel("detailView").setProperty("/busy", false);
				}

			});

			return ticketStatus;
		},

		checkLabelStatus: function(token, consignment_id) {
			var that = this;
			var labelStatus;
			var delayMillis = 10000; //10 second
		
			labelStatus = that.getLabelStatus(token, consignment_id);

			// Show Busy indicator

			if (labelStatus === 'Processing' || labelStatus === 'Accepted' || labelStatus === '') {
				//setTimeout(this.getLabelStatus(token, labelID), 500);

				if (labelStatus !== 'Failed') {

					setTimeout(function() {
						
						sap.m.MessageToast.show("Getting Label Status");
						labelStatus = that.getLabelStatus(token, consignment_id);

						if (labelStatus === 'Processing' || labelStatus === 'Accepted' || labelStatus === '') {

							setTimeout(function() {
								

								labelStatus = that.getLabelStatus(token, consignment_id);
								
								// fail after 3 attempts
								if (labelStatus === 'Processing' || labelStatus === 'Accepted' || labelStatus === '') {
									that.openErrorDialog("Error in creating label , please try again later or create label manually");
									// give additional option of creating label manually
									that.getView().getModel("detailView").setProperty("/busy", false);
									that.getView().byId("actionButtton1").setVisible(true);
								}
							}, delayMillis);

						}

					}, delayMillis);
				}
			} else {
				that.getView().getModel("detailView").setProperty("/busy", false);
			
			 
			}

		},

		getLabelStatus: function(token, LabelID) {
			//	var sURL = "https://api.uat.nzpost.co.nz/ParcelLabel/v3/labels/" + LabelID + "/status";
			var sURL = "/WebMethods/rest/directShipCommon.service.parcelLabelStatus?label=" + LabelID;
			var labelStatus = "";
			var that = this;
			$.ajax({
				url: sURL,
				async: false,
				global: false,

				headers: {
					'Authorization': 'Bearer ' + token,
					'client_id': '27c0ba357b544efa9d2e98b0e6497e5a',
					'Content-Type': 'application/x-www-form-urlencoded'
				},
				success: function(response, status, xhr) {

					var data = $.parseJSON(xhr.responseText);
					labelStatus = data.consignment_status;

					if (labelStatus === "Complete") {
						var i;
						var tracking_ids = "";

						for (i = 0; i < data.labels.length; i++) {
							tracking_ids = tracking_ids + "," + data.labels[i].tracking_reference;
						}
						tracking_ids = tracking_ids.substring(1)

						that.byId("label").setText(LabelID);
						that.byId("trackingNumber").setText(tracking_ids);
						sap.m.MessageToast.show("Setting backend status");
						that.setStatus(); // Set the backend status
					}
					if (labelStatus === "Failed") {
						var errors = data.errors[0].details + '-' + data.errors[0].message;
						that.openErrorDialog(errors);
						that.getView().byId("actionButtton1").setVisible(true);

					}

				},

				error: function(response, status, xhr) {
					that.openErrorDialog("Couldn't process request");

				},

				beforeSend: function() {
					that.getView().getModel("detailView").setProperty("/busy", true);
				}

			});

			return labelStatus;
		},

	
		completeClick: function(oEvent) {

			this.setStatus();

		},

		handleMessagePopoverPress2: function(oEvent) {

			oMessagePopover2.openBy(oEvent.getSource());
		},

		resetViewMapping: function(oEvent) {

			this.setButtonStatus();
			var eModel = this.oTable.getModel("editModel")
			var eModelData = eModel.getData();
			eModelData.pqty = false;
			eModel.setData(eModelData);
			var status = this.byId("Status");
			//	status.setText("New");

			//oStatusObject.LifecycleStatusDescription = "In Progress";

		},
		createLabelManually: function() {

			var labelModel = new JSONModel({
				"label": ""
			});

			if (!this._lDialog) {
				this._lDialog = sap.ui.xmlfragment("masterdetail/view/ManualLabelPopup", this);
				this.getView().addDependent(this._lDialog);

			}
			this._lDialog.setModel(labelModel);

			this._lDialog.open();

		},
		LabelDialogOK: function(oEvent) {
			var labelModel = this._lDialog.getModel();

			this.byId("trackingNumber").setText(labelModel.getProperty("/tracking"));

			this.byId("label").setText("Manual");
			this._lDialog.close();
			this.setStatus();

		},
		LabelDialogCancel: function(oEvent) {
			this._lDialog.close();
		},

		trackingClicked: function(evt) {

			//	this.getView().getModel("detailView").setProperty("/busy", true);
			var trackingNumbers = this.byId("trackingNumber").getText();
			var tracking_array = trackingNumbers.split(",");

			var tracking_details = {};
			var trackingCollection = [];
			var token = ""; //this._getNZPostAuthcode();
			sap.m.MessageToast.show("Retrieving Tracking Status", {
			duration: 5000} );      // default
			// Set Busy Flag while we retrieve the Tracking status
			this.getView().getModel("detailView").setProperty("/busy", true);
			
			for (var i = 0; i < tracking_array.length; i++) {
				var trackingNumber = tracking_array[i];
				var status = this._parcelTrack(token, trackingNumber);
				var tracking = {};

				tracking["TrackingNumber"] = trackingNumber;
				tracking["TrackingStatus"] = status;
				trackingCollection.push(tracking);
				//tracking_details.push(trackingCollection);

				//alert(trackingNumber);
			}
			tracking_details["TrackingCollection"] = trackingCollection;

			// Open the Table Setting dialog
			if (!this._oTDialog) {
				this._oTDialog = sap.ui.xmlfragment("masterdetail/view/TrackingPopup", this);
				this.getView().addDependent(this._oTDialog);

			}

			var TrackingModel = new sap.ui.model.json.JSONModel();
			TrackingModel.setData(tracking_details);
			//this.oTable = this.getView().byId("lineItemsList");
			this._oTDialog.setModel(TrackingModel);
			//this.getView().byId("TrackingTable").setModel(TrackingModel);

			this.getView().getModel("detailView").setProperty("/busy", false);
			this._oTDialog.open();
		},

		onCloseTrackingDialog: function(evt) {

			this._oTDialog.close();

		},

		handleUrlPress: function(evt) {
			console.log("redirecting to:");
			//	sap.m.URLHelper.redirect("https://www.nzpost.co.nz/tools/tracking", true);

			var authcode = this._getNZPostAuthcode();
			var trackingID = "8441112754000801AKL048HS";
			var status = this._parcelTrack(authcode, trackingID);
			//alert(status.event_description);

			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			sap.m.MessageBox.information(
				"Parcel Delivered!!.", {
					styleClass: bCompact ? "sapUiSizeCompact" : ""
				}
			);
		},

		labelClick: function(evt) {
			console.log("redirecting to:");
			//	sap.m.URLHelper.redirect("https://www.nzpost.co.nz/tools/tracking", true);
			var bindingContext = this.getView().getBindingContext();

			//var LabelID = "LL4H5A"; // assign screen field consignment ID here
			var LabelID = bindingContext.getProperty("OrderHeader/ConsignmentID");

			var authcode = ""; // this._getNZPostAuthcode();

			if (LabelID !== 'Manual') {
				this._downloadLabel(authcode, LabelID);

				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;

				sap.m.MessageToast.show("Label in PDF will be downloaded!!.", {
					duration: 6000
				});
			} else {
				/*	sap.m.MessageBox.information(
						"Label was created manually, can not be downloaded.", {
							styleClass: bCompact ? "sapUiSizeCompact" : ""
						}
					);*/

				sap.m.MessageToast.show("Label was created manually, can not be downloaded..", {
					duration: 6000
				});
			}
		},

		handleUrlPress2: function(evt) {
			console.log("redirecting to:");
			//	sap.m.URLHelper.redirect("https://www.nzpost.co.nz/tools/tracking", true);

			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			sap.m.MessageBox.information(
				"Will be redirected to Invoice Page of ACE !!.", {
					styleClass: bCompact ? "sapUiSizeCompact" : ""
				}
			);
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Event handler when the share by E-Mail button has been clicked
		 * @public
		 */
		onShareEmailPress: function() {
			var oViewModel = this.getModel("detailView");

			sap.m.URLHelper.triggerEmail(
				null,
				oViewModel.getProperty("/shareSendEmailSubject"),
				oViewModel.getProperty("/shareSendEmailMessage")
			);
		},

		/**
		 * Updates the item count within the line item table's header
		 * @param {object} oEvent an event containing the total number of items in the list
		 * @private
		 */
		onListUpdateFinished: function(oEvent) {
			var sTitle,
				iTotalItems = oEvent.getParameter("total"),
				oViewModel = this.getModel("detailView");

			// only update the counter if the length is final
			if (this.byId("lineItemsList").getBinding("items").isLengthFinal()) {
				if (iTotalItems) {
					sTitle = this.getResourceBundle().getText("detailLineItemTableHeadingCount", [iTotalItems]);
				} else {
					//Display 'Line Items' instead of 'Line items (0)'
					sTitle = this.getResourceBundle().getText("detailLineItemTableHeading");
				}
				oViewModel.setProperty("/lineItemListTitle", sTitle);
			}
		},

		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */

		/**
		 * Binds the view to the object path and expands the aggregated line items.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched: function(oEvent) {
			var sObjectId = oEvent.getParameter("arguments").objectId;
			//this.getModel().metadataLoaded().then(function() {
			//	var sObjectPath = this.getModel().createKey("SalesOrderSet", {
			//		SalesOrderID: sObjectId
			//	});
			var sObjectPath = "DropShipOrder/" + sObjectId
			this._bindView("/" + sObjectPath);
			//	}.bind(this));
			this.getModel.bind(this);
			//	this.resetViewMapping(oEvent);
		},

		/**
		 * Binds the view to the object path. Makes sure that detail view displays
		 * a busy indicator while data for the corresponding element binding is loaded.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound to the view.
		 * @private
		 */
		_bindView: function(sObjectPath) {
			// Set busy indicator during view binding
			var oViewModel = this.getModel("detailView");

			// If the view was not bound yet its not busy, only if the binding requests data it is set to busy again
			oViewModel.setProperty("/busy", false);

			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function() {
						oViewModel.setProperty("/busy", true);
					},
					dataReceived: function() {
						oViewModel.setProperty("/busy", false);
					}
				}
			});
		},

		_onBindingChange: function() {
			var oView = this.getView(),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("detailObjectNotFound");
				// if object could not be found, the selection in the master list
				// does not make sense anymore.
				this.getOwnerComponent().oListSelector.clearMasterListSelection();
				return;
			}

			var sPath = oElementBinding.getPath(),
				oResourceBundle = this.getResourceBundle(),
				oObject = oView.getModel().getObject(sPath),
				sObjectId = oObject.SalesOrderID,
				sObjectName = oObject.SalesOrderID,
				oViewModel = this.getModel("detailView");

			this.getOwnerComponent().oListSelector.selectAListItem(sPath);
			/* Added by Prashant */

			var oList = this.getOwnerComponent().oListSelector._oList;
			var oBinding = oList.getBinding("items");
			var globalFilter = this.getOwnerComponent().globalFilter
			if (globalFilter) {

				oBinding.filter(globalFilter);
			}
			oList.getItems().some(function(oItem) {
				if (oItem.getBindingContext() && oItem.getBindingContext().getPath() === sPath) {
					oList.setSelectedItem(oItem);

				}
			});
			/* End */

			// Set Action Button Text, Based on Status
			this.setButtonStatus();

			oViewModel.setProperty("/shareSendEmailSubject",
				oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
			oViewModel.setProperty("/shareSendEmailMessage",
				oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
		},

		_onMetadataLoaded: function() {
			// Store original busy indicator delay for the detail view
			var iOriginalViewBusyDelay = this.getView().getBusyIndicatorDelay(),
				oViewModel = this.getModel("detailView"),
				oLineItemTable = this.byId("lineItemsList"),
				iOriginalLineItemTableBusyDelay = oLineItemTable.getBusyIndicatorDelay();

			// Make sure busy indicator is displayed immediately when
			// detail view is displayed for the first time
			oViewModel.setProperty("/delay", 0);
			oViewModel.setProperty("/lineItemTableDelay", 0);

			oLineItemTable.attachEventOnce("updateFinished", function() {
				// Restore original busy indicator delay for line item table
				oViewModel.setProperty("/lineItemTableDelay", iOriginalLineItemTableBusyDelay);
			});

			// Binding the view will set it to not busy - so the view is always busy if it is not bound
			oViewModel.setProperty("/busy", true);
			// Restore original busy indicator delay for the detail view
			oViewModel.setProperty("/delay", iOriginalViewBusyDelay);
		},

		validatePickedQuanity: function(oEvent) {

			var oInput = this.byId(oEvent.getParameter("id"));

			//	var orderQuantity = oEvent.getSource().getBindingContext().getObject().Quantity;
			var orderQuantity = oEvent.getSource().getBindingContext().getProperty("OpenQty");
			//	var pickedQuantity = oEvent.getParameter("value");
			var pickedQuantity = oEvent.getSource().getBindingContext().getProperty("SupplQty");

			//var oldPickedQuantity = oEvent.getSource().getBindingContext().getObject().Quantity; // This will change when the binding of picked Quantity changes
			if (pickedQuantity > orderQuantity) {

				oInput.setValueState(sap.ui.core.ValueState.Error);
				oInput.setValueStateText("Picked Quantity cannot be greater than Ordered Quantity");
				oInput.focus();
				//	oInput.setValue(oldPickedQuantity);
			} else {
				oInput.setValueState(sap.ui.core.ValueState.None);
				oInput.setValueStateText("");
			}

			var errorFlag = false;

			this.getView().byId("lineItemsList").getItems().some(function(oItem) {

				// Index of Picked Quantity is 5. Check if it's in error.	
				if (oItem.getCells()[5].getValueState() === "Error") {
					errorFlag = true;
				}

			});
			if (errorFlag) {
				this.byId("actionButtton").setEnabled(false);
				this.byId("actionButtton").setTooltip("Disabled due to error in form");
			} else {
				this.byId("actionButtton").setEnabled(true);
				this.byId("actionButtton").setTooltip("");
			}

		}

	});

});