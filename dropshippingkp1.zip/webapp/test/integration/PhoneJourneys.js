jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"masterdetail/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"masterdetail/test/integration/pages/App",
	"masterdetail/test/integration/pages/Browser",
	"masterdetail/test/integration/pages/Master",
	"masterdetail/test/integration/pages/Detail",
	"masterdetail/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "masterdetail.view."
	});

	sap.ui.require([
		"masterdetail/test/integration/NavigationJourneyPhone",
		"masterdetail/test/integration/NotFoundJourneyPhone",
		"masterdetail/test/integration/BusyJourneyPhone"
	], function () {
		QUnit.start();
	});
});