sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("crisismanagement.controller.main", {
		/*
		  initial function for view
		*/
		onInit: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			this.getOwnerComponent().getGroups("2018ac7d-cbba-4632-b26b-dc2c6e55c4cb");

		},
		
		onPress: function(ev) { 
			//alert(ev.getSource().getTitle());
			this.getOwnerComponent().group = ev.getSource().getTitle();
			this.getOwnerComponent().getRouter().navTo("actions", {
					id: ev.getSource().getTitle()
				}, false); 
			
		}
		
	});
});