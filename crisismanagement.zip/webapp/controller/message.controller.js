sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("crisismanagement.controller.message", {
		/*
		  initial function for view
		*/
		onInit: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var oRouter = this.getOwnerComponent().getRouter();

			oRouter.attachRouteMatched(function(oEvent) {
				if (oEvent.getParameter("name") !== "message") {
					return;
				}
				this._selectItemWithId(oEvent.getParameter("arguments"));
			}, this);

		},

		_selectItemWithId: function(arg) {
			var subject = this.byId("templates").getValue();
			var body = this.byId("templates").getSelectedKey();			
			subject = this.getOwnerComponent().substituteVariables(subject);
			body = this.getOwnerComponent().substituteVariables(body);				


			this.byId("d_email_subject").setValue(subject);
			this.byId("d_email_body").setValue(body);
			this.byId("page").setTitle(this.getOwnerComponent().group);
		},

		onTemplateChange: function(ev) {
			var subject = this.byId("templates").getValue();
			var body = this.byId("templates").getSelectedKey();			
			subject = this.getOwnerComponent().substituteVariables(subject);
			body = this.getOwnerComponent().substituteVariables(body);				

	
			this.byId("d_email_subject").setValue(subject);
			this.byId("d_email_body").setValue(body);
		},

		onReset: function(ev) {
			this.byId("d_email_subject").setValue();
			this.byId("d_email_body").setValue();
		},
		/*
		  submit email/sms
		*/
		onSubmit: function(ev) {
			// sendMessage: function(from, to, cc, subject, body) {	
			var to;
			var cc;
			var sms = this.byId("sms").getPressed();
			var email = this.byId("email").getPressed();
			
			if (!sms && !email){
				sap.m.MessageToast.show("Please select SMS and/or Email");
				return;
			}

			jQuery.sap.delayedCall(50, this, function() {
//				if (sms) {
//					cc = "+61417261536@smsau.lionco.com,+61434100850@smsau.lionco.com,+61449584599@smsau.lionco.com";
//				}
//				if (email) {
//					to = "john.peter@lionco.com,shane.rose@lionco.com,gary.dejesus@lionco.com";
//				}
				this.getOwnerComponent().sendMessage("crisis_Management@lionco.com",
					email,
					sms,
					this.byId("d_email_subject").getValue(),
					this.byId("d_email_body").getValue());

				sap.m.MessageToast.show("Message Sent");
				sap.ui.core.BusyIndicator.hide();
			});
			sap.ui.core.BusyIndicator.show(10);

		},

		onAfterRendering: function() {
			
			var subject = this.byId("templates").getValue();
			var body = this.byId("templates").getSelectedKey();			
			subject = this.getOwnerComponent().substituteVariables(subject);
			body = this.getOwnerComponent().substituteVariables(body);				


			this.byId("d_email_subject").setValue(subject);
			this.byId("d_email_body").setValue(body);
			
		},

		onBack: function(ev) {
			this.getOwnerComponent().getRouter().navTo("actions", {
				id: this.getOwnerComponent().group
			}, false);
		}

	});
});