sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("crisismanagement.controller.actions", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf crisismanagement.view.View2
		 */
		onInit: function() {
			var oRouter = this.getOwnerComponent().getRouter();
			this.message = "";
			this.title = "";

			oRouter.attachRouteMatched(function(oEvent) {
				if (oEvent.getParameter("name") !== "actions") {
					return;
				}
				this._selectItemWithId(oEvent.getParameter("arguments"));
			}, this);
		},

		_selectItemWithId: function(arg) {
			var model = this.getOwnerComponent().getModel("templates");
			var _true = true;
			var i = 0;

			while (_true) {
				try {
					this.title = model.getProperty("/entry/" + i + "/content/m:properties/d:Title");
					this.message = model.getProperty("/entry/" + i + "/content/m:properties/d:Template_x0020_text");

					if (this.title.indexOf("Crisis Managment Team Activated") !== -1) {
						break;
					}
				} catch (exception) {
					break;
				}
				i++;
			}

			this.byId("page").setTitle(arg.id);
		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf crisismanagement.view.View2
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf crisismanagement.view.View2
		 */
		//	onAfterRendering: function() {
		//
		//	},

		onBack: function(ev) {
			this.getOwnerComponent().getRouter().navTo("main", {}, false);
		},

		onContactList: function(ev) {
			this.getOwnerComponent().getRouter().navTo("contacts", {
				id: this.getOwnerComponent().group
			}, false);
		},

		onFirstResponse: function(ev) {
			this.getOwnerComponent().getRouter().navTo("firstresponse", {}, false);
		},

		onMessage: function(ev) {
			this.getOwnerComponent().getRouter().navTo("message", {}, false);
		},

		onActivateFinished: function(ev) {

			var oFilterName = new sap.ui.model.Filter("content/m:properties/d:Title",
				sap.ui.model.FilterOperator.Contains, "Crisis Managment Team Activated");
			var oFilter = new sap.ui.model.Filter({
				filters: [oFilterName],
				and: false
			});
			var oBinding = this.byId("activatetemplate").getBinding("items");
			oBinding.filter([oFilter]);
		},

		onActivate: function(ev) {
			jQuery.sap.require("sap.m.MessageBox");			
			
			var that = this;
			sap.m.MessageBox.confirm(
				"Confirm Activate Crisis?", {
					onClose: function(oAction) {
						//	alert(oAction);
						if (oAction !== "CANCEL") {
							jQuery.sap.delayedCall(50, this, function() {
								var cc;
								var to;
								that.getOwnerComponent().sendMessage("crisis_Management@lionco.com",
									true,
									true,
									that.title,
									that.message);

								sap.m.MessageToast.show("Crisis Activated");
								sap.ui.core.BusyIndicator.hide();
							});
							sap.ui.core.BusyIndicator.show(10);
						}
					}
				}
			);

		}

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf crisismanagement.view.View2
		 */
		//	onExit: function() {
		//
		//	}

	});

});