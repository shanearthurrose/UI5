sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("crisismanagement.controller.firstResponse", {
		/*
		  initial function for view
		*/
		onInit: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");

		},
		
		onBack: function(ev) {
			this.getOwnerComponent().getRouter().navTo("actions", {
					id: this.getOwnerComponent().group
				}, false); 
		}

	});
});