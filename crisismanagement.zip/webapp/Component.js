sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"crisismanagement/model/models"
], function(UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("crisismanagement.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			this.group = "";

			//this.getContacts("a654c383-b578-41cb-a935-f9c3d0bcf394");  //contacts GUID

			this.callIntelex("contacts", "a654c383-b578-41cb-a935-f9c3d0bcf394"); //get Contacts
			this.callIntelex("templates", "df5e4161-9423-49a4-947e-75954be648c0", false); //templates list
			this.callIntelex("firstresponse", "a6980aaa-6689-4508-b97a-a9a41e782df2", false); //first responselist			
			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			this.userid = localStorage.userid;

			this.getRouter().initialize();

			if (!this.userid) {
				if (!this.logon) {
					this.logon = sap.ui.xmlfragment("crisismanagement.view.login", this); //	this.oContactDialog.setModel(this.getOwnerComponent().getModel("sellins"), "sellins");
				}
				this.logon.open();
			} else {
				this.getRouter().navTo("main", {}, false);
			}

		},

		onLogin: function(ev) {

			this.userid = sap.ui.getCore().byId("username").getValue().toUpperCase();
			this.password = sap.ui.getCore().byId("password").getValue();

			//	alert($('.password input').val());

			if (this.userid === "") {
				sap.ui.getCore().byId("username").setValueState(sap.ui.core.ValueState.Error);
				sap.m.MessageToast.show("Please Enter all Mandatory Fields(Userame)");
			} else if (this.password === "") {
				sap.ui.getCore().byId("password").setValueState(sap.ui.core.ValueState.Error);
				sap.m.MessageToast.show("Please Enter all Mandatory Fields(passord)");
			} else {
				var valid = this._checkLogin(this.userid, this.password);
				if (valid === "true") {
					localStorage.userid = this.userid;
					//localStorage.password = this.password;
					this.logon.close();
				} else {
					sap.m.MessageToast.show("Invalid Credentials");
				}
				//sap.ui.core.BusyIndicator.show(10);
			}

		},

		_checkLogin: function(user, password) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			var sServiceUrl = "/destinations/WebMethods";
			//var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
			//	"Content-Type": "application/xml; charset=utf-8"
			//});
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, user, password, {}, false, true);
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var query = "/rest/ldapCommon.service.ldapAuth?userId=" + user + "&password=" + password;

			var oXML = new sap.ui.model.xml.XMLModel();

			var valid = false;

			oModel.read(query, null, null, false,
				function(oData, oResponse) {
					oDataJSONModel.setData(oResponse);
					var obody = oDataJSONModel.getProperty("/body");
					//sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));

					var oXMLModel = new sap.ui.model.xml.XMLModel();
					oXMLModel.setXML(obody);

					valid = oXMLModel.getProperty("/status");
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oXMLModel.getProperty("/status"), null, 4));

				},
				function(oError) {

				});

			return valid;
		},

		getGroups: function(guid) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var query = "/rest/commonIntelex.restIntelex.formsDataDefinition?guid=" + guid;

			var oXML = new sap.ui.model.xml.XMLModel();
			this.setModel(oXML, "groups");

			sap.ui.core.BusyIndicator.show(10);

			oModel.read(query, null, null, true, function(oData, oResponse) {
				oDataJSONModel.setData(oResponse);
				var obody = oDataJSONModel.getProperty("/body");
				//	sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));
				//
				//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
				//
				var oXMLModel = new sap.ui.model.xml.XMLModel();
				oXMLModel.setXML(obody);
				that.setModel(oXMLModel, "groups");

				sap.ui.core.BusyIndicator.hide();

			}, function(oError) {
				sap.ui.core.BusyIndicator.hide();
				//		sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
			});

		},

		callIntelex: function(model, guid, debug) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var query = "/rest/commonIntelex.restIntelex.formsDataDefinition?guid=" + guid;

			var oXML = new sap.ui.model.xml.XMLModel();
			this.setModel(oXML, model);

			//sap.ui.core.BusyIndicator.show(10);

			oModel.read(query, null, null, true, function(oData, oResponse) {
				oDataJSONModel.setData(oResponse);
				var obody = oDataJSONModel.getProperty("/body");
				if (debug) {
					sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));
				}
				//
				//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
				//
				var oXMLModel = new sap.ui.model.xml.XMLModel();
				oXMLModel.setXML(obody);
				that.setModel(oXMLModel, model);

				//sap.ui.core.BusyIndicator.hide();

			}, function(oError) {
				//sap.ui.core.BusyIndicator.hide();
				//		sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
			});

		},

		getList: function(type) {
			// use: this.group
			var contacts = this.getModel("contacts");
			var _true = true;
			var i = 0;
			var to = "";
			var cc = "";

			while (_true) {
				try {
					if (contacts.getProperty("/entry/" + i + "/content/m:properties/d:CMT") === this.group) {
						var email = contacts.getProperty("/entry/" + i + "/content/m:properties/d:Email");
						var mobile = contacts.getProperty("/entry/" + i + "/content/m:properties/d:Mobile");
						if (mobile !== "") {
							mobile = mobile.split(" ").join("") + "@smsau.lionco.com";
							if (cc === "") {
								cc = mobile;
							} else {
								cc = cc + ',' + mobile;
							}
						}
						if (to === "") {
							to = email;
						} else {
							to = to + ',' + email;
						}

					}

				} catch (Exception) {
					break;
				}
				i++;

			}

			if (type === "email") {
				return to;
			} else {
				return cc;
			}

		},

		substituteVariables: function(text) {

			text = text.split("<CMT>").join(this.group);
			text = text.split("<cmt>").join(this.group);
			text = text.split("<User>").join(this.userid);
			text = text.split("<USER>").join(this.userid);
			text = text.split("<user>").join(this.userid);

			return text;
		},

		sendMessage: function(from, email, sms, subject, body) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var query = "/rest/ldapCommon.service.emailSvc";

			var data = {};

			// Create update payload
			if (email) {
				data.emailTo = this.getList("email");
			}

			if (sms) {
				data.emailCC = this.getList("sms");
			}

			data.emailFrom = from;

			subject = this.substituteVariables(subject);

			data.emailSubject = subject;

			body = this.substituteVariables(body);
			data.emailBody = body;

			oModel.create(query, data, null,
				function(oData, response) {

					//	oDataJSONModel.setData(response);
					//					var obody = oDataJSONModel.getProperty("/body");
					//					var oXML = new sap.ui.model.xml.XMLModel();
					//					oXML.setXML(obody);
				},
				function(oError) {
					//alert("error" + oError);
				});

		}

	});
});