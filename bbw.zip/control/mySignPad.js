/*jQuery.sap.registerModulePath("SignaturePad", "./control/SignaturePad");*/
sap.ui.define(["sap/ui/core/Control"], function(oControl) {
    "use strict";
    return oControl.extend("bbw.control.mySignPad", {
 
        metadata: {
            properties: {
                "width": {
                    type: "sap.ui.core.CSSSize",
                    defaultValue: "250px"
                },
                "height": {
                    type: "sap.ui.core.CSSSize",
                    defaultValue: "100px"
                },
                "thickness": {
                    type: "int",
                    defaultValue: 2
                },
                "bgcolor": {
                    type: "sap.ui.core.CSSColor",
                    defaultValue: "white"
                },
                "signcolor": {
                    type: "sap.ui.core.CSSColor",
                    defaultValue: "black"
                } ,
                "class": {
                    type: "string",
                    defaultValue: "signature"
                }                
            }
        },
 
        renderer: function(oRm, oControl) {
            var thickness = parseInt(oControl.getProperty('thickness'), 10);
            oRm.write("<div id='siganturediv'");
            oRm.writeControlData(oControl);
            oRm.addStyle("width", oControl.getProperty('width'));
            oRm.addStyle("height", oControl.getProperty('height'));
            oRm.addStyle("background-color", oControl.getProperty('bgcolor'));
            oRm.addStyle("outline","#bfbfbf dotted");
            oRm.addStyle("margin-top","3mm");
            oRm.addStyle("margin-bottom","3mm");                                    
            oRm.writeStyles();
 
            oRm.writeClasses();
            oRm.write(">");
 
            oRm.write("<canvas class='signature' width='" + oControl.getProperty('width') + "' " +
                "height='" + oControl.getProperty('height') + "'");
            oRm.writeControlData(oControl);
            oRm.addStyle("width", oControl.getProperty('width'));
            oRm.addStyle("height", oControl.getProperty('height'));
            oRm.writeStyles();
            oRm.write("></canvas>");
            oRm.write("</div>");
        },
 
        onAfterRendering: function() {
        	var id = '#' + this.getId();
            //var canvas = document.querySelector("canvas");
            var canvas = document.querySelector(id);
            
            //var canvas = this;
            try {
                this.signaturePad = new SignaturePad(canvas);
            } catch (e) {
            //    console.error(e);
            }
        },
        
        clear: function() {
 
            this.signaturePad.clear();
 
        },
        
        isEmpty: function(){
          return this.signaturePad.isEmpty();	
        },
        
        save: function() {
            return this.signaturePad.toDataURL();
        }
    });
});