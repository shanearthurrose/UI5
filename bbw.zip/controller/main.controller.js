sap.ui.define(["sap/ui/core/mvc/Controller"], function(Controller) {
	"use strict";
	return Controller.extend("bbw.controller.main", {
		capturePhoto: function() {
			var that = this;
			var oNav = navigator.camera;
			oNav.getPicture(function cameraSuccess(imageUri) {
				var myImage = that.byId("myImage");
				myImage.setSrc("data:image/jpeg;base64," + imageUri);
			}, function onFail(error) {}, {
				quality: 20,
				destinationType: oNav.DestinationType.DATA_URL
			});
			this.getPosition();
		},
		/*
		 *  initial - prior to page load
		 */
		onInit: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			this.theTokenInput = this.getView().byId("location");
			this.theTokenInputid = this.getView().byId("locationid");
			var oRouter = this.getOwnerComponent().getRouter();

			oRouter.attachRouteMatched(function(oEvent) {
				if (oEvent.getParameter("name") !== "main") {
					return;
				}
				this._selectItemWithId(oEvent.getParameter("arguments"));
			}, this);
			//			//this.theTokenInput.setEnableMultiLineMode(sap.ui.Device.system.phone);

		},

		_selectItemWithId: function(arg) {

		},

		onBeforeRendering: function() {

		},

		onAfterRendering: function() {

			this.setDropDown("isolations", "FragApplication_YesNAObject", "Caption", true);
			this.setDropDown("controls", "FragApplication_YesNoNAObject", "Caption", true);
			var today = new Date();
			var dd = today.getDate();
			var MM = today.getMonth() + 1;
			if (MM < 10) {
				MM = "0" + MM;
			}
			var yyyy = today.getFullYear();
			var hh = today.getHours();
			var mm = today.getMinutes();
			var ss = today.getSeconds();
			this.byId("date").setDateValue(new Date());
			this.byId("reviewdate").setDateValue(new Date());

			this.getOwnerComponent().setDropDownFilter("reportedby", "SysEmployeeEntity", "FullName", "Email", this.getOwnerComponent().userid, "", "", true, true);
			this.getOwnerComponent().setLocation("location", "SysEmployeeEntity", "Location", "Email", this.getOwnerComponent().userid, "", "", true);

		},
		/**
		 *@memberOf nearmiss.controller.main
		 */
		onLocationChange: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var oLocationInput = new sap.m.Input();
			oLocationInput = this.byId("location");
			var oDepartmentSelect = new sap.ui.commons.ComboBox();
			oDepartmentSelect = this.byId("department");
			//	oDepartmentSelect.removeAllItems();

			//sap.m.MessageToast.show("loc:"+oLocationInput.getValue());

			if (oLocationInput.getValue() !== "") {
				//oDepartmentSelect.removeAllItems();
				this.getOwnerComponent().setDepartment("department", "hciMastIncdntv6_IMDepartmentObject", "DepartmentName", "location", oLocationInput.getValue(),
					"", "", true);
			}
		},
		/*
		  when the Department changes 
		*/
		onDepartmentChange: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var oLocationInput = new sap.m.Input();
			oLocationInput = this.byId("location");
			var oDepartmentSelect = new sap.ui.commons.ComboBox();
			oDepartmentSelect = this.byId("department");
			this.getOwnerComponent().setDropDownFilter("area", "FragApplication_SubDepartmentObject", "SDepartmentName", "department", oDepartmentSelect.getValue(),
				"location", oLocationInput.getValue(), false, true);
		},

		/*
		 *
		 * Set drop down values (coming from Sequis database Via WebMethods)
		 *
		 */
		setDropDown: function(field, systemname, fieldname, async) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			this.byId(field).setBusy(true);
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			oModel.read("/rest/commonIntelex/restIntelex/getRecords?systemName=" + systemname + "&Field=" + fieldname, //				"/odata/commonIntelex.odata:ointelex/getRecords?$filter=systemName eq '" + systemname + "' and field eq '" + fieldname + "'",
				null, null, async,
				function(oData, oResponse) {
					// create JSON model  
					oDataJSONModel.setData(oResponse);
					var obody = oDataJSONModel.getProperty("/body");
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					var oXMLModel = new sap.ui.model.xml.XMLModel();
					oXMLModel.setXML(obody);
					that.getView().setModel(oXMLModel, field);
					that.byId(field).setBusy(false); //	sap.ui.commons.MessageBox.alert(JSON.stringify(oResponse, null, 4));
				},
				function(oError) {
					that.byId(field).setBusy(false); //sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				});
		},

		onSubmit: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			jQuery.sap.require("sap.m.MessageToast");
			var that = this;
			var returnguid;
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			oModel.setHeaders({
				"X-Requested-With": "X"
			});
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var oXMLModel = new sap.ui.model.xml.XMLModel();
			var oRecord = {};
			var nameVal = [];
			var guid = "fe9a2075-a839-4880-a4ea-f46497282751";
			var systemName = "SRiskAssessment_JSRAObject";
			var objectId = "c71c54fa-6cab-4661-9166-28fddd045d60";
			nameVal = this._setJSRARecord();
			if (!this._validateDate()) {
				sap.m.MessageToast.show("Date/Time cannot be in the future");
			} else if (this._validateForm()) {
				oRecord.nameVal = nameVal;
				oRecord.systemName = systemName;
				sap.m.MessageToast.show("About to save Recorded");
				var query = "/rest/commonIntelex/restIntelex/dataManagerServices";
				//batchChanges.push( oModel.createBatchOperation(query,"POST", oRecord));
				oModel.create(query, oRecord, null, function(oData, oResult) {
					//sap.ui.commons.MessageBox.alert(JSON.stringify(oResult, null, 4));
					oDataJSONModel.setData(oResult);
					var obody = oDataJSONModel.getProperty("/body");
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					oXMLModel.setXML(obody);
					//sap.ui.commons.MessageBox.alert("guid:"+oXMLModel.getProperty("/"));
					that.getView().setModel(oXMLModel.getProperty("/"), "guid");
					returnguid = oXMLModel.getProperty("/");
					//	var objectId = "925b9271-8c18-4825-8f75-16819d23384f";
					if (that.byId("myImage").getSrc() !== null && that.byId("myImage").getSrc() !== "") {
						//sap.ui.commons.MessageBox.alert("srce:" + this.byId("myImage").getSrc());
						//	that._uploadImage("incident.jpg", returnguid, objectId, that.byId("myImage").getSrc());
					}
					that.setDropDownFilter("workflow", systemName, "Workflow.CurrentStageId", "id", returnguid, "", "", false, false);
					that.setDropDownFilter("nextworkflow", "SysWorkflowStageActionEntity", "", "stageId", that.getView().getModel("workflow").getProperty(
						"/getRecordsByFilter/fieldValue"), "", "", false, false);
					that._issueWorkflow(systemName, that.getView().getModel("nextworkflow").getProperty("/getRecordsByFilter/idValue"), returnguid);
					sap.ui.core.BusyIndicator.hide();
					sap.ui.commons.MessageBox.alert("Near Miss Successfully Submitted:");
					sap.m.MessageToast.show("Incident Success Recorded");
				}, function(oError) {
					sap.ui.core.BusyIndicator.hide(); //	sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				}, true);
			}
		},
		onSubmit2: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			jQuery.sap.require("sap.m.MessageToast");
			//sap.m.MessageToast.show("start");
			var that = this;
			var returnguid;
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			oModel.setHeaders({
				"X-Requested-With": "X"
			});
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var oXMLModel = new sap.ui.model.xml.XMLModel();
			var oRecord = {};
			var nameVal = [];
			var systemName = "SRiskAssessment_JSRAObject";
			var objectId = "c71c54fa-6cab-4661-9166-28fddd045d60";
			var guid = "fe9a2075-a839-4880-a4ea-f46497282751";
			//		if ( this.byId("reviewedby").isEmpty()){
			//		sap.ui.commons.MessageBox.alert("empty");
			//		}
			/*
			  Set the JSRA fields
			*/
			sap.m.MessageToast.show("submitting");
			if (!this._validateDate()) {
				sap.m.MessageToast.show("Date/Time cannot be in the future");
			} else if (this._validateForm()) {
				if (!this.byId("reviewedhazards").getState()) {
					sap.ui.commons.MessageBox.alert("Prompt Sheet has not been read");
					return;
				}
				if (!this.byId("myreviewedhazards").getState()) {
					sap.ui.commons.MessageBox.alert("Please confirm hazards have been reviewed");
					return;
				}
				if (this.byId("reviewedby").isEmpty()) {
					sap.ui.commons.MessageBox.alert("Please have someone sign JSRA");
					return;
				}
				nameVal = this._setJSRARecord();
				oRecord.nameVal = nameVal;
				//oRecord.systemName = "SafetyIncident_SafetyIncidentObject"; // for safety
				oRecord.systemName = systemName;
				// for safety				
				//sap.m.MessageToast.show("About to save Recorded");
				sap.m.MessageToast.show("Preparing JSRA...");
				this._createJSRA(oRecord, objectId, systemName);
				/*
																  Use: CreateBatch
																*/
			} else {
				sap.m.MessageToast.show("Please enter all information");
			}
		},
		_createJSRA: function(oRecord, objectId, systemName) {
			jQuery.sap.require("sap.ui.core.BusyIndicator");
			var that = this;
			var returnguid;
			var sServiceUrl = "/destinations/WebMethods";
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var oXMLModel = new sap.ui.model.xml.XMLModel();
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			oModel.setHeaders({
				"X-Requested-With": "X"
			});

			that._setRisk();

			//that.getRouter().navTo("result", {}, false);

			jQuery.sap.delayedCall(1000, this, function() {
				var query = "/rest/commonIntelex/restIntelex/dataManagerServices";
				oModel.create(query, oRecord, null, function(oData, oResult) {
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oResult, null, 4));
					oDataJSONModel.setData(oResult);
					var obody = oDataJSONModel.getProperty("/body");
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					oXMLModel.setXML(obody);
					//debug ==> sap.ui.commons.MessageBox.alert(JSON.stringify(obody, null, 4));
					that.getView().setModel(oXMLModel.getProperty("/"), "guid");
					returnguid = oXMLModel.getProperty("/");
					//	var objectId = "925b9271-8c18-4825-8f75-16819d23384f";
					//					if (that.byId("myImage").getSrc() !== null && that.byId("myImage").getSrc() !== "") {
					//sap.ui.commons.MessageBox.alert("srce:" + this.byId("myImage").getSrc());
					//	sap.ui.commons.MessageBox.alert("JSRA:signature.png" +  returnguid +":" + that.objectId + ":" + this.byId("reviewedby").save());
					that._uploadImage("signature1.png", returnguid, objectId, that.byId("reviewedby").save());
					if (!that.byId("reviewedby1").isEmpty()) {
						that._uploadImage("signature2.png", returnguid, objectId, that.byId("reviewedby1").save());
					}
					if (that.byId("myImage").getSrc() !== null && that.byId("myImage").getSrc() !== "") {
						//sap.ui.commons.MessageBox.alert("srce:" + this.byId("myImage").getSrc());
						that._uploadImage("jsra1.jpg", returnguid, objectId, that.byId("myImage").getSrc());
					}
					//	if (that.byId("myImage1").getSrc() !== null && that.byId("myImage").getSrc() !== "") {
					//		//sap.ui.commons.MessageBox.alert("srce:" + this.byId("myImage").getSrc());
					//		that._uploadImage("jsra2.jpg", returnguid, objectId, that.byId("myImage1").getSrc());
					//	}
					//					}
					that.setDropDownFilter("workflow", systemName, "Workflow.CurrentStageId", "id", returnguid, "", "", false, false);
					that.setDropDownFilter("nextworkflow", "SysWorkflowStageActionEntity", "", "stageId", that.getView().getModel("workflow").getProperty(
						"/getRecordsByFilter/fieldValue"), "", "", false, false);
					that._issueWorkflow(systemName, that.getView().getModel("nextworkflow").getProperty("/getRecordsByFilter/idValue"),
						returnguid);

					sap.ui.core.BusyIndicator.hide();

					//that._setRisk();
					that.getOwnerComponent().getRouter().navTo("result", {}, false);

					//sap.ui.commons.MessageBox.alert("JSRA Successfully Submitted:");
					//sap.ui.commons.MessageBox.alert("JSRA Successfully Submitted:" + returnguid + "Obj:" + objectId);					
					//sap.m.MessageToast.show("JSRA Successfully Submitted");
				}, function(oError) {
					sap.ui.core.BusyIndicator.hide();
					sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				}, true);

			});
			sap.ui.core.BusyIndicator.show(100);

		},
		_setInterlexField: function(record, field, value, id) {
			if (!id === null && !id === "") {
				if (this.byId(id).getVisible()) {
					record[record.length] = this._addField(field, value);
				}
			} else {
				record[record.length] = this._addField(field, value);
			}
		},

		_setRisk: function() {

			if (this.byId("confinedspace").getState() ||
				this.byId("harness").getState() ||
				this.byId("containerunloading").getState() ||
				this.byId("processchange").getState() ||
				this.byId("productquality").getState() ||
				this.byId("highvoltage").getState() ||
				this.byId("safetysystems").getState() ||
				this.byId("potentialrisk").getState() ||
				this.byId("controlmeasures").getSelectedKey() !== "Yes") {
				this.getOwnerComponent().setModel(true, "risk");
			} else {
				this.getOwnerComponent().setModel(false, "risk");
			}

		},
		/*
		   add field for Save 
		*/
		_addField: function(field, value) {
			var name = {};
			name.name = field;
			name.value = value;
			return name;
		},
		/*
		 * handle search for location field
		 *
		 */
		handleLocationPress: function(oEvent) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var oXMLModel = new sap.ui.model.xml.XMLModel();
			var showBusy = false;
			if (!this._oDialog) {
				oModel.read("/rest/commonIntelex/restIntelex/getRecords?systemName=SysLocationEntity&Field=Name", null, null, true, function(oData,
					oResponse) {
					// create JSON model  
					oDataJSONModel.setData(oResponse);
					var obody = oDataJSONModel.getProperty("/body");
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					oXMLModel.setXML(obody);
					sap.ui.core.BusyIndicator.hide();
				}, function(oError) {
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				});
				this._oDialog = sap.ui.xmlfragment("bbw.view.locationSelect", this);
				//this._oDialog.setModel(this.getView().getModel());
				this._oDialog.setModel(oXMLModel);
				showBusy = true;
			}
			// clear the old search filter
			this._oDialog.getBinding("items").filter([]);
			// toggle compact style
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog);
			this._oDialog.open();
			if (showBusy) {
				sap.ui.core.BusyIndicator.show();
			}
		},
		handleLocationSearch: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilterName = new sap.ui.model.Filter("fieldValue", sap.ui.model.FilterOperator.Contains, sValue);
			var oFilter = new sap.ui.model.Filter({
				filters: [oFilterName],
				and: false
			});
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		},
		handleLocationClose: function(oEvent) {
			var that = this;
			var aContexts = oEvent.getParameter("selectedContexts");
			if (aContexts && aContexts.length) {
				that.theTokenInput.setValue(aContexts.map(function(oContext) {
					//return oContext.getObject().fieldValue;
					return oContext.getModel().getProperty(oContext.getPath() + "/fieldValue");
				}));
				that.theTokenInputid.setText(aContexts.map(function(oContext) {
					//return oContext.getObject().fieldValue;
					return oContext.getModel().getProperty(oContext.getPath() + "/idValue");
				}));
				that.onLocationChange();
			}
			oEvent.getSource().getBinding("items").filter([]);
		},
		/**
		 *@memberOf nearmiss.controller.main
		 */
		getPhoto: function() {
			var that = this;
			var oNav = navigator.camera;
			oNav.getPicture(function onPhotoURISuccess(imageURI) {
				var myImage = that.byId("myImage");
				myImage.setSrc(imageURI);
			}, function onFail(error) {}, {
				quality: 20,
				destinationType: oNav.DestinationType.FILE_URI,
				sourceType: oNav.PictureSourceType.PHOTOLIBRARY
			});
		},
		onMismatch: function(e) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			sap.ui.commons.MessageBox.alert("mismatch");
		},
		onExceed: function(e) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			sap.ui.commons.MessageBox.alert("file name exceed");
		},
		onUploadCompleteFUP: function(e) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			//	sap.ui.commons.MessageBox.alert("Photo added");
			this.byId("photo1").clear();
		},
		onUploadCompleteFUP1: function(e) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			//	sap.ui.commons.MessageBox.alert("Photo added");
			//	this.byId("photo2").clear();
		},
		onSizeExceed: function(e) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			sap.ui.commons.MessageBox.alert("size exceed");
		},
		onChangeFUP: function(e) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			//			sap.ui.commons.MessageBox.alert("uploading");
			//			this.byId("photo1").clear();
			var output = this.byId("myImage");
			this._import(e.getParameter("files") && e.getParameter("files")[0], "myImage"); //this.byId("fileupload").attachChange("onChangeFUP");
		},
		onChangeFUP1: function(e) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			//			this.byId("photo2").clear();
			var output = this.byId("myImage1");
			this._import(e.getParameter("files") && e.getParameter("files")[0], "myImage1");
		},
		_import: function(file, id) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;

			if (file) {
				var reader = new FileReader();
				//	var reader = new FileReader();
				reader.onload = function() {
					var dataURL = reader.result;
					var output = that.byId(id);
					output.setSrc(dataURL);
				};
				reader.readAsDataURL(file);
			}
		},
		/**
		 *@memberOf nearmiss.controller.main
		 */
		onClearImage: function() {
			//This code was generated by the layout editor.
			var output = this.byId("myImage");
			output.setSrc();
		},

		onUndoPhoto: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			sap.m.MessageToast.show("reset");
			var output = this.byId("myImage");
			output.setSrc("./images/noimage.png");
			this.byId("photo1").clear();
		},
		/*
		  validate form
		*/
		_validateForm: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			//this._validateField("reportedby");
			var valid = true;
			if (this.byId("onsitejob").getState()) {
				if (!this._validateField("location"))
					valid = false;
			}

			if (this.byId("reportedby").getSelectedKey() === "") {
				this.byId("reportedby").setValueState(sap.ui.core.ValueState.Error);
				valid = false;
			} else {
				this.byId("reportedby").setValueState(sap.ui.core.ValueState.None);
			}

			if (!this.byId("lionemployee").getState()) {
				this._validateField("contractorcompany");
				this._validateField("contractorname");
			}

			if (!this._validateField("exactlocation"))
				valid = false;

			if (!this._validateField("exactlocation"))
				valid = false;

			if (!this._validateField("detailofwork"))
				valid = false;
			//	if (!this._validateField("additionalcontrols"))
			//		valid = false;
			if (!this._validateField("reviewdate"))
				valid = false;

			if (this.byId("isolations").getValue() !== "N/A") {
				if (!this._validateField("isolationpoints"))
					valid = false;
			} else {
				this.byId("isolationpoints").setValueState(sap.ui.core.ValueState.None);
			}

			if (!this._validateField("equipment"))
				valid = false;

			if (this.byId("controlmeasures").getSelectedKey() === " ") {
				this.byId("controlmeasures").setValueState(sap.ui.core.ValueState.Error);
				valid = false;
			} else {
				this.byId("controlmeasures").setValueState(sap.ui.core.ValueState.None);
			}
			return valid;
		},
		/*
		Function: _validateDate
		Parameters: none
		
		Returns Boolean value based on the date being less than today or not
		True - if date/time is less than today
		False - if date/time in the future
		
		
		*/
		_validateDate: function() {
			var valid = true;
			var dd = this.byId("date").getValue()[6] + this.byId("date").getValue()[7];
			var MM = this.byId("date").getValue()[4] + this.byId("date").getValue()[5];
			MM = parseInt(MM) - 1;
			var yyyy = this.byId("date").getValue()[0] + this.byId("date").getValue()[1] + this.byId("date").getValue()[2] + this.byId("date").getValue()[
				3];
			var hh = "00";
			var mm = "00";
			var DateTime;
			DateTime = new Date(yyyy, MM, dd, hh, mm, 0);
			var today = new Date();
			var DateTime_ms = DateTime.getTime();
			var today_ms = today.getTime();
			if (DateTime_ms > today_ms) {
				this.byId("date").setValueState(sap.ui.core.ValueState.Error);
				valid = false;
			}
			return valid;
		},
		/*
		  Function: _validateField
		  Parameters: 
			field - field name to perform validation on, currently checks if there is a value or not
			
		  Returns Boolean value
		*/
		_validateField: function(field) {
			var oInput = new sap.m.Input();
			oInput = this.byId(field);
			if (oInput.getVisible()) {
				if (oInput.getValue() === "") {
					oInput.setValueState(sap.ui.core.ValueState.Error);
					return false;
				} else {
					oInput.setValueState(sap.ui.core.ValueState.None);
				}
			}
			return true;
		},
		/**
		 *@memberOf nearmiss.controller.main
		 */
		onCategoryChange: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var oCategorySelect = new sap.m.Select();
			oCategorySelect = this.byId("category");
			var osubcategorySelect = new sap.m.Select();
			osubcategorySelect = this.byId("subcategory");
			if (osubcategorySelect.getVisible()) {
				this.setDropDownFilter("subcategory", "QualiIncidentV6_QualityCat2Object", "QualitCategory2", "QualityCat1", oCategorySelect.getValue(),
					"", "", false, true);
			}
		},
		/**
		 *@memberOf nearmiss.controller.main
		 */
		onCapitonWorksChange: function() {
			//This code was generated by the layout editor.
			this.byId("projectname").setVisible(false);
			this.byId("__labelprojectname").setVisible(false);
			if (!this.byId("capital").getState() && this.byId("capital").getVisible()) {
				this.byId("projectname").setVisible(true);
				this.byId("__labelprojectname").setVisible(true);
			}
		},
		onSiteChange: function() {
			//This code was generated by the layout editor.
			this.byId("location").setVisible(false);
			this.byId("__labellocation").setVisible(false);
			this.byId("department").setVisible(false);
			this.byId("__labeldepartment").setVisible(false);
			this.byId("area").setVisible(false);
			this.byId("__labelarea").setVisible(false);
			if (!this.byId("onsite").getState()) {
				this.byId("location").setVisible(true);
				this.byId("__labellocation").setVisible(true);
				this.byId("department").setVisible(true);
				this.byId("__labeldepartment").setVisible(true);
				this.byId("area").setVisible(true);
				this.byId("__labelarea").setVisible(true);
			}
		},
		onControlChange: function() {
			//This code was generated by the layout editor.
			this.byId("__labelexp").setVisible(false);
			this.byId("notcontrolled").setVisible(false);
			if (this.byId("reporttype").getValue() === "Environment") {
				if (this.byId("controlled").getState()) {
					this.byId("__labelexp").setVisible(true);
					this.byId("notcontrolled").setVisible(true);
				}
			}
		},
		/*
		  Function: _issueWorkflow
		  Parameters: 
			SystemName - Name of the system in Sequis
			actionId - guid of the next workflow item
			guid - Guid of the record in sequis that workflow is for 
		
		*/
		_issueWorkflow: function(SystemName, actionId, guid) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			oModel.setHeaders({
				"X-Requested-With": "X"
			});
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var oXMLModel = new sap.ui.model.xml.XMLModel();
			var oRecord = {};
			oRecord.systemName = SystemName;
			oRecord.actionId = actionId;
			oRecord.guid = guid;
			//sap.ui.commons.MessageBox.alert("workFlow");
			var query = "/rest/commonIntelex/restIntelex/workflowService";
			oModel.create(query, oRecord, null, function(oData, oResult) {
				//sap.ui.commons.MessageBox.alert(JSON.stringify(oResult, null, 4));
				oDataJSONModel.setData(oResult);
				var obody = oDataJSONModel.getProperty("/body"); //sap.ui.commons.MessageBox.alert(JSON.stringify(oResult, null, 4));
				//
				//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
				//
				//oXMLModel.setXML(obody);
				//sap.ui.commons.MessageBox.alert("guid:"+oXMLModel.getProperty("/"));
				//that.getView().setModel(oXMLModel.getProperty("/"), "guid");
				//sap.ui.commons.MessageBox.alert("Incident Success Recorded");
			}, function(oError) {
				//	sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
			});
		},
		/*
		  Function: _uploadImage
		  Parameters: 
		   Filename - Name of the file when attching to sequis
		   RecordId - the guid of the record in sequis where the attachment will be 
		   ObjectId - the guid of the sequis type
		   Source - the source base64 of the image
		   
		*/
		_uploadImage: function(Filename, RecordId, ObjectId, Source) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			oModel.setHeaders({
				"X-Requested-With": "X"
			});
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var oXMLModel = new sap.ui.model.xml.XMLModel();
			var oRecord = {};
			oRecord.Filename = Filename;
			// for safety
			oRecord.RecordId = RecordId;
			oRecord.ObjectId = ObjectId;
			oRecord.Source = Source;
			//	sap.ui.commons.MessageBox.alert("JSRA RecordID:" + oRecord.RecordId + "Obj:" + oRecord.ObjectId);								
			//sap.ui.commons.MessageBox.alert("workFlow");
			var query = "/rest/commonIntelex/restIntelex/PrivateDocumentAttachmentService";
			oModel.create(query, oRecord, null, function(oData, oResult) {
				//sap.ui.commons.MessageBox.alert(JSON.stringify(oResult, null, 4));
				oDataJSONModel.setData(oResult);
				var obody = oDataJSONModel.getProperty("/body"); //	sap.ui.commons.MessageBox.alert(JSON.stringify(oResult, null, 4));
			}, function(oError) {
				//	sap.ui.commons.MessageBox.alert("Image Error:" + JSON.stringify(oError, null, 4));
			});
		},
		/*
		  @todo 
		  This will set all fields for JSRA in sequis.
		*/
		_setJSRARecord: function() {
			var nameVal = [];
			var now = new Date();
			var guid = "fe9a2075-a839-4880-a4ea-f46497282751";
			// date 
			var dd = this.byId("date").getValue()[6] + this.byId("date").getValue()[7];
			var MM = this.byId("date").getValue()[4] + this.byId("date").getValue()[5];
			//	MM = parseInt(MM) - 1;
			var yyyy = this.byId("date").getValue()[0] + this.byId("date").getValue()[1] + this.byId("date").getValue()[2] + this.byId("date").getValue()[
				3];

			var hh = now.getHours();
			var mm = now.getMinutes();

			var myDate = new Date(MM + '/' + dd + '/' + yyyy + ' ' + hh + ':' + mm + ':00');
			var month = myDate.getUTCMonth() + 1; //Month is between 0 - 11
			var newDate = myDate.getUTCDate() + '/' + month + '/' + myDate.getUTCFullYear() + ' ' + myDate.getUTCHours() + ':' + myDate.getUTCMinutes() +
				':00';
			//			var newDate = dd + '/' + MM + '/' + yyyy + ' ' + hh + ':' + mm + ':00';

			var reviewdd = this.byId("reviewdate").getValue()[6] + this.byId("reviewdate").getValue()[7];
			var reviewMM = this.byId("reviewdate").getValue()[4] + this.byId("reviewdate").getValue()[5];
			//	MM = parseInt(MM) - 1;
			var reviewyyyy = this.byId("reviewdate").getValue()[0] + this.byId("reviewdate").getValue()[1] + this.byId("reviewdate").getValue()[
				2] + this.byId("reviewdate").getValue()[3];
			//			var newDate = dd + '/' + MM + '/' + yyyy + ' ' + hh + ':' + mm + ':00';
			var reviewDate = new Date(reviewMM + "/" + reviewdd + "/" + reviewyyyy + ' ' + hh + ':' + mm + ':00');
			//var myDate = new Date(MM + "/" + dd + "/" + yyyy + " " + hh + ":" + mm + ":00");			
			var reviewmonth = reviewDate.getUTCMonth() + 1;
			//Month is between 0 - 11
			var reviewNewDate = reviewDate.getUTCDate() + "/" + reviewmonth + "/" + reviewDate.getUTCFullYear() + " " + reviewDate.getUTCHours() +
				":" + reviewDate.getUTCMinutes() + ":00";

			var i = 0;
			nameVal[i] = this._addField("AdditionControl", this.byId("additionalcontrols").getValue());
			//sap.m.MessageToast.show("here");
			i++;
			nameVal[i] = this._addField("Confinedspace", this.byId("confinedspace").getState() ? "yes" : "no");
			i++;
			nameVal[i] = this._addField("Contaiunloading", this.byId("containerunloading").getState() ? "yes" : "no");
			i++;
			//			//nameVal[i] = this._addField("measureadequate", this.byId("controlmeasures").getState() ? "yes" : "no");
			nameVal[i] = this._addField("measureadequate", this.byId("controlmeasures").getSelectedKey());
			i++;
			//	sap.m.MessageToast.show("setting JSRA Fields");	
			nameVal[i] = this._addField("Controlsinplace", this.byId("controls").getSelectedKey());
			//>>>	nameVal[i] = this._addField("Controlsinplace", this.byId("controls").getState() ? "yes" : "no");
			i++;
			nameVal[i] = this._addField("DateReviewed1", reviewNewDate);
			i++;
			nameVal[i] = this._addField("Dateidentified", newDate);
			//nameVal[i] = this._addField("DateReviewed1", this.byId("reviewdate").getValue());			
			i++;
			nameVal[i] = this._addField("sourcesisolated", this.byId("isolations").getSelectedKey());
			i++;
			nameVal[i] = this._addField("Harnessrequired", this.byId("harness").getState() ? "yes" : "no");
			i++;
			nameVal[i] = this._addField("Highvolatage", this.byId("highvoltage").getState() ? "yes" : "no");
			i++;
			nameVal[i] = this._addField("Hotwork", this.byId("hotwork").getState() ? "yes" : "no");
			i++;
			nameVal[i] = this._addField("isolationpoints", this.byId("isolationpoints").getValue());

			i++;
			nameVal[i] = this._addField("Comments", this.byId("comments").getValue());

			i++;
			nameVal[i] = this._addField("PersResponsible", this.byId("reportedby").getSelectedKey());

			i++;
			//
			nameVal[i] = this._addField("Potentialrisk", this.byId("potentialrisk").getState() ? "yes" : "no");
			i++;
			nameVal[i] = this._addField("Processchange", this.byId("processchange").getState() ? "yes" : "no");
			i++;
			nameVal[i] = this._addField("Productquality", this.byId("productquality").getState() ? "yes" : "no");
			i++;
			nameVal[i] = this._addField("Reviewedhazards", this.byId("reviewedhazards").getState() ? "yes" : "no");
			i++;
			nameVal[i] = this._addField("Safetysystems", this.byId("safetysystems").getState() ? "yes" : "no");
			//	i++;
			//	nameVal[i] = this._addField("Workareaclean", this.byId("clean").getState() ? "yes" : "no");
			i++;
			nameVal[i] = this._addField("Workinatheights", this.byId("height").getState() ? "yes" : "no");

			i++;
			nameVal[i] = this._addField("Onsite", this.byId("onsitejob").getState() ? "yes" : "no");
			//			i++;
			//			nameVal[i] = this._addField("Dateidentifiedt", newDate);

			if (this.byId("onsitejob").getState()) {
				i++;
				nameVal[i] = this._addField("Location", this.byId("locationid").getText());
				i++;
				nameVal[i] = this._addField("Department", this.byId("department").getSelectedKey());
				i++;
				nameVal[i] = this._addField("subDepartment", this.byId("area").getSelectedKey());
			}
			i++;
			nameVal[i] = this._addField("ExactLocation", this.byId("exactlocation").getValue());
			i++;
			nameVal[i] = this._addField("Description", this.byId("detailofwork").getValue());
			i++;
			nameVal[i] = this._addField("Equipment", this.byId("equipment").getValue());
			i++;
			nameVal[i] = this._addField("Revieallhazards", this.byId("myreviewedhazards").getState() ? "yes" : "no");

			i++;
			nameVal[i] = this._addField("Lionemployee", this.byId("lionemployee").getState() ? "yes" : "no");

			if (!this.byId("lionemployee").getState()) {
				i++;
				nameVal[i] = this._addField("Contractorname", this.byId("contractorname").getValue());
				i++;
				nameVal[i] = this._addField("ContractCompany", this.byId("contractorcompany").getValue());
			}

			return nameVal;
		},
		/**
		 *@memberOf jsra.controller.main
		 */
		onClearSignature: function() {
			//This code was generated by the layout editor.
			//sap.ui.commons.MessageBox.alert(this.byId("reviewedby").save());
			this.byId("reviewedby").clear();
		},
		undoSig: function() {
			//This code was generated by the layout editor.
			//sap.ui.commons.MessageBox.alert(this.byId("reviewedby").save());
			this.byId("reviewedby").clear();

		},
		undoSig1: function() {
			//This code was generated by the layout editor.
			//sap.ui.commons.MessageBox.alert(this.byId("reviewedby").save());
			this.byId("reviewedby1").clear();
		},
		/**
		 *@memberOf jsra.controller.main
		 */
		displayPDF: function() {
			//This code was generated by the layout editor.
			//	sap.m.URLHelper.redirect("./docs/RISK_ASSESSMENT_PROMPT_SHEET.pdf",true);
			this.byId("reviewedhazards").setState(true);
			this.byId("hazardreviewpanel").setExpanded(true);
			this.getOwnerComponent().getRouter().navTo("risk", {}, false); //this.getView().setVisible(false);
			//	sap.m.MessageToast.show("press");
		},
		undoPhoto: function() {
			this.byId("myImage").setSrc();
		},
		/**
		 *@memberOf jsra.controller.main
		 */
		onHazardPromptChange: function() {
			//This code was generated by the layout editor.
			if (this.byId("confinedspace").getState() || this.byId("harness").getState() || this.byId("containerunloading").getState() || this.byId(
					"processchange").getState() || this.byId("productquality").getState() || this.byId("highvoltage").getState() || this.byId(
					"safetysystems").getState() || this.byId("potentialrisk").getState()) {
				this.byId("hazardtitle").setText("Hazard Prompt - follow permit process");
			} else {
				this.byId("hazardtitle").setText("Hazard Prompt");
			}
		},
		/**
		 *@memberOf jsra.controller.main
		 */
		onSiteJob: function() {

			if (this.byId("onsitejob").getState()) {
				this.byId("__labellocation").setVisible(true);
				this.byId("location").setVisible(true);
				this.byId("__labeldepartment").setVisible(true);
				this.byId("department").setVisible(true);
				this.byId("__labelarea").setVisible(true);
				this.byId("area").setVisible(true);
			} else {
				this.byId("__labellocation").setVisible(false);
				this.byId("location").setVisible(false);
				this.byId("__labeldepartment").setVisible(false);
				this.byId("department").setVisible(false);
				this.byId("__labelarea").setVisible(false);
				this.byId("area").setVisible(false);
			}

		},
		onLionEmployee: function() {

			if (this.byId("lionemployee").getState()) {
				this.byId("contractorcompany").setVisible(false);
				this.byId("__labelcontractorcompany").setVisible(false);
				this.byId("contractorname").setVisible(false);
				this.byId("__labelcontractorname").setVisible(false);

			} else {
				this.byId("contractorcompany").setVisible(true);
				this.byId("__labelcontractorcompany").setVisible(true);
				this.byId("contractorname").setVisible(true);
				this.byId("__labelcontractorname").setVisible(true);
			}
		},

		onChangeIsolations: function(ev) {
			//	alert("change"+ev.getSource().getValue());
			if (ev.getSource().getValue() === "N/A") {
				this.byId("isolationpoints").setVisible(false);
			} else {
				this.byId("isolationpoints").setVisible(true);
			}
			//id="isolationpoints"
		},

		onLogon: function(ev) {

			if (!this.getOwnerComponent().logon) {
				this.getOwnerComponent().logon = sap.ui.xmlfragment("jsra.view.login", this.getOwnerComponent()); //	this.oContactDialog.setModel(this.getOwnerComponent().getModel("sellins"), "sellins");
			}
			this.getOwnerComponent().logon.open();
		}
	});
});