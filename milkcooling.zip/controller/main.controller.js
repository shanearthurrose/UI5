sap.ui.define(["sap/ui/core/mvc/Controller", "sap/ui/model/Filter"], function(Controller) {
	"use strict";
	return Controller.extend("milkcooling.controller.main", {
		getRouter: function() {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},
		onToView2: function() {
			this.getRouter().navTo("final"); //this.getOwnerComponent().getTargets().display("final");
		},

		handleSelectDialogPress: function(oEvent) {
			var sServiceUrl = "/destinations/milkCooling/sap/opu/odata/sap/ZOGSM_SRV/";
			var odataModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			var oRowsModel = new sap.ui.model.json.JSONModel();

			//oRowsModel = sap.ui.getCore().getModel("oRowsModel");
			//this.getView().setModel(oRowsModel);

			if (!this._oDialog) {
				odataModel.read("ZMC_FARMERSet", null, null, false, function(oData) {
					// create JSON model  
					oRowsModel.setData(oData);
				}, function(oError) {
					sap.m.MessageToast.show("Error1");
				});
				this._oDialog = sap.ui.xmlfragment("milkcooling.view.farmerSelect", this);
				//this._oDialog.setModel(this.getView().getModel());
				this._oDialog.setModel(oRowsModel);
			}

			// clear the old search filter
			this._oDialog.getBinding("items").filter([]);

			// toggle compact style
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog);
			this._oDialog.open();

			//sap.ui.commons.MessageBox.alert(oRowsModel.getJSON());
		},

		handleFarmerSearch: function(oEvent) {

			var sValue = oEvent.getParameter("value");
			var oFilterName = new sap.ui.model.Filter("Name", sap.ui.model.FilterOperator.Contains, sValue);
			var oFilterZone = new sap.ui.model.Filter("Vtext", sap.ui.model.FilterOperator.Contains, sValue);
			var oFilter = new sap.ui.model.Filter({
				filters: [oFilterName, oFilterZone],
				and: false
			});
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		},

		handleFarmerClose: function(oEvent) {
			var that = this;
			var token = new sap.m.Token();
			var aContexts = oEvent.getParameter("selectedContexts");

			token.setKey(aContexts.map(function(oContext) {
				return oContext.getObject().Lifnr;
			}));
			token.setText(aContexts.map(function(oContext) {
				return oContext.getObject().Name;
			}));

			if (aContexts && aContexts.length) {
				//sap.m.MessageToast.show("You have chosen " + aContexts.map(function(oContext) { return oContext.getObject().Name; }).join(", "));
				that.theTokenInput.setTokens([token]);
			}
			oEvent.getSource().getBinding("items").filter([]);
		},
		/**

When User hits BACK Button

**/
		onBack: function() {
			// this.getOwnerComponent().getTargets().display("initial");
			this.onReset();
			var page = new sap.m.Page();
			page = this.byId("Tempurature");
			page.scrollTo(0, 0);
			this.getRouter().navTo("initial", {}, false /*no history*/ );
		},
		/**
			Initialise
		**/
		onBeforeRendering: function() {
			this.onReset();
		},

		onInit: function() {
			jQuery.sap.require("sap.m.MessageBox");
			var oModel = new sap.ui.model.json.JSONModel();
			var oRowsModel = new sap.ui.model.json.JSONModel();
			var oSiteModel = new sap.ui.model.json.JSONModel();
			var oCarrierModel = new sap.ui.model.json.JSONModel();
			var sServiceUrl = "/destinations/milkCooling/sap/opu/odata/sap/ZOGSM_SRV/";
			var odataModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			this.getView().setModel(oModel);
			this.getView().bindElement("/");

			this.aKeys = [
				"Lifnr",
				"Name"
			];
			this.theTokenInput = this.getView().byId("__inputFarmer");
			this.theTokenInput.setEnableMultiLineMode(sap.ui.Device.system.phone);
			/*
			 get all carriers
			*/
			odataModel.read("ZMC_CARRIER_LISTSet", null, null, false, function(oData) {
				// create JSON model  
				oCarrierModel.setData(oData);
				sap.ui.getCore().setModel(oCarrierModel, "oCarrierModel");
			}, function(oError) {
				sap.m.MessageToast.show("Error2");
			});

			/**
			 * get all vendors (which equate to farmers)
			 */

			odataModel.read("ZMC_FARMERSet", null, null, false, function(oData) {
				// create JSON model  
				oRowsModel.setData(oData);
				sap.ui.getCore().setModel(oRowsModel, "oRowsModel");
			}, function(oError) {
				sap.m.MessageToast.show("Error3");
			});

			/**
			 * get all available plant/name combinations
			 */
			odataModel.read("H_PLANTSet", null, null, false, function(oData) {
				// create JSON model  
				oSiteModel.setData(oData);
				sap.ui.getCore().setModel(oSiteModel, "oSiteModel");
			}, function(oError) {
				//sap.m.MessageToast.show("Error4");
			});

			//Use oSiteModel...
			var oSelect = new sap.m.Select();
			var oItem = new sap.ui.core.Item();
			oSelect = this.byId("site");
			// loop over json data...
			var sites = oSiteModel.getProperty("/results");
			//sap.m.MessageBox.confirm(oSiteModel.getJSON());
			//oItem.setKey(" ");
			//oItem.setText("Please Enter Site");
			//oSelect.addItem(oItem);

			for (var i = 0; i < sites.length; i++) {
				var oItem = new sap.ui.core.Item();
				oItem.setKey(sites[i].Werks);
				oItem.setText(sites[i].Werks + "-" + sites[i].Name1);
				oSelect.addItem(oItem);
			}

			//Use oCarrierModel...

			var oCarrierSelect = new sap.m.Select();
			var oCarrierItem = new sap.ui.core.Item();
			oCarrierSelect = this.byId("lioncarrier");
			// loop over json data...
			var carriers = oCarrierModel.getProperty("/results");
			//sap.m.MessageBox.confirm(oSiteModel.getJSON());
			//oCarrierItem.setKey(" ");
			//oCarrierItem.setText("Please Enter Carrier");
			//oCarrierSelect.addItem(oCarrierItem);

			for (var i = 0; i < carriers.length; i++) {
				var oCarrierItem = new sap.ui.core.Item();
				oCarrierItem.setKey(carriers[i].Lifnr);
				oCarrierItem.setText(carriers[i].Lifnr + "-" + carriers[i].Name1);
				oCarrierSelect.addItem(oCarrierItem);
			}

			/*
			  retriev User Details
			*/
			jQuery.sap.require("sap.m.MessageBox");
			jQuery.sap.require("sap.ui.commons.AutoComplete");

			var userModel = new sap.ui.model.json.JSONModel("/services/userapi/currentUser");
			userModel.loadData("/services/userapi/currentUser", null, false);
			sap.ui.getCore().setModel(userModel, "userapi");
			//	sap.m.MessageBox.alert("here"+userModel.getJSON());

		},
		/**
			Help requets for Farmer 
		**/
		onValueRequest: function(evt) {
			//jQuery.sap.require("sap.m.MessageBox");
			jQuery.sap.require("sap.ui.comp.valuehelpdialog.ValueHelpDialog");
			jQuery.sap.require("sap.ui.comp.filterbar.FilterBar");

			var thisSite = this;

			//var theTokenInput = this.getView().byId("__inputFarmer");
			var oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
				basicSearchText: this.theTokenInput.getValue(),
				title: "Farmer",
				supportMultiselect: false,
				supportRanges: false,
				supportRangesOnly: false,
				key: this.aKeys[0],
				descriptionKey: this.aKeys[1],
				stretch: sap.ui.Device.system.phone,
				filterMode: true,
				ok: function(oControlEvent1) {
					thisSite.aTokens = oControlEvent1.getParameter("tokens");
					thisSite.theTokenInput.setTokens(thisSite.aTokens);
					oValueHelpDialog.close();
				},
				cancel: function() {
					sap.m.MessageToast.show("Cancel pressed!");
					oValueHelpDialog.close();
				},
				afterClose: function() {
					oValueHelpDialog.destroy();
				}
			});

			var oColModel = new sap.ui.model.json.JSONModel();
			oColModel.setData({
				cols: [{
					label: "Famer",
					template: "Lifnr"
				}, {
					label: "Name",
					template: "Name"
				}, {
					label: "Zone",
					template: "ZzFrZone"
				}, {
					label: "Description",
					template: "Vtext"
				}]
			});
			oValueHelpDialog.getTable().setModel(oColModel, "columns");

			var oRowsModel = new sap.ui.model.json.JSONModel();
			oRowsModel = sap.ui.getCore().getModel("oRowsModel");
			oValueHelpDialog.getTable().setModel(oRowsModel);

			if (oValueHelpDialog.getTable().bindRows) {
				oValueHelpDialog.getTable().bindRows("/results");
			}

			if (oValueHelpDialog.getTable().bindItems) {
				var oTable = oValueHelpDialog.getTable();
				oTable.bindAggregation("items", "/results", function(sId, oContext) {
					var aCols = oTable.getModel("columns").getData().cols;
					return new sap.m.ColumnListItem({
						cells: aCols.map(function(column) {
							var colname = column.template;
							return new sap.m.Label({
								text: "{" + colname + "}"
							});
						})
					});
				});
			}

			//		sap.m.MessageToast.show("Search pressed");
			var oFilterBar = new sap.ui.comp.filterbar.FilterBar({
				advancedMode: true,
				filterBarExpanded: false,
				showGoOnFB: !sap.ui.Device.system.phone,
				filterGroupItems: [
					new sap.ui.comp.filterbar.FilterGroupItem({
						groupTitle: "farmer",
						groupName: "gn1",
						name: "Lifnr",
						label: "Farmer",
						control: new sap.m.Input()
					}),
					new sap.ui.comp.filterbar.FilterGroupItem({
						groupTitle: "farmer",
						groupName: "gn1",
						name: "Name",
						label: "Name",
						control: new sap.m.Input()
					}),
					new sap.ui.comp.filterbar.FilterGroupItem({
						groupTitle: "Zone",
						groupName: "gn2",
						name: "ZzFrZone",
						label: "Zone",
						control: new sap.m.Input()
					}),
					new sap.ui.comp.filterbar.FilterGroupItem({
						groupTitle: "Zone",
						groupName: "gn2",
						name: "Vtext",
						label: "Description",
						control: new sap.m.Input()
					})
				],

				search: function(oEvent) {
					//sap.m.MessageToast.show("Search pressed");
					var oBinding = oValueHelpDialog.getTable().getBinding("rows");

					var oFarmer = arguments[0].mParameters.selectionSet[0].getValue();
					var oName = arguments[0].mParameters.selectionSet[1].getValue();
					var oZone = arguments[0].mParameters.selectionSet[2].getValue();
					var oZoneDesc = arguments[0].mParameters.selectionSet[3].getValue();
					var aFilters = [];
					var oFilter = new sap.ui.model.Filter("Lifnr", sap.ui.model.FilterOperator.Contains, oFarmer);
					aFilters.push(oFilter);
					var oNameFilter = new sap.ui.model.Filter("Name", sap.ui.model.FilterOperator.Contains, oName);
					aFilters.push(oNameFilter);
					// var oNameFilter = new sap.ui.model.Filter("Name", sap.ui.model.FilterOperator.Contains, oName);
					aFilters.push(oNameFilter);
					var oZoneFilter = new sap.ui.model.Filter("ZzFrZone", sap.ui.model.FilterOperator.Contains, oZone);
					aFilters.push(oZoneFilter);
					var oZoneDescFilter = new sap.ui.model.Filter("Vtext", sap.ui.model.FilterOperator.Contains, oZoneDesc);
					aFilters.push(oZoneDescFilter);
					// update list binding
					//oBinding.setFilterMode(true);
					oValueHelpDialog.getTable().bindRows({
						path: "/results",
						filters: aFilters
					});
					//oBinding.filter(aFilters);

				}
			});

			if (oFilterBar.setBasicSearch) {
				oFilterBar.setBasicSearch(new sap.m.SearchField({
					showSearchButton: sap.ui.Device.system.phone,
					placeholder: "Search",
					search: function(oEvent) {
						sap.m.MessageToast.show("really basic Search");
						var oBinding = oValueHelpDialog.getTable().getBinding("rows");
						var oName = "Kerry";
						var aFilters = [];
						var oNameFilter = new sap.ui.model.Filter("Name", sap.ui.model.FilterOperator.Contains, oName);
						aFilters.push(oNameFilter);
						//	oBinding.filter(aFilters);
						oValueHelpDialog.getTable().bindRows({
							path: "/results",
							filters: aFilters
						});

						//					oValueHelpDialog.getFilterBar().search();
					}
				}));
			}

			oValueHelpDialog.setFilterBar(oFilterBar);

			if (this.theTokenInput.$().closest(".sapUiSizeCompact").length > 0) { // check if the Token field runs in Compact mode
				oValueHelpDialog.addStyleClass("sapUiSizeCompact");
			} else {
				oValueHelpDialog.addStyleClass("sapUiSizeCozy");
			}

			oValueHelpDialog.open();
			oValueHelpDialog.update();
		},
		/**
		 * 
		 * when User hits the refresh Button
		 * 
		 */
		onReset: function() {
			//sap.m.MessageBox.alert("here"+sap.ui.getCore().getModel("userapi").getJSON());
			//sap.m.MessageBox.alert("here:"+sap.ui.getCore().getModel("userapi").getJSON());
			this.getView().getModel().setData({});
			var oInput = new sap.m.MultiInput();
			oInput = this.byId("__inputFarmer");
		//	oInput.setTokens({});
			//oInput = this.byId("__inputSite");
			//oInput.setTokens({});
			var oSelect = new sap.m.Select();

			oSelect = this.byId("temperature");
			oSelect.setSelectedKey(" ");

			oSelect = this.byId("time");
			oSelect.setSelectedKey(" ");

			oSelect = this.byId("event");
			oSelect.setSelectedKey(" ");

			var oSite = new sap.m.Select();
			oSite = this.byId("site");
			oSite.setSelectedItem(oSite.getItemByKey(" "));

			var oCarrier = new sap.m.Select();
			oCarrier = this.byId("lioncarrier");
			oCarrier.setSelectedItem(oCarrier.getItemByKey(" "));

			var oI = new sap.m.Input();
			oI = this.byId("inputArrival");
			oI.setValue("");

			oI = this.byId("driverName");
			oI.setValue("");

			oI = this.byId("driverPhone");
			oI.setValue("");

		},
		/**
		 * 
		 * when the User SUbmits Request
		 * 
		 */
		onAccept: function(evt) {
			// validate first - iff all ok then submit form
			if (this.validateInput()) {
				this.submitRequest();
			}
		},
		/**
		 *Validate user input
		 */
		validateInput: function() {
			jQuery.sap.require("sap.m.MessageBox");
			var valid = true;
			if (!this.validateField("__inputContactName")) {
				valid = false;
			}
			if (!this.validateField("__inputContactPhone")) {
				valid = false;
			}
			//if (!this.validateField("__inputCarrier")) {
			//	valid = false;
			//}
			if (!this.validateSelectField("lioncarrier")) {
				valid = false;
			}
			if (!this.validateMultiField("__inputFarmer")) {
				valid = false;
			}
			if (!this.validateField("__inputVolume")) {
				valid = false;
			}
			if (!this.validateSelectField("site")) {
				valid = false;
			}
			if (!this.validateField("inputArrival")) {
				valid = false;
			}
			if (!this.validateField("totalLoad")) {
				valid = false;
			}
			if (!this.validateField("avgTemp")) {
				valid = false;
			}
			if (!this.validateField("__inputCRN")) {
				valid = false;
			}
			if (!this.validateField("driverName")) {
				valid = false;
			}
			if (!this.validateField("driverPhone")) {
				valid = false;
			}
			if (!this.validateSelectField("time")) {
				valid = false;
			}
			if (!this.validateSelectField("temperature")) {
				valid = false;
			}
			if (!this.validateSelectField("event")) {
				valid = false;
			}
			return valid;
		},
		/**
		 * 
		 * validate fields (Input type)
		 * 
		 */
		validateField: function(field) {
			var oInput = new sap.m.Input();
			oInput = this.byId(field);
			if (oInput.getValue() === "") {
				oInput.setValueState(sap.ui.core.ValueState.Error);
				return false;
			} else {
				oInput.setValueState(sap.ui.core.ValueState.None);
			}
			return true;
		},
		/**
		 * 
		 * Validate MultiInput Fields
		 * 
		 */
		validateMultiField: function(field) {
			jQuery.sap.require("sap.m.MessageBox");
			var oInput = new sap.m.MultiInput();
			oInput = this.byId(field);
			var fValue = oInput.getTokens();
			//	sap.m.MessageBox.alert("ok:"+fValue.length);
			if (fValue.length === 0) {
				oInput.setValueState(sap.ui.core.ValueState.Error);
				return false;
			} else {
				oInput.setValueState(sap.ui.core.ValueState.None);
			}
			return true;
		},
		validateSelectField: function(field) {
			jQuery.sap.require("sap.m.MessageBox");
			var oInput = new sap.m.Select();
			oInput = this.byId(field);
			var fValue = oInput.getSelectedKey();
			if (fValue === " ") {
				return false;
			} else {
				return true;
			}
			return true;
		},
		/*
 submit the input to SAP for calculation result
*/
		submitRequest: function() {
			var oInput = new sap.m.Input();
			var oMultiInput = new sap.m.MultiInput();
			var oInputVolume = new sap.m.Input();
			var ototalLoad = new sap.m.Input();
			var oInputTemp = new sap.m.Input();
			var oEntry = {};
			//This code was generated by the layout editor.
			// need to call odata request here........
			//Itemperature
			jQuery.sap.require("sap.m.MessageBox");
			//this.byId("lblResult").setText("something");
			//Ievent
			var oEvent = new sap.m.Select();
			oEvent = this.byId("event");
			var oTemp = new sap.m.Select();
			oTemp = this.byId("temperature");
			var oTime = new sap.m.Select();
			oTime = this.byId("time");
			var sServiceUrl = "/destinations/milkCooling/sap/opu/odata/sap/ZOGSM_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			var oODataJSONModel = new sap.ui.model.json.JSONModel();
			sap.ui.getCore().setModel(oModel);
			oModel.read("ZMILK_COOLINGSet(Event='" + oEvent.getSelectedKey() + "',Time='" + oTime.getSelectedKey() + "',Temperature=" + oTemp.getSelectedKey() +
				"m)", null, null, false,
				function(oData, oResponse) {
					// create JSON model  
					oODataJSONModel.setData(oData);
				},
				function(oError) {
					// create JSON model  
					jQuery.sap.require("sap.m.MessageBox");
					sap.m.MessageBox.show("ZMILK_COOLINGSet(Event='" + oEvent.getSelectedKey() + "',Time='" + oTime.getSelectedKey() +
						"',Temperature=" + oTemp.getSelectedKey() + "m)");
				});
			var obj = {};
			obj.value = oODataJSONModel.getProperty("/Nmtl");
			oInputVolume = this.byId("__inputVolume");
			obj.supply = oInputVolume.getValue();
			ototalLoad = this.byId("totalLoad");
			//sap.m.MessageBox.alert("here"+ ototalLoad);
			obj.totalload = ototalLoad.getValue();
			oInputTemp = this.byId("avgTemp");
			obj.avgtemp = oInputTemp.getValue();
			obj.temp = oTemp.getSelectedKey();
			obj.avgloadest = obj.supply * obj.temp + obj.totalload * obj.avgtemp;
			var denom = obj.totalload * 1 + obj.supply * 1;
			obj.avgloadest = obj.avgloadest / denom;
			//inputArrival
			oInput = this.byId("inputArrival");
			obj.timetounload = oInput.getValue();
			obj.timetounload = obj.timetounload * 1;
			jQuery.sap.require("sap.ui.commons.MessageBox");
			/*
			  Create Log entry 
			  ----------------
			*/
			oInput = this.byId("__inputContactName");
			oEntry.ContactName = oInput.getValue();
			oInput = this.byId("__inputContactPhone");
			oEntry.ContactPhone = oInput.getValue();

			//oInput = this.byId("__inputCarrier");
			//oEntry.Carrier = oInput.getValue();
			var oCarrier = new sap.m.Select();
			oCarrier = this.byId("lioncarrier");
			oEntry.Carrier = oCarrier.getSelectedKey();

			oMultiInput = this.byId("__inputFarmer");
			oEntry.Farmer = oMultiInput.getTokens()[0].getKey();

			//oMultiInput = this.byId("__inputSite");
			//oEntry.ReceivingSite = oMultiInput.getTokens()[0].getKey();
			var oSite = new sap.m.Select();
			oSite = this.byId("site");
			oEntry.ReceivingSite = oSite.getSelectedKey();

			oInput = this.byId("__inputCRN");
			oEntry.Crn = oInput.getValue();
			oEntry.Event = oEvent.getSelectedKey();
			oEntry.Time = oTime.getSelectedKey();
			oEntry.Temperature = oTemp.getSelectedKey();
			oEntry.Nmtl = obj.value;
			oInput = this.byId("__inputVolume");
			oEntry.Supply = oInput.getValue();
			oEntry.Supply = oEntry.Supply;
			oInput = this.byId("totalLoad");
			oEntry.TotalLoad = oInput.getValue();
			oEntry.TotalLoad = oEntry.TotalLoad;
			oInput = this.byId("inputArrival");
			oEntry.TimeToUnload = oInput.getValue();
			oEntry.TimeToUnload = oEntry.TimeToUnload;
			oInput = this.byId("avgTemp");
			oEntry.EstTemp = oInput.getValue();
			oEntry.EstTemp = oEntry.EstTemp;

			oInput = this.byId("driverName");
			oEntry.DriverName = oInput.getValue();

			oInput = this.byId("driverPhone");
			oEntry.DriverPhone = oInput.getValue();

			oEntry.CreatedBy = sap.ui.getCore().getModel("userapi").getProperty("/name");

			//sap.m.MessageBox.alert("here"+sap.ui.getCore().getModel("userapi"));

			oModel.setHeaders({
				"X-Requested-With": "X"
			});
			oModel.create("ZMILK_COOLINGSet", oEntry, null, function() {}, function(oError) {
				sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
			});

			sap.ui.getCore().setModel(obj, "result");
			this.onReset();

			var page = new sap.m.Page();
			page = this.byId("Tempurature");
			page.scrollTo(0, 0);

			this.getRouter().navTo("final", {
				results: oODataJSONModel.getProperty("/Nmtl")
			});
		},
		/**
		 *@memberOf milkcooling.controller.main
		 */
		OnSiteChange: function(oEvent) {
			/*
				    Here we add the contact name and Phone number 
			*/

			//var userModel = new sap.ui.model.json.JSONModel("/services/userapi/attributesr");  			

			var oItem = new sap.ui.core.Item();
			var oSiteModel = new sap.ui.model.json.JSONModel();
			var oInput = new sap.m.Input();

			oItem = oEvent.getParameters().selectedItem;
			/* use the key to find the contact name/ contact number   */
			//	sap.m.MessageBox.alert("site:"+oItem.getKey());

			oSiteModel = sap.ui.getCore().getModel("oSiteModel");
			var sites = oSiteModel.getProperty("/results");

			oInput = this.byId("__inputContactName");
			oInput.setValue("");
			oInput = this.byId("__inputContactPhone");
			oInput.setValue("");
			//sap.m.MessageBox.confirm(oSiteModel.getJSON());
			// __inputContactName
			//__inputContactPhone
			for (var i = 0; i < sites.length; i++) {
				if (sites[i].Werks === oItem.getKey()) {
					oInput = this.byId("__inputContactName");
					oInput.setValue(sites[i].Contact_name);
					oInput = this.byId("__inputContactPhone");
					oInput.setValue(sites[i].Contact_phone);
					break;
				}
			}
		},
		OnCarrierChange: function(oEvent) {

		},

		afterInit: function(evt) {
			//var oCarrierModel = new sap.ui.model.json.JSONModel();
			//oCarrierModel = sap.ui.getCore().getModel("oCarrierModel");			
			//sap.m.MessageBox.alert("here"+oCarrierModel.getJSON());	
			this.onReset();
		}
	});
});