sap.ui.define(["sap/ui/core/mvc/Controller"], function (Controller) {
	"use strict";
	return Controller.extend("milkcooling.controller.initial", {
		
		getRouter : function () {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},
		goToHistory : function () { 
		 	this.getRouter().navTo("history",{},false);
		},
		goToCalculation : function () {
		 	this.getRouter().navTo("main",{},false);
		},
	/**
	*@memberOf milkcooling.controller.main
	*/
	onInit: function(){

	}



	});
});