sap.ui.define(["sap/ui/core/mvc/Controller"], function(Controller) {
	"use strict";
	return Controller.extend("milkcooling.controller.final", {
		getRouter: function() {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},
		onBack: function() {
			this.getRouter().navTo("main", {}, false /*no history*/ ); //this.getRouter().navTo("initial", {}, false	/*no history*/);
			// this.getOwnerComponent().getTargets().display("main");
		},
		/**
		 *@memberOf milkcooling.controller.main
		 */
		onInit: function() {
			var oRouter = this.getRouter();
			//oRouter.getRoute("final").attachPatternMatched(this._onObjectMatched, this);
			oRouter.getRoute("final").attachMatched(this._onRouteMatched, this); //this.getOwnerComponent().getTargets().attachMatched(this._onRouteMatched, this);
		},
		popup: function() {
			sap.m.MessageBox.alert("init");
		},
		_onRouteMatched: function(oEvent) {
			var oArgs, oView;
			var result = sap.ui.getCore().getModel("result");
			var oResult = new sap.m.Input();
			var oAvgLoadEst = new sap.m.Input();
			var oNmtlResult = new sap.ui.core.Icon();
			var oLoadEstResult = new sap.ui.core.Icon();
			var oFinalResult = new sap.m.Button();
			oArgs = oEvent.getParameter("arguments");
			oView = this.getView();
			//      jQuery.sap.require("sap.m.MessageBox");
			oResult = this.byId("result");
			oResult.setValue(result.value);
			oAvgLoadEst = this.byId("avgLoadEst");
			oAvgLoadEst.setValue(result.avgloadest);
			oLoadEstResult = this.byId("loadEstResult");
			oFinalResult = this.byId("finalResult");
			oFinalResult.setType("Accept");
			oFinalResult.setText("Collect Milk");
			// use result.avgloadest 
			if (result.avgloadest >= 6) {
				//	sap.m.MessageBox.alert("greater than 6");
				oLoadEstResult.setColor("red");
				oLoadEstResult.setSrc("sap-icon://decline");
			} else {
				oLoadEstResult.setColor("green");
				oLoadEstResult.setSrc("sap-icon://accept");
			}
			oNmtlResult = this.byId("nmtlResult");
			if (result.timetounload > result.value) {
				oNmtlResult.setColor("red");
				oNmtlResult.setSrc("sap-icon://decline");
			} else {
				oNmtlResult.setColor("green");
				oNmtlResult.setSrc("sap-icon://accept");
			}
			//finalResult
			if (result.avgloadest >= 6 && result.timetounload > result.value) {
				oFinalResult.setType("Reject");
				oFinalResult.setText("Reject Milk");
			}
			//
			oView.bindElement({
				path: "/results/" + oArgs.results
			});
		},
		onAfterRendering: function(oEvent) {
			//var oRouter = this.getRouter();
			//oRouter.getRoute("final").attachPatternMatched(this._onRouteMatched, this);
			//var result = sap.ui.getCore().getModel("result");
		},
		onPress: function(oEvent) {
			//sap.m.MessageBox.alert('result'+ this.getRouter().getRoute("final").getPattern());
			//sap.m.MessageBox.alert(oEvent.getParameter("arguments"));	
		},
		/**
		 *@memberOf milkcooling.controller.final
		 */
		onMainPress: function() {
			this.getRouter().navTo("initial", {}, false /*no history*/ );
		}
	});
});