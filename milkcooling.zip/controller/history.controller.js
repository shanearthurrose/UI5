sap.ui.define(["sap/ui/core/mvc/Controller"], function(Controller) {
	"use strict";
	return Controller.extend("milkcooling.controller.history", {
		getRouter: function() {
			return sap.ui.core.UIComponent.getRouterFor(this);
		},
		/**
		 *@memberOf milkcooling.controller.history
		 */
		onBack: function() {
			this.getRouter().navTo("initial");
		},
		onInit: function() {
				var oTable = new sap.m.Table();
				var oRefresh = new sap.m.PullToRefresh();
				oRefresh = this.byId("refresh");
				//var sServiceUrl = "/sap/opu/odata/sap/ZOGSM_SRV/";
				var sServiceUrl = "/destinations/milkCooling/sap/opu/odata/sap/ZOGSM_SRV/";
				//"ZMILK_COOLINGSet(Event='1',Time='0100',Temp=10.00m)";
				var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
				var oODataJSONModel = new sap.ui.model.json.JSONModel();
				sap.ui.getCore().setModel(oModel);
				oModel.read("ZMILK_COOLINGSet", null, null, false, function(oData, oResponse) {
					// create JSON model  
					oODataJSONModel.setData(oData);
				}, function(oError) {
					// create JSON model  
					jQuery.sap.require("sap.m.MessageBox");
					sap.m.MessageBox.show(oError);
				});
				oTable = this.byId("HistoryTable");
				oTable.setModel(oODataJSONModel);

				oRefresh.hide();

			}
			/**
			 *@memberOf milkcooling.controller.history
			 */
	});
});