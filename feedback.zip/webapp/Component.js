sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"FEEDBACK/model/models"
], function(UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("FEEDBACK.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			// call the base component's init function

			var that = this;

			UIComponent.prototype.init.apply(this, arguments);

			// set the device model
			this.setModel(models.createDeviceModel(), "device");

			this.getRouter().initialize();
			this.getRouter().navTo("initial", {}, false);

			var oModel = new sap.ui.model.json.JSONModel();
			var userModel = new sap.ui.model.json.JSONModel("/services/userapi/currentUser");
			userModel.loadData("/services/userapi/currentUser", null, false);

			this.setModel(userModel, "userInfo");
			this._getSummaryCount();
			this._getRequestCount();
			this._getSelfreflectionCount();

			this._getUser();

			//sap.ui.commons.MessageBox.alert(this.getModel("userInfo").getProperty("/name"));
			this._getUserDetails(this.getModel("userInfo").getProperty("/name"));

			//sap.ui.commons.MessageBox.alert(JSON.stringify(oBundle, null, 4));
			//sap.ui.commons.MessageBox.alert(this.getModel("i18n").getResourceBundle().getText("score0"));

		},

		_getLabel: function(name) {
			return this.getModel("i18n").getResourceBundle().getText(name);
		},

		_sendEmail: function(goal) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			///sap/opu/odata/SAP/ZLEADER_SRV_01/CATEGORIESSet
			var that = this;
			//sap.m.MessageBox.alert("here"+sap.ui.getCore().getModel("userapi"));
			var sServiceUrl = "/destinations/SAP";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false);
			var oRowsModel = new sap.ui.model.json.JSONModel();
			var oRequest = "/sap/opu/odata/sap/ZLEADER_SRV_01/EmailSet('" + goal + "')";

			oModel.setHeaders({
				"X-Requested-With": "X",
				"content-type": "application/json"
			});

			//sap.ui.commons.MessageBox.alert(oRequest);
			oModel.read(oRequest, null, null, false,
				function(oData, response) {
					// create JSON model  
					//sap.ui.commons.MessageBox.alert(JSON.stringify(oData, null, 4));
				},
				function(oError) {
					//sap.m.MessageToast.show("Error1");
				});

			this._getSelfreflectionCount();

		},

		_getCategories: function(categorytype) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			///sap/opu/odata/SAP/ZLEADER_SRV_01/CATEGORIESSet
			var that = this;
			//sap.m.MessageBox.alert("here"+sap.ui.getCore().getModel("userapi"));
			var sServiceUrl = "/destinations/SAP";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false);
			var oRowsModel = new sap.ui.model.json.JSONModel();
			var oRequest = "/sap/opu/odata/sap/ZLEADER_SRV_01/CATEGORIESSet?$filter=Type eq '" + categorytype + "'";
			var modelName = "categories" + categorytype;

			oModel.setHeaders({
				"X-Requested-With": "X",
				"content-type": "application/json"
			});

			//sap.ui.commons.MessageBox.alert(oRequest);
			oModel.read(oRequest, null, null, false,
				function(oData, response) {
					// create JSON model  

					oRowsModel.setData(oData);
					//that.setModel(oRowsModel, "categories");
					that.setModel(oRowsModel, modelName);
					//sap.ui.commons.MessageBox.alert(JSON.stringify(oData, null, 4));
				},
				function(oError) {
					//sap.m.MessageToast.show("Error1");
				});
		},

		_getUserDetails: function(email) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			///sap/opu/odata/SAP/ZLEADER_SRV_01/CATEGORIESSet
			var that = this;
			//sap.m.MessageBox.alert("here"+sap.ui.getCore().getModel("userapi"));
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false);
			var oRowsModel = new sap.ui.model.json.JSONModel();
			var oXMLModel = new sap.ui.model.xml.XMLModel();
			var modelName = "ldapuser";

			var name = email;
			name = name.replace("@lionco.com", "");
			name = name.replace(".", " ");
			//sap.m.MessageToast.show(name);

			var oRequest = "/rest/ldapCommon/service/ldapUser?username=" + name;

			//sap.ui.commons.MessageBox.alert(oRequest);
			oModel.read(oRequest, null, null, false,
				function(oData, response) {
					// create JSON model  
					oRowsModel.setData(response);
					var obody = oRowsModel.getProperty("/body");
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					oXMLModel.setXML(obody);
					//	oRowsModel.setData(oData);
					//that.setModel(oRowsModel, "categories");
					that.setModel(oXMLModel.getProperty("/resultsList/cn"), modelName);
					//sap.ui.commons.MessageBox.alert(JSON.stringify(oXMLModel.getXML(), null, 4));
					//sap.ui.commons.MessageBox.alert(oXMLModel.getProperty("/resultsList/cn"));
				},
				function(oError) {
					that.setModel(name, modelName);
					//	sap.m.MessageToast.show("Error1:" + email);
				});
		},

		_getSelfreflectionCount: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			//sap.m.MessageBox.alert("here"+sap.ui.getCore().getModel("userapi"));
			var sServiceUrl = "/destinations/SAP";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false);
			var oRowsModel = new sap.ui.model.json.JSONModel();
			var oRequest = "/sap/opu/odata/sap/ZLEADER_SRV_01/goalSet/$count?$filter=Owner eq '" +
				this.getModel("userInfo").getProperty("/name") +
				"' and Status ne 'C'";

			oModel.setHeaders({
				"X-Requested-With": "X",
				"content-type": "application/json"
			});
			that.setModel(oRowsModel, "selfreflectionNumber");

			//sap.ui.commons.MessageBox.alert(oRequest);
			oModel.read(oRequest, null, null, true,
				function(oData, response) {
					// create JSON model  

					oRowsModel.setData(response);
					var oCount = oRowsModel.getProperty("/body");
					that.setModel(oCount, "selfreflectionCount");
					that.setModel(oRowsModel, "selfreflectionNumber");
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oData, null, 4));					

				},
				function(oError) {
					//sap.m.MessageToast.show("Error1");
				});
		},
		_getSummaryCount: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			//sap.m.MessageBox.alert("here"+sap.ui.getCore().getModel("userapi"));
			var sServiceUrl = "/destinations/SAP";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false);
			var oRowsModel = new sap.ui.model.json.JSONModel();
			var oRequest = "/sap/opu/odata/sap/ZLEADER_SRV_01/summarySet/$count?$filter=Owner eq '" +
				this.getModel("userInfo").getProperty("/name") +
				"'";
			//sap.ui.commons.MessageBox.alert(oRequest);

			//var oTile = new sap.m.StandardTile();
			//oTile = view.byId("mysummary");
			//oTile.setBusy(true);

			oModel.setHeaders({
				"X-Requested-With": "X",
				"content-type": "application/json"
			});

			//sap.ui.commons.MessageBox.alert(oRequest);
			oModel.read(oRequest, null, null, false,
				function(oData, response) {
					// create JSON model  

					oRowsModel.setData(response);
					var oCount = oRowsModel.getProperty("/body");
					that.setModel(oCount, "summaryCount");
					//oTile.setBusy(false);
					//oTile.setNumber(oCount);
					//sap.m.MessageToast.show(oCount);

					//	sap.m.MessageToast.show("ok");
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oCount, null, 4));
				},
				function(oError) {
					//sap.m.MessageToast.show("Error1");
				});
		},

		_getRequestCount: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			//sap.m.MessageBox.alert("here"+sap.ui.getCore().getModel("userapi"));
			var sServiceUrl = "/destinations/SAP";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false);
			var oRowsModel = new sap.ui.model.json.JSONModel();
			var oRequest = "/sap/opu/odata/sap/ZLEADER_SRV_01/requesterSet/$count?$filter=Requester eq '" +
				this.getModel("userInfo").getProperty("/name") +
				"' and Status ne 'C'";
			//sap.ui.commons.MessageBox.alert(oRequest);

			//var oTile = new sap.m.StandardTile();
			//oTile = view.byId("mysummary");
			//oTile.setBusy(true);

			oModel.setHeaders({
				"X-Requested-With": "X",
				"content-type": "application/json"
			});

			that.setModel('0', "requestCount");
			that.setModel(oRowsModel, "requestNumber");
			//sap.ui.commons.MessageBox.alert(oRequest);
			oModel.read(oRequest, null, null, true,
				function(oData, response) {
					// create JSON model  

					oRowsModel.setData(response);
					var oCount = oRowsModel.getProperty("/body");

					//that.setModel(oCount, "requestCount");
					that.setModel(oCount, "requestCount");
					that.setModel(oRowsModel, "requestNumber");

					//oTile.setBusy(false);
					//oTile.setNumber(oCount);

					//	sap.m.MessageToast.show("ok");
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(response, null, 4));
				},
				function(oError) {
					//sap.m.MessageToast.show("Error1");
				});
		},
		_getmyReflection: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");

			var that = this;
			//sap.ui.commons.MessageBox.alert("here");
			//sap.m.MessageBox.alert("here"+sap.ui.getCore().getModel("userapi"));
			var sServiceUrl = "/destinations/SAP";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false);
			var oRowsModel = new sap.ui.model.json.JSONModel();
			var oRequest = "/sap/opu/odata/sap/ZLEADER_SRV_01/goalSet?$filter=Owner eq '" +
				this.getModel("userInfo").getProperty("/name") +
				"' and Status ne 'C'";
			//sap.ui.commons.MessageBox.alert(oRequest);

			oModel.setHeaders({
				"X-Requested-With": "X",
				"content-type": "application/json"
			});

			that.setModel(oRowsModel, "selfreflection");
			sap.ui.core.BusyIndicator.show();
			oModel.read(oRequest, null, null, true,
				function(oData) {
					// create JSON model  
					oRowsModel.setData(oData);
					that.setModel(oRowsModel, "selfreflection");
					sap.ui.core.BusyIndicator.hide();
					//	sap.m.MessageToast.show("ok");
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oData, null, 4));
				},
				function(oError) {
					sap.ui.core.BusyIndicator.hide();
					//sap.m.MessageToast.show("Error1");
				});

		},
		_getSummary: function(status) {
			jQuery.sap.require("sap.ui.commons.MessageBox");

			var that = this;
			//sap.ui.commons.MessageBox.alert("here");
			//sap.m.MessageBox.alert("here"+sap.ui.getCore().getModel("userapi"));
			var sServiceUrl = "/destinations/SAP";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false);
			var oRowsModel = new sap.ui.model.json.JSONModel();
			var oRequest = "/sap/opu/odata/sap/ZLEADER_SRV_01/summarySet?$filter=Owner eq '" +
				this.getModel("userInfo").getProperty("/name") +
				"' and Status eq '" + status + "'";
			//	"'";
			var oModelName = 'summary' + status;
			//sap.ui.commons.MessageBox.alert(oRequest);

			oModel.setHeaders({
				"X-Requested-With": "X",
				"content-type": "application/json"
			});
			sap.ui.core.BusyIndicator.show();
			oModel.read(oRequest, null, null, true,
				function(oData) {
					// create JSON model  
					oRowsModel.setData(oData);
					that.setModel(oRowsModel, oModelName);
					sap.ui.core.BusyIndicator.hide();
					//	sap.m.MessageToast.show("ok");
					//		sap.ui.commons.MessageBox.alert(JSON.stringify(oData, null, 4));
				},
				function(oError) {
					sap.ui.core.BusyIndicator.hide();
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
					//	sap.m.MessageToast.show("Error1");
				});

		},
		_getRequests: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");

			var that = this;
			//sap.ui.commons.MessageBox.alert("here");
			//sap.m.MessageBox.alert("here"+sap.ui.getCore().getModel("userapi"));
			var sServiceUrl = "/destinations/SAP";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false);
			var oRowsModel = new sap.ui.model.json.JSONModel();

			var oRequest = "/sap/opu/odata/sap/ZLEADER_SRV_01/requesterSet?$filter=Requester eq '" +
				this.getModel("userInfo").getProperty("/name") +
				"'";
			//sap.ui.commons.MessageBox.alert(oRequest);

			oModel.setHeaders({
				"X-Requested-With": "X",
				"content-type": "application/json"
			});

			that.setModel(oRowsModel, "requests");

			oModel.read(oRequest, null, null, true,
				function(oData) {
					// create JSON model  
					oRowsModel.setData(oData);
					that.setModel(oRowsModel, "requests");
					//	sap.m.MessageToast.show("ok");
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oData, null, 4));
				},
				function(oError) {
					//sap.m.MessageToast.show("Error1");
				});
		},

		_getUser: function() {

			jQuery.sap.require("sap.ui.commons.MessageBox");

			var that = this;
			//sap.ui.commons.MessageBox.alert("here");
			//sap.m.MessageBox.alert("here"+sap.ui.getCore().getModel("userapi"));
			var sServiceUrl = "/destinations/SAP";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false);
			var oRowsModel = new sap.ui.model.json.JSONModel();
			this.setModel(oRowsModel, "user");

			var oRequest = "/sap/opu/odata/sap/ZLEADER_SRV_01/User('" + this.getModel("userInfo").getProperty("/name") + "')";

			//sap.ui.commons.MessageBox.alert(oRequest);

			oModel.setHeaders({
				"X-Requested-With": "X",
				"content-type": "application/json"
			});

			oModel.read(oRequest, null, null, false,
				function(oData) {
					// create JSON model  
					oRowsModel.setData(oData);
					that.setModel(oRowsModel, "user");
					//	sap.m.MessageToast.show("ok");
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oData, null, 4));
				},
				function(oError) {
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
					//	sap.m.MessageToast.show("Error1");
				});

		},
		_getReflection: function(goal) {

			jQuery.sap.require("sap.ui.commons.MessageBox");

			var that = this;
			//sap.ui.commons.MessageBox.alert("here");
			//sap.m.MessageBox.alert("here"+sap.ui.getCore().getModel("userapi"));
			var sServiceUrl = "/destinations/SAP";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false);
			var oRowsModel = new sap.ui.model.json.JSONModel();
			this.setModel(oRowsModel, "reflectiondetail");

			//			var oRequest = "/sap/opu/odata/sap/ZLEADER_SRV_01/goalSet?$filter=Owner eq '" +
			//				this.getModel("userInfo").getProperty("/name") +
			//				"' and Status ne 'C'";

			var oRequest = "/sap/opu/odata/sap/ZLEADER_SRV_01/reflectionSet?$filter=Requester eq '" +
				this.getModel("userInfo").getProperty("/name") +
				"' and Goal eq '" + goal + "'";
			//sap.ui.commons.MessageBox.alert(oRequest);

			oModel.setHeaders({
				"X-Requested-With": "X",
				"content-type": "application/json"
			});

			oModel.read(oRequest, null, null, false,
				function(oData) {
					// create JSON model  
					oRowsModel.setData(oData);
					that.setModel(oRowsModel, "reflectiondetail");
					//	sap.m.MessageToast.show("ok");
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oData, null, 4));
				},
				function(oError) {
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
					//	sap.m.MessageToast.show("Error1");
				});

		},

		_getFeedback: function(goal) {

			jQuery.sap.require("sap.ui.commons.MessageBox");

			var that = this;
			//sap.ui.commons.MessageBox.alert("here");
			//sap.m.MessageBox.alert("here"+sap.ui.getCore().getModel("userapi"));
			var sServiceUrl = "/destinations/SAP";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false);
			var oRowsModel = new sap.ui.model.json.JSONModel();
			this.setModel(oRowsModel, "feedbackdetail");

			//			var oRequest = "/sap/opu/odata/sap/ZLEADER_SRV_01/goalSet?$filter=Owner eq '" +
			//				this.getModel("userInfo").getProperty("/name") +
			//				"' and Status ne 'C'";

			var oRequest = "/sap/opu/odata/sap/ZLEADER_SRV_01/reflectionSet?$filter=Requester ne '" +
				this.getModel("userInfo").getProperty("/name") +
				"' and Goal eq '" + goal + "'";
			//sap.ui.commons.MessageBox.alert(oRequest);

			oModel.setHeaders({
				"X-Requested-With": "X",
				"content-type": "application/json"
			});

			that.setModel(oRowsModel, "feedbackdetail");

			oModel.read(oRequest, null, null, true,
				function(oData) {
					// create JSON model  
					oRowsModel.setData(oData);
					that.setModel(oRowsModel, "feedbackdetail");
					//	sap.m.MessageToast.show("ok");
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oData, null, 4));
				},
				function(oError) {
					//sap.m.MessageToast.show("Error1");
				});

		},
		_getGoal: function(goal) {
			jQuery.sap.require("sap.ui.commons.MessageBox");

			var that = this;
			var oJSON = new sap.ui.model.json.JSONModel();
			//sap.ui.commons.MessageBox.alert("here");
			//sap.m.MessageBox.alert("here"+sap.ui.getCore().getModel("userapi"));
			var sServiceUrl = "/destinations/SAP";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false);
			var oRowsModel = new sap.ui.model.json.JSONModel();
			var oRequest = "/sap/opu/odata/sap/ZLEADER_SRV_01/goalSet(Goal='" + goal + "')";
			//sap.ui.commons.MessageBox.alert(oRequest);

			oModel.setHeaders({
				"X-Requested-With": "X",
				"content-type": "application/json"
			});

			oModel.read(oRequest, null, null, false,
				function(oData, response) {
					// create JSON model  
					oRowsModel.setData(oData);
					that.setModel(oRowsModel, "goal");

					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oData, null, 4));
					//sap.m.MessageToast.show("OK");
					//oJSON.setModel(oData);
					//that.setModel(oRowsModel, "goal");
					//sap.ui.commons.MessageBox.alert(JSON.stringify(oXML.getXML(), null, 4));
				},
				function(oError) {
					sap.m.MessageToast.show("error");
					//sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				});

		},

		_getCategory: function(categorytype, category) {
			jQuery.sap.require("sap.ui.commons.MessageBox");

			var that = this;
			var oJSON = new sap.ui.model.json.JSONModel();
			//sap.ui.commons.MessageBox.alert("here");
			//sap.m.MessageBox.alert("here"+sap.ui.getCore().getModel("userapi"));
			var sServiceUrl = "/destinations/SAP";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false);
			var oRowsModel = new sap.ui.model.json.JSONModel();
			var oRequest = "/sap/opu/odata/sap/ZLEADER_SRV_01/CATEGORIESSet(Type='" + categorytype + "',Category='" + category + "')";

			var modelName = 'category' + categorytype + category;

			//sap.ui.commons.MessageBox.alert(oRequest);

			oModel.setHeaders({
				"X-Requested-With": "X",
				"content-type": "application/json"
			});

			oModel.read(oRequest, null, null, false,
				function(oData, response) {
					// create JSON model  
					oRowsModel.setData(oData);
					//that.setModel(oRowsModel, "goal");
					that.setModel(oRowsModel, modelName);

					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oData, null, 4));
					//sap.m.MessageToast.show("OK");
					//oJSON.setModel(oData);
					//that.setModel(oRowsModel, "goal");
					//sap.ui.commons.MessageBox.alert(JSON.stringify(oXML.getXML(), null, 4));
				},
				function(oError) {
					sap.m.MessageToast.show("error");
					//sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				});

		},

		_getHistory: function(categorytype, workshop) {
			jQuery.sap.require("sap.ui.commons.MessageBox");

			var that = this;
			var oJSON = new sap.ui.model.json.JSONModel();
			//sap.ui.commons.MessageBox.alert("here");
			//sap.m.MessageBox.alert("here"+sap.ui.getCore().getModel("userapi"));
			var sServiceUrl = "/destinations/SAP";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false);
			var oRowsModel = new sap.ui.model.json.JSONModel();
			var oRequest = "/sap/opu/odata/sap/ZLEADER_SRV_01/historySet?$filter=type eq '" + categorytype + "' and workshop eq '" + workshop +
				"'";

			var modelName = 'history';

			//sap.ui.commons.MessageBox.alert(oRequest);

			oModel.setHeaders({
				"X-Requested-With": "X",
				"content-type": "application/json"
			});

			that.setModel(oRowsModel, modelName);

			oModel.read(oRequest, null, null, false,
				function(oData, response) {
					// create JSON model  
					oRowsModel.setData(oData);
					//that.setModel(oRowsModel, "goal");
					that.setModel(oRowsModel, modelName);

					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oData, null, 4));
					//sap.m.MessageToast.show("OK");
					//oJSON.setModel(oData);
					//that.setModel(oRowsModel, "goal");
					//sap.ui.commons.MessageBox.alert(JSON.stringify(oXML.getXML(), null, 4));
				},
				function(oError) {
					sap.m.MessageToast.show("error - refresh page");
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				});

		},

		/*
		 *  Create goal
		 */
		_createGoal: function() {
			var sServiceUrl = "/destinations/SAP/sap/opu/odata/sap/ZOGSM_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			var oODataJSONModel = new sap.ui.model.json.JSONModel();

			//var oGoal = {};

			var oGoal = this.getModel("goal");
			// sap.ui.getCore().setModel(oModel);			

			//oInput = this.byId("driverPhone");
			//oEntry.DriverPhone = oInput.getValue();

			//oGoal.Owner = sap.ui.getCore().getModel("userapi").getProperty("/name");

			//sap.m.MessageBox.alert("here"+sap.ui.getCore().getModel("userapi"));

			oModel.setHeaders({
				"X-Requested-With": "X"
			});
			oModel.create("goalSet", oGoal, null, function() {}, function(oError) {
				sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
			});
			this._getSelfreflectionCount();
		},
		/*
		 *  Create goal
		 */
		_createFeedback: function(goal, desc, rating, status) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var sServiceUrl = "/destinations/SAP";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			var oODataJSONModel = new sap.ui.model.json.JSONModel();

			var oFeedback = {};
			oFeedback.Goal = goal;
			//oFeedback.Requester = sap.ui.getCore().getModel("userapi").getProperty("/name");
			oFeedback.Requester = this.getModel("userInfo").getProperty("/name");
			oFeedback.Description = desc;
			oFeedback.Rating = rating;
			oFeedback.Status = status;
			//sap.m.MessageBox.alert("here");

			oModel.setHeaders({
				"X-Requested-With": "X"
			});
			oModel.create("/sap/opu/odata/sap/ZLEADER_SRV_01/feedbackSet", oFeedback, null,
				function() {
					sap.m.MessageToast.show("success");
				},
				function(oError) {
					//sap.m.MessageBox.alert(JSON.stringify(oError, null, 4));
					//	sap.m.MessageToast.show("fail:");
				});
			this._getRequestCount();

		},

		/*
		 *  Create goal
		 */
		_declineFeedback: function(goal, desc) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var sServiceUrl = "/destinations/SAP";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			var oODataJSONModel = new sap.ui.model.json.JSONModel();

			var oFeedback = {};
			oFeedback.Goal = goal;
			//oFeedback.Requester = sap.ui.getCore().getModel("userapi").getProperty("/name");
			oFeedback.Requester = this.getModel("userInfo").getProperty("/name");
			oFeedback.Description = desc;
			oFeedback.Status = 'R'; //Rejected
			//sap.m.MessageBox.alert("here");

			oModel.setHeaders({
				"X-Requested-With": "X"
			});
			oModel.create("/sap/opu/odata/sap/ZLEADER_SRV_01/feedbackSet", oFeedback, null,
				function() {
					sap.m.MessageToast.show("success");
				},
				function(oError) {
					//sap.m.MessageBox.alert(JSON.stringify(oError, null, 4));
					//	sap.m.MessageToast.show("fail:");
				});
			this._getRequestCount();

		},

		_sliderMessage: function(value) {
			var message;
			var inValue = parseInt(value);

			if (inValue === 0) {
				message = this._getLabel("score0");
			} else if (inValue === 1) {
				message = this._getLabel("score20");
			} else if (inValue === 2) {
				message = this._getLabel("score40");
			} else if (inValue === 3) {
				message = this._getLabel("score60");
			} else if (inValue === 4) {
				message = this._getLabel("score80");
			} else if (inValue === 5) {
				message = this._getLabel("score100");
			}

			//sap.m.MessageToast.show(message);
			return message;
		}
	});

});