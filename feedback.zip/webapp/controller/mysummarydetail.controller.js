sap.ui.define(["sap/ui/core/mvc/Controller", "sap/ui/model/Filter"], function(Controller) {
	"use strict";

	return Controller.extend("FEEDBACK.controller.mysummarydetail", {
		/**
		 *@memberOf FEEDBACK.controller.mygoal
		 */
		onInit: function() {
			//that.setModel(oRowsModel, "goal");
			this.getView().setModel(this.getOwnerComponent().getModel("goal"),"goal");
			this.getView().setModel(this.getOwnerComponent().getModel("reflectiondetail"),"reflectiondetail");
			this.getView().setModel(this.getOwnerComponent().getModel("feedbackdetail"),"feedbackdetail");			
		},
		onBeforeRendering: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			this.getView().setModel(this.getOwnerComponent().getModel("goal"),"goal");
			this.getView().setModel(this.getOwnerComponent().getModel("reflectiondetail"),"reflectiondetail");
			this.getView().setModel(this.getOwnerComponent().getModel("feedbackdetail"),"feedbackdetail");						
			this.getView().setVisible(true);
		},

		onBack: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			this.getView().setVisible(false);
			this.getOwnerComponent().getRouter().navTo("mysummary", {}, false);
		},
		
		onHome: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			this.getView().setVisible(false);
			this.getOwnerComponent().getRouter().navTo("initial", {}, false);
		},
		
		formatRating: function(rating) {
		//	sap.m.MessageToast.show("rating:" + rating);
			if (rating === '' || rating === null) rating = 0;

			return parseInt(rating);
		},
		formatRatingWords: function(rating) {
			//sap.m.MessageToast.show("rating:" + rating);
			
			return 	this.getOwnerComponent()._sliderMessage(parseInt(rating));
//			var message;
		},
		
		formatDate: function(value) {
			//return value;
			if ( value === null ) return value;
			
			sap.m.MessageToast.show("value:"+value);
			var date = new Date(value);
			var dd = date.getDate();
			var mm = date.getMonth() + 1;
			if (mm < 10) {
				mm = '0' + mm;
			}
			var yyyy = date.getFullYear();
//			var yyyy = value[0] + value[1] + value[2] + value[3] ;
//			var mm = value[4] + value[5];
//			var dd = value[6] + value[7];
			//var date = new Date(yyyy,mm,dd);
			//var date = dd + '/' + mm + '/' + yyyy;
			
			return  ( dd + "/" + mm + "/" + yyyy );
		}		
	});
});