sap.ui.define(["sap/ui/core/mvc/Controller"], function(Controller) {
	"use strict";
	return Controller.extend("FEEDBACK.controller.myfeedback", {
		/**
		 *@memberOf FEEDBACK.controller.mygoal
		 */
		onInit: function() {

			this.getOwnerComponent()._getRequests();
			this.getView().setModel(this.getOwnerComponent().getModel("requests"), "requests");
		},

		onBeforeRendering: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			//	sap.ui.commons.MessageBox.alert("here");
			//	this.byId("myrating").setValue(0);
			//	this.byId("feedback").setValue();
			this.getView().setVisible(true);

			this.getOwnerComponent()._getRequests();
			this.getView().setModel(this.getOwnerComponent().getModel("requests"), "requests");
			//			this.getView().getModel("requests").refresh(true);

		},
		/*
		 * when user selects line
		 */
		onDetailPress: function(oEvent) {

			/*
			 * when user selects line
			 */
			jQuery.sap.require("sap.ui.commons.MessageBox");
			//	this.getView().setVisible(false);
			//sap.m.MessageToast.show("Goal#:" + oEvent.getSource().getParent().getParent().getTitle());
			this.getOwnerComponent()._getGoal(oEvent.getSource().data("goal"));
			//sap.m.MessageToast.show("Incident to be closed:" + oEvent.getSource().data("goal"));

			//this.getView().setVisible(false);
			this.getOwnerComponent().getRouter().navTo("myfeedbackdetail", {}, false);

			//sap.m.MessageToast.show("Incident to be closed:" + oEvent.getSource().getParent().getParent().getTitle());
			//this.getOwnerComponent().getRouter().navTo("myfeedbackdetail", {}, false);

		},

		onRefresh: function() {
			var oRefresh = new sap.m.PullToRefresh();
			this.getOwnerComponent()._getRequests();
			this.getView().setModel(this.getOwnerComponent().getModel("requests"), "requests");			
			oRefresh = this.byId("refresh");
			oRefresh.hide();
		},
		/*
		 * user selects to go back to previous page
		 */
		onBack: function() {
			this.getView().setVisible(false);
			this.getOwnerComponent()._getRequestCount();			
			this.getOwnerComponent().getRouter().navTo("initial", {}, false);
		}
	});
});