sap.ui.define(["sap/ui/core/mvc/Controller"], function(Controller) {
	"use strict";
	return Controller.extend("FEEDBACK.controller.analytics", {

		oVizFrame: null,

		onInit: function() {
			var ovizFrame = this.oVizFrame = this.byId("idVizFrame");
			ovizFrame.setVizProperties({
				title: {
					alignment: "left",
					visible: true,
					text: 'Behaviours'
				}
			});


			this.getOwnerComponent()._getCategories('3'); //LION workshop
			this.getView().setModel(this.getOwnerComponent().getModel("categories3"), "categories3");
			this.getOwnerComponent()._getHistory("1","1");
			//	this.getView().setModel(this.getOwnerComponent().getModel("history"));
			//sap.m.MessageToast.show("workshop:"+this.byId("workshop").getSelectedKey());

		},
		onBeforeRendering: function() {
			this.getView().setVisible(true);
			//this.getOwnerComponent()._getHistory("1");
			this.oVizFrame.setModel(this.getOwnerComponent().getModel("history"));
			//this.getView().setModel(this.getOwnerComponent().getModel("history"));
		},

		onChange: function(oEvent){

			var oType = this.byId("datasetRadioGroup").getSelectedIndex() + 1;
			//sap.m.MessageToast.show("change:"+this.byId("workshop").getSelectedKey()+oType);			
			this.getOwnerComponent()._getHistory(oType.toString(),this.byId("workshop").getSelectedKey());
			this.oVizFrame.setModel(this.getOwnerComponent().getModel("history"));
		},

		onDatasetSelected: function(oEvent) {

			if (!oEvent.getParameters().selected) {
				return;
			}
			var datasetRadio = oEvent.getSource();
			//sap.m.MessageToast.show("got it");
			if (this.oVizFrame && datasetRadio.getSelected()) {
				//var bindValue = datasetRadio.getBindingContext().getObject();
				if (datasetRadio.getText()[0] === 'B') {
					this.getOwnerComponent()._getHistory("1",this.byId("workshop").getSelectedKey());
					this.oVizFrame.setVizProperties({
						title: {
							alignment: "left",
							visible: true,
							text: 'Behaviours'
						}
					});
				} else {
					this.getOwnerComponent()._getHistory("2",this.byId("workshop").getSelectedKey());
					this.oVizFrame.setVizProperties({
						title: {
							alignment: "left",
							visible: true,
							text: 'Circle of Change'
						}
					});
				}
				this.oVizFrame.setModel(this.getOwnerComponent().getModel("history"));
			}
		},

		onBack: function() {
			this.getView().setVisible(false);
			this.getOwnerComponent().getRouter().navTo("initial", {}, false);
		}
	});
});