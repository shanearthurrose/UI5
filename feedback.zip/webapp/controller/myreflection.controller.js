sap.ui.define(["sap/ui/core/mvc/Controller"], function(Controller) {
	"use strict";
	return Controller.extend("FEEDBACK.controller.myreflection", {
		/**
		 *@memberOf FEEDBACK.controller.mygoal
		 */
		onInit: function() {
		//	this.getOwnerComponent()._getmyReflection();
		//	this.getView().setModel(this.getOwnerComponent().getModel("selfreflection"), "selfreflection");
		},

		onBeforeRendering: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			this.getView().setVisible(true);
			//sap.m.MessageToast.show("Self reflection");
			this.getOwnerComponent()._getmyReflection();
			this.getView().setModel(this.getOwnerComponent().getModel("selfreflection"), "selfreflection");
		},
		/*
		 * when user selects line
		 */
		onDetailPress: function(oEvent) {
			//this.getView().setVisible(false);
			this.getOwnerComponent()._getGoal(oEvent.getSource().data("goal"));
			this.getOwnerComponent().getRouter().navTo("myselfreflectiondetail", {}, false);
		},

		/*
		 * user selects to go back to previous page
		 */
		onBack: function() {
			this.getView().setVisible(false);
			this.getOwnerComponent().getRouter().navTo("initial", {}, false);
		}
	});
});