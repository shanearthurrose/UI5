sap.ui.define(["sap/ui/core/mvc/Controller"], function(Controller) {
	"use strict";
	return Controller.extend("FEEDBACK.controller.main", {
		onInit: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			//	sap.ui.commons.MessageBox.alert("here");			
			//this.getOwnerComponent()._getSummaryCount();
			//	this.getOwnerComponent()._getRequestCount();
			//	this.getView().setModel(this.getOwnerComponent().getModel("requestNumber"), "requestNumber");
			//	this.getView().setModel(this.getOwnerComponent().getModel("selfreflectionNumber"), "selfreflectionNumber");
			//	sap.ui.commons.MessageBox.alert('admin:'+ this.getOwnerComponent().getModel("user").getProperty("/admin"));

		},
		onBeforeRendering: function() {
			this.getView().setModel(this.getOwnerComponent().getModel("requestNumber"), "requestNumber");
			this.getView().setModel(this.getOwnerComponent().getModel("selfreflectionNumber"), "selfreflectionNumber");

			this.byId("mychart").setVisible(false);
			if (this.getOwnerComponent().getModel("user").getProperty("/Admin") === "X") {
				this.byId("mychart").setVisible(true);
			}
		},
		
		onMyGoalPress: function() {
			this.getOwnerComponent().getRouter().navTo("mygoal", {}, false); //this.getView().setVisible(false);
		},
		//onMyFeedbackPress
		onMyFeedbackPress: function() {
			//this.getView().setVisible(true);
			this.getOwnerComponent().getRouter().navTo("myfeedback", {}, false);
		},
		onMyReflection: function() {
			//this.getView().setVisible(true);
			this.getOwnerComponent()._getmyReflection();
			this.getOwnerComponent().getRouter().navTo("myreflection", {}, false);
		},
		onAnalyticsPress: function() {
			//this.getView().setVisible(true);
			this.getOwnerComponent().getRouter().navTo("analytics", {}, false);
		},
		//onMySUmmaryPress
		onMySummaryPress: function() {
			//	this.getView().setModel(this.getOwnerComponent().getModel("summaryCount"));
			//this.getView().setVisible(true);
			this.getOwnerComponent().getRouter().navTo("mysummary", {}, false);
		},
		
		//sap.m.URLHelper.triggerEmail(person.website, "Info", "Dear " + person.name + ",");
		onAppFeedback: function() {
			sap.m.URLHelper.triggerEmail("learning@lionco.com", "iCommit App Feedback", null);
		},		
		
		/**
		 *@memberOf FEEDBACK.controller.main
		 */
		onRefresh: function() {

			var oRefresh = new sap.m.PullToRefresh();
			oRefresh = this.byId("refresh");
			//var sServiceUrl = "/sap/opu/odata/sap/ZOGSM_SRV/";
			//this.getOwnerComponent()._getSummaryCount();
			this.getOwnerComponent()._getSelfreflectionCount();
			this.getOwnerComponent()._getRequestCount();

			//this.byId("mysummary").setNumber(this.getOwnerComponent().getModel("summaryCount"));
			//this.byId("myfeedback").setNumber(this.getOwnerComponent().getModel("requestCount"));
			//this.byId("myreflection").setNumber(this.getOwnerComponent().getModel("selfreflectionCount"));			
			oRefresh.hide();
		}
	});
});