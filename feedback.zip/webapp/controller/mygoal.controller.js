sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter"
], function(Controller) {
	"use strict";
	return Controller.extend("FEEDBACK.controller.mygoal", {
		/**
		 *@memberOf FEEDBACK.controller.mygoal
		 */
		onInit: function() {
			this.aKeys = [
				"mail",
				"cn"
			];
			this.theTokenInput = this.getView().byId("request"); //this.theTokenInput.setEnableMultiLineMode(sap.ui.Device.system.phone);
			this.getOwnerComponent()._getCategories('1');  //LION Behaviours
			this.getView().setModel(this.getOwnerComponent().getModel("categories1"), "categories1");
			this.getOwnerComponent()._getCategories('2');  //LION Circle of Change
			this.getView().setModel(this.getOwnerComponent().getModel("categories2"), "categories2");
			this.getOwnerComponent()._getCategories('3');  //LION workshop
			this.getView().setModel(this.getOwnerComponent().getModel("categories3"), "categories3");
			
			
		},

		onBeforeRendering: function() {
			this._clearField("goal");
			this._clearMultiField("request");
			this.byId("status").setValue(this.getOwnerComponent()._getLabel("score0"));
			this.byId("rating").setValue(0);
			this.byId("behaviour").setValue("");
			this.byId("circleofchange").setValue("");			
			this.byId("ldap").setValue("");			
			
			//this.byId("ratingimage").setSrc("./images/F.png");
			this.getView().setVisible(true);

			
			//this.getOwnerComponent()._getUserDetails("Shane.Rose@lionco.com");
			//sap.m.MessageToast.show(this.getOwnerComponent().getModel("ldapuser"));

		},


		onAccept: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");

			var oGoal = {};
			oGoal.Owner = this.getOwnerComponent().getModel("userInfo").getProperty("/name");
			oGoal.Ownername = this.getOwnerComponent().getModel("ldapuser");
			//displayName
			oGoal.Description = this.byId("goal").getValue();
			//oGoal.Category = this.byId("category").getSelectedItem().getKey();
			oGoal.Behaviour = this.byId("behaviour").getSelectedKey();
			oGoal.Circleofchange = this.byId("circleofchange").getSelectedKey();			
			oGoal.Workshop = this.byId("workshop").getSelectedKey();
			
			oGoal.Frequency = this.byId("frequency").getSelectedKey();
			//sap.m.MessageToast.show(oGoal.Owner);

			oGoal.Rating = this.byId("rating").getValue().toString();
			sap.m.MessageToast.show(oGoal.Rating);

			if (!this._validateGoal()) {
				sap.m.MessageToast.show(this.getOwnerComponent()._getLabel("error01"));
			} else {
				//sap.m.MessageBox.alert("here"+this.byId("rating").getValue());
				//sap.ui.core.BusyIndicator.show();
				var sServiceUrl = "/destinations/SAP";
				var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false);
				oModel.setHeaders({
					"X-Requested-With": "X"
				});
				oModel.create("/sap/opu/odata/sap/ZLEADER_SRV_01/goalSet", oGoal, null,
					function(oData, response) {
						oGoal.Goal = oData.Goal;
						sap.m.MessageToast.show("Goal Created: " + oData.Goal); //sap.ui.commons.MessageBox.alert(oData.Goal);
					},
					function(oError) {
						sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
					});
				/*
				 *  Now add the requesters....
				 */
				var requesters = new sap.m.MultiInput();
				requesters = this.byId("request");
				var tokens = [];
				tokens = requesters.getTokens();
				/*
				 *  loop over each requester - use email address
				 */
				$.each(tokens, function(index, value) {
					var oRequest = {};
					var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false);
					oRequest.Requester = value.getKey();
					oRequest.Requestername = value.getText();
					oRequest.Goal = oGoal.Goal;
					oRequest.Status = 'N';
					
					oModel.setHeaders({
						"X-Requested-With": "X"
					});
					oModel.create("/sap/opu/odata/sap/ZLEADER_SRV_01/requesterSet", oRequest, null, function(oData, response) {
						//sap.m.MessageToast.show("Goal Created: " + oData.Goal);
						//	sap.ui.commons.MessageBox.alert(oData.Goal);
					}, function(oError) {
						//sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
					});

				});
				/*
				  Now trigger an Email in SAP to all
				*/

				this.getOwnerComponent()._sendEmail(oGoal.Goal);
				//sap.m.MessageToast.show("Email Sent for Goal:" + oData.Goal);
				this.getView().setVisible(false);

				//this._getSelfreflectionCount();

				this.onBack();

				//this.getOwnerComponent().getRouter().navTo("initial", {}, false);
			}

		},
		onReset: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			sap.ui.commons.MessageBox.alert("reset");
		},
		handleSelectUser: function(oEvent) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl);
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var oXMLModel = new sap.ui.model.xml.XMLModel();
			var showBusy = false;
			//var user = this.byId("request").getValue();
			var user = this.byId("ldap").getValue();
			this.byId("ldap").setValue("");		
			
			if ( user === ""){
				sap.m.MessageToast.show("Please Enter Start of Name");
				//sap.ui.commons.MessageBox.alert("Please Enter Start of Name");
			    return;
			}
			
			this.byId("request").setValue();
			//	sap.ui.commons.MessageBox.alert(user);

			//			if (!this._oDialog) {
			oModel.read("/rest/ldapCommon/service/ldapUser?username=" + user, //					"/rest/ldapCommon/service/ldapUser?username=Sh",
				null, null, true,
				function(oData, oResponse) {
					// create JSON model  
					oDataJSONModel.setData(oResponse);
					var obody = oDataJSONModel.getProperty("/body");
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					oXMLModel.setXML(obody);
					//that._oDialog.setBusy(false);
					sap.ui.core.BusyIndicator.hide(); //	sap.ui.commons.MessageBox.alert(JSON.stringify(oXMLModel.getXML(), null, 4));
				},
				function(oError) {
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
					sap.ui.core.BusyIndicator.hide();
				});
			showBusy = true;

			if (!this._oDialog) {
				//this._oDialog.setBusy(true);
				this._oDialog = sap.ui.xmlfragment("FEEDBACK.view.userSelect", this);
				//this._oDialog.setModel(this.getView().getModel());
				this._oDialog.setModel(oXMLModel);
				showBusy = true;
			}
			this._oDialog.setModel(oXMLModel);			
			this._oDialog.getBinding("items").filter([]);
			// toggle compact style
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog);
			this._oDialog.open();
			//sap.ui.commons.MessageBox.alert(oRowsModel.getJSON());
			// set busy indicator
			if (showBusy) {
				sap.ui.core.BusyIndicator.show();
			} //sap.ui.commons.MessageBox.alert(oRowsModel.getJSON());
		},
		handleUserSearch: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilterName = new sap.ui.model.Filter("cn", sap.ui.model.FilterOperator.Contains, sValue);
			var oFilterEmail = new sap.ui.model.Filter("mail", sap.ui.model.FilterOperator.Contains, sValue);
			var oFilter = new sap.ui.model.Filter({
				filters: [
					oFilterName,
					oFilterEmail
				],
				and: false
			});
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		},
		handleUserClose: function(oEvent) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			var token = new sap.m.Token();
			var aContexts = oEvent.getParameter("selectedContexts");
			//console.log(JSON.stringify(aContexts.getModel(), null, 4));
			token.setKey(aContexts.map(function(oContext) {
				//return oContext.getObject("cn");
				return oContext.getModel().getProperty(oContext.getPath() + "/mail");
			}));
			token.setText(aContexts.map(function(oContext) {
				return oContext.getModel().getProperty(oContext.getPath() + "/cn"); //return oContext.getObject("mail");
			}));
			if (aContexts && aContexts.length) {
				//sap.m.MessageToast.show("You have chosen " + aContexts.map(function(oContext) { return oContext.getModel().getProperty(oContext.getPath()+"/mail"); }).join(", "));
				//that.theTokenInput.setTokens([token]);
				that.theTokenInput.addToken(token);
			}
			oEvent.getSource().getBinding("items").filter([]);
		},
		onBack: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			this.getView().setVisible(false);
			this.getOwnerComponent().getRouter().navTo("initial", {}, false);
		},
		/**
		 *@memberOf FEEDBACK.controller.mygoal
		 */
		onRatingChange: function() {
			//This code was generated by the layout editor.

			jQuery.sap.require("sap.ui.commons.MessageBox");
			//	sap.m.MessageToast.show("Changed ");
		},
		/**
		 *@memberOf FEEDBACK.controller.mygoal
		 */
		onLiveSliderChange: function(oControlEvent) {
			
			var message;
			var image;
			message = this.getOwnerComponent()._sliderMessage(oControlEvent.getParameter("value"));
			this.byId("status").setValue(message);
		//	this.byId("ratingimage").setSrc("./images/" + image);
			sap.m.MessageToast.show(message);
		},

		_validateGoal: function() {
			var valid = true;

			if (!this._validateField("goal")) valid = false;
			if (!this._validateMultiField("request")) valid = false;
			if (!this._validateDropdownField("behaviour")) valid = false;			
			if (!this._validateDropdownField("circleofchange")) valid = false;			

			return valid;
		},
		_validateMultiField: function(field) {
			jQuery.sap.require("sap.m.MessageBox");
			var oInput = new sap.m.MultiInput();
			oInput = this.byId(field);
			var fValue = oInput.getTokens();
			//	sap.m.MessageBox.alert("ok:"+fValue.length);
			if (fValue.length === 0) {
				oInput.setValueState(sap.ui.core.ValueState.Error);
				return false;
			} else {
				oInput.setValueState(sap.ui.core.ValueState.None);
			}
			return true;
		},
		
		_validateDropdownField: function(field) {
			jQuery.sap.require("sap.m.MessageBox");
			var oInput = this.byId(field);
			var fValue = oInput.getSelectedKey();
			//	sap.m.MessageBox.alert("ok:"+fValue.length);
			if (fValue.length === 0) {
				oInput.setValueState(sap.ui.core.ValueState.Error);
				return false;
			} else {
				oInput.setValueState(sap.ui.core.ValueState.None);
			}
			return true;
		},		

		_validateField: function(field) {
			//var oInput = new sap.m.Input();
			var oInput = this.byId(field);
			if (oInput.getVisible()) {
				if (oInput.getValue() === "") {
					oInput.setValueState(sap.ui.core.ValueState.Error);
					return false;
				} else {
					oInput.setValueState(sap.ui.core.ValueState.None);
				}
			}
			return true;
		},

		_clearField: function(field) {
			this.byId(field).setValue();

		},

		_clearMultiField: function(field) {
			this.byId(field).setTokens([]);
		}

	});
});