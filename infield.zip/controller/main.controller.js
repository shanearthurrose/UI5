sap.ui.define(["sap/ui/core/mvc/Controller"], function(Controller) {
	"use strict";
	return Controller.extend("infield.controller.main", {
		onInit: function() {
			//this.getOwnerComponent()._getCalls();
			jQuery.sap.require("sap.ui.commons.MessageBox");
			/*

			<TileContainer id="container" tiles="{MAIN>/RESULT}" 


			*/
			/*
			var sampleXML = "<root>" +
				"<result>" +
				"<Description>test</Description>" +
				"</result>" +
				"<result>" +
				"<Description>test</Description>" +
				"</result>" +
				"</root>";
			var oXMLModel = new sap.ui.model.xml.XMLModel();
			oXMLModel.setXML(sampleXML);
*/
			this.getView().setModel(this.getOwnerComponent().getModel("day0"), "day0");
			this.getView().setModel(this.getOwnerComponent().getModel("day1"), "day1");
			this.getView().setModel(this.getOwnerComponent().getModel("day2"), "day2");
			this.getView().setModel(this.getOwnerComponent().getModel("day3"), "day3");
			this.getView().setModel(this.getOwnerComponent().getModel("day4"), "day4");
			//	this.getView().setModel(this.getOwnerComponent().getModel("day5"), "day5");
			//	this.getView().setModel(this.getOwnerComponent().getModel("day6"), "day6");

			//var oXMLModel = new sap.ui.model.xml.XMLModel();
			//oXMLModel.setXML(sampleXML);
		},

		onBeforeRendering: function() {
			this.getOwnerComponent()._setTitles(this, null);
		},
		/**
		 *@memberOf infield.controller.main
		 */
		onPrevious: function() {
			this.getOwnerComponent()._setTitles(this, "-");
			//sap.ui.commons.MessageBox.alert("Date:" + this.getOwnerComponent().getModel("CURRENTDATE"));
		},
		/**
		 *@memberOf infield.controller.main
		 */
		onNext: function() {
			this.getOwnerComponent()._setTitles(this, "+");
			//sap.ui.commons.MessageBox.alert("Date:" + this.getOwnerComponent().getModel("CURRENTDATE"));
		},
		onListItemPress: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			//_getTickets: function(view, field, successPage) {
			//sap.ui.commons.MessageBox.alert("press");
			this.getOwnerComponent().getRouter().navTo("plan", {}, false);
			//	this.getOwnerComponent()._getTickets(this,"myopencalls","mycalls");
		}
	});
});