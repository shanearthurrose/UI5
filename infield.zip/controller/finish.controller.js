sap.ui.define(["sap/ui/core/mvc/Controller"], function(Controller) {
	"use strict";
	return Controller.extend("infield.controller.finish", {
		onInit: function() {
			var state = [{
				state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
				value: 10
			}, {
				state: sap.suite.ui.commons.ProcessFlowNodeState.Negative,
				value: 20
			}, {
				state: sap.suite.ui.commons.ProcessFlowNodeState.Neutral,
				value: 30
			}, {
				state: sap.suite.ui.commons.ProcessFlowNodeState.Planned,
				value: 40
			}];
			var oDataProcessFlowLanesOnly = {
				lanes: [{
					id: "0",
					icon: "sap-icon://order-status",
					label: "Plan",
					position: 0
				}, {
					id: "1",
					icon: "sap-icon://monitor-payments",
					label: "Sell",
					position: 1
				}, {
					id: "2",
					icon: "sap-icon://payment-approval",
					label: "Do",
					position: 2
				}, {
					id: "3",
					icon: "sap-icon://money-bills",
					label: "Finish",
					position: 3,
					state: [{
						state: sap.suite.ui.commons.ProcessFlowNodeState.Positive,
						value: 10
					}]
				}]
			};
			var oModelPf2 = new sap.ui.model.json.JSONModel();
			var viewPf2 = this.getView();
			oModelPf2.setData(oDataProcessFlowLanesOnly);
			viewPf2.setModel(oModelPf2, "pf2");
			viewPf2.byId("processflow2").updateModel();
		},
		/**
		 *@memberOf infield.controller.plan
		 */

		
		onBack: function() {
			this.getOwnerComponent().getRouter().navTo("do", {}, false);
		}		
	});
});