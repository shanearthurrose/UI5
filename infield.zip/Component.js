sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"infield/model/models"
], function(UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("infield.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			this.getRouter().initialize();
			this.getRouter().navTo("main", {}, false);

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			var date = new Date();
			this.setModel(date, "CURRENTDATE");
		},

		_getCalls: function(view, day, dd, mm, yyyy) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			//	sap.ui.commons.MessageBox.alert("day:"+dd+"month:"+mm+"year:"+yyyy);
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var that = this;
			var oDataJSONModel = new sap.ui.model.json.JSONModel();

			var list = view.byId("idlistDetail" + day);
			list.setBusy(true);
			this.setModel(null, "day" + day);
			var startDay = dd;
			var endDay = parseInt(dd, 10) + 1;

			//var startDay = 18;
			//var endDay = 19;
			var query = "/rest/commonSiebelWebservice/service/callInbound?startDate=" +
				yyyy + "-" + mm + "-" + startDay +
				"&endDate=" +
				yyyy + "-" + mm + "-" + endDay + "&owner=1-41PUCU9";
			//sap.ui.commons.MessageBox.alert(JSON.stringify(query, null, 4));
			//var oXML = new sap.ui.model.xml.XMLModel();
			//that.setModel(oXML, "day" + day);
			that.setModel(this._setDummyXML(), "day" + day);

			oModel.read(
				query,
				null, null, true,
				function(oData, response) {
					// create JSON model  
					oDataJSONModel.setData(response);
					var obody = oDataJSONModel.getProperty("/body");
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					var oXML = new sap.ui.model.xml.XMLModel();


					oXML.setXML(obody);
					if (oXML.getProperty("/xsdLocal1:ListOfLnCallsInbound/xsdLocal1:InStoreVisit") !== ""){
						that.setModel(oXML, "day" + day);
					}	

					list.setBusy(false);

					
				},
				function(oError) {
					list.setBusy(false);
					sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
					//sap.ui.commons.MessageBox.alert("Session timeout - please refresh");
				});
		},

		_setTitles: function(view, operation) {
			jQuery.sap.require("sap.ui.commons.MessageBox");

			var weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
			var monthNames = ["January", "February", "March", "April", "May", "June",
				"July", "August", "September", "October", "November", "December"
			];

			var date = this.getModel("CURRENTDATE");
			var day = date.getDay(),
				diff = date.getDate() - day + (day == 0 ? -6 : 1); // adjust when day is sunday
			Date(date.setDate(diff));
			//sap.ui.commons.MessageBox.alert("Date:" + date);
			this.setModel(null, "CURRENTDATE");

			if (operation === "-") {
				var newDate = new Date(date.setDate(date.getDate() - 7));
			} else if (operation === "+") {
				var newDate = new Date(date.setDate(date.getDate() + 7));
			} else {
				var newDate = new Date(date.setDate(date.getDate()));
			}

			for (var i = 0; i < 5; i++) {
				var fieldId = "day" + i + "Title";
				var NotificationListGroup = view.byId(fieldId);
				//sap.ui.commons.MessageBox.alert("field:" + weekdays[date.getDay()] + " " + date.getDate() + '-' + monthNames[date.getMonth()]);
				NotificationListGroup.setTitle(weekdays[date.getDay()] + " " + date.getDate() + '-' + monthNames[date.getMonth()]);
				//this._setDummyXML(i, date.getDate(), date.getMonth() + 1, date.getUTCFullYear());				
				this._getCalls(view, i, (view, "0" + date.getDate()).slice(-2), ("0" + (date.getMonth() + 1)).slice(-2), date.getUTCFullYear());
				//this._setDummyXML(i, date.getDate(), date.getMonth() + 1, date.getUTCFullYear());
				date.setDate(date.getDate() + 1);
			}
			this.setModel(newDate, "CURRENTDATE");
			//sap.ui.commons.MessageBox.alert(JSON.stringify(newDate, null, 4));
		},

		_setDummyXML: function(day, dd, mm, yyyy) {
			var oXML = '<?xml version="1.0"?>' +
				'<tns:LN_spcCalls_spcInbound_spcWorkflow_Output>' +
				'<xsdLocal1:ListOfLnCallsInbound>' +
				'<xsdLocal1:InStoreVisit>' +
				'</xsdLocal1:InStoreVisit>' +
				'</xsdLocal1:ListOfLnCallsInbound>' +
				'</tns:LN_spcCalls_spcInbound_spcWorkflow_Output>';
			var XML = new sap.ui.model.xml.XMLModel();
			XML.setXML(oXML);
			//sap.ui.commons.MessageBox.alert("day"+XML.getXML());
			//this.setModel(XML, "day" + day);
			return XML;
		}
	});

});