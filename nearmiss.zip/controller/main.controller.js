sap.ui.define(["sap/ui/core/mvc/Controller"], function(Controller) {
	"use strict";
	return Controller.extend("nearmiss.controller.main", {
		capturePhoto: function() {
			var that = this;
			var oNav = navigator.camera;
			oNav.getPicture(function cameraSuccess(imageUri) {
				var myImage = that.byId("myImage");
				myImage.setSrc("data:image/jpeg;base64," + imageUri);
			}, function onFail(error) {}, {
				quality: 20,
				destinationType: oNav.DestinationType.DATA_URL
			});
			this.getPosition();
		},
		/*
		 *  initial - prior to page load
		 */
		onInit: function() {
			/* @todo
			
		 
				<Input width="50%" id="reportedby" placeholder="Enter"/>
			
			  1. when report type eq SAFETY (this should be default)
			    significant incident is visible
			    (Hasrd code values to the 3)
			   		<Select selectedKey=" " id="reporttype" width="" icon="sap-icon://temperature" items="{reporttype>/getRecord}" change="onReportTypeChange">
							<sap.ui.core:ListItem text="{reporttype>fieldValue}" key="{reporttype>idValue}"/>
					</Select>
					
									<Select selectedKey="Safety" id="reporttype" width="" icon="sap-icon://temperature" change="onReportTypeChange">
										<sap.ui.core:ListItem text="Safety" key="Safety"/>
										<sap.ui.core:ListItem text="Quality" key="Quality"/>
										<sap.ui.core:ListItem text="Environment" key="Environment"/>
									</Select>					

			    
			    Category source will change based on report type
			    a. SafetyIncident_NeaMissCategoryObject (safety report type)
			    b. EnviIncidentV6_EReportCategoryObject  (enviro report type)
				c. QualiIncidentV6_QualityCat1Object(quality)
			
			2. New Sub Category field ONLY when report type is Quality
			    a. values are from  QualiIncidentV6_QualityCat2Object(quality)
			
			3. Does this relate to a capitol works only when SAFETY
			
			4. Project Name only when Safety
			
			5. when does this relate to capitol works project is NO, hide project name field
			
			6. move location fields under Location section
			
			
			*/
			jQuery.sap.require("sap.ui.commons.MessageBox");
			this.theTokenInput = this.getView().byId("location");
			this.theTokenInputid = this.getView().byId("locationid");
			//this.theTokenInput.setEnableMultiLineMode(sap.ui.Device.system.phone);
			/*
			  set reported by
			*/
			//var oReportedBy = new sap.m.Input();
			//oReportedBy = this.byId("reportedby");

			this.setDropDown("category", "SafetyIncident_NeaMissCategoryObject", "Caption", true);

			this.setDropDown("reporttype", "CAPAV6_SystemTypeObject", "Caption", true);
			//this.setDropDown("location", "SysLocationEntity", "Name");
			this.setDropDown("projectname", "SafetyIncident_CapitalProjectsObject", "Caption", true);

			this.byId("subcategory").setVisible(false);
			this.byId("_labelsubcategory").setVisible(false);
			this.byId("significant").setVisible(true);
			this.byId("_labelsignificant").setVisible(true);
			this.byId("capital").setVisible(true);
			this.byId("__labelcapitalworks").setVisible(true);
			this.byId("projectname").setVisible(false);
			this.byId("__labelprojectname").setVisible(false); //	oReportedBy.setValue(this.getOwnerComponent().getModel("userInfo").getProperty("/displayName"));
			/*
												<Label text="Location" width="100%" id="__labellocation" required="true"/>
												<Input width="100%" id="location" showValueHelp="true" valueHelpRequest="handleLocationPress" fieldWidth="80%" value="{fieldValue}"
													valueHelpOnly="true" change="onLocationChange"/>
												<sap.ui.core:InvisibleText id="locationid"/>
												<Label text="Department" width="100%" id="__labeldepartment" required="true"/>
												<Select id="department" width="" change="onDepartmentChange" items="{department>/getRecordsByFilter}">
													<sap.ui.core:ListItem text="{department>fieldValue}" key="{department>idValue}"/>
												</Select>
												<Label text="Area" width="100%" id="__labelarea" required="true"/>
												<Select id="area" width="" items="{area>/getRecordsByFilter}">
													<sap.ui.core:ListItem text="{area>fieldValue}" key="{area>idValue}"/>
												</Select>			
			*/
			this.byId("location").setVisible(false);
			this.byId("__labellocation").setVisible(false);
			this.byId("department").setVisible(false);
			this.byId("__labeldepartment").setVisible(false);
			this.byId("area").setVisible(false);
			this.byId("__labelarea").setVisible(false);

			this.byId("__labelexp").setVisible(false);
			this.byId("notcontrolled").setVisible(false);

		},
		onBeforeRendering: function() {
			//var oReportedBy = new sap.m.Input();
			//oReportedBy = this.byId("reportedby");
			//oReportedBy.setValue(this.getOwnerComponent().getModel("userInfo").getProperty("/displayName"));

			var today = new Date();
			var dd = today.getDate();
			var MM = today.getMonth() + 1;
			if (MM < 10) {
				MM = '0' + MM;
			}
			var yyyy = today.getFullYear();

			var hh = today.getHours();
			var mm = today.getMinutes();
			var ss = today.getSeconds();

			this.setDropDownFilter("reportedby", "SysEmployeeEntity", "FullName", "Email", this.getOwnerComponent().getModel("userInfo").getProperty(
				"/displayName"), "", "", true);

			//	this.byId("date").setValue(dd + '.' + MM + '.' + yyyy);
			this.byId("date").setDateValue(new Date());
			this.byId("time").setDateValue(new Date());
			//this.byId("time").setValue(hh + ':' + mm + ':' + ss);
		},
		onAfterRendering: function() {
			//this.onReportTypeChange();
			this.setDropDownFilter("reportedby", "SysEmployeeEntity", "FullName", "Email", this.getOwnerComponent().getModel("userInfo").getProperty(
				"/displayName"), "", "", true);
			//sap.ui.commons.MessageBox.alert("after: " + this.getOwnerComponent().getModel("userInfo").getProperty("/displayName"));				
		},
		/**
		 *@memberOf nearmiss.controller.main
		 */
		onLocationChange: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var oLocationInput = new sap.m.Input();
			oLocationInput = this.byId("location");
			var oDepartmentSelect = new sap.ui.commons.ComboBox();
			oDepartmentSelect = this.byId("department");
			oDepartmentSelect.removeAllItems();
			this.setDropDownFilter("department", "hciMastIncdntv6_IMDepartmentObject", "DepartmentName", "location", oLocationInput.getValue(),
				"", "", false);
			var items = oDepartmentSelect.getItems();
			//	sap.ui.commons.MessageBox.alert(oDepartmentSelect = this.byId("department").getValue());
			//	this.onDepartmentChange();	
			this.setDropDownFilter("area", "FragApplication_SubDepartmentObject", "SDepartmentName", "department", items[0].getText(),
				"location", oLocationInput.getValue(), false); //this.onDepartmentChange();
		},
		/*
		  when the Department changes 
		*/
		onDepartmentChange: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			//sap.ui.commons.MessageBox.alert(JSON.stringify(oLocationSelect.getSelectedItem()
			//	.getText(), null, 4));
			var oLocationInput = new sap.m.Input();
			oLocationInput = this.byId("location");
			var oDepartmentSelect = new sap.ui.commons.ComboBox();
			oDepartmentSelect = this.byId("department");
			//sap.ui.commons.MessageBox.alert("change:"+oDepartmentSelect.getValue());
			this.setDropDownFilter("area", "FragApplication_SubDepartmentObject", "SDepartmentName", "department", oDepartmentSelect.getValue(),
				"location", oLocationInput.getValue(), false);
		},
		/*
		 *
		 * Set drop down values (coming from Sequis database Via WebMethods)
		 *
		 */
		setDropDown: function(field, systemname, fieldname, async) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			this.byId(field).setBusy(true);
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			oModel.read("/rest/commonIntelex/restIntelex/getRecords?systemName=" + systemname + "&Field=" + fieldname, //				"/odata/commonIntelex.odata:ointelex/getRecords?$filter=systemName eq '" + systemname + "' and field eq '" + fieldname + "'",
				null, null, async,
				function(oData, oResponse) {
					// create JSON model  
					oDataJSONModel.setData(oResponse);
					var obody = oDataJSONModel.getProperty("/body");
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					var oXMLModel = new sap.ui.model.xml.XMLModel();
					oXMLModel.setXML(obody);
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oXMLModel.getXML(), null, 4));
					that.getView().setModel(oXMLModel, field);
					that.byId(field).setBusy(false);
				},
				function(oError) {
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
					that.byId(field).setBusy(false); //sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				});
		},
		/*
		 *
		 * Set drop down values (coming from Sequis database Via WebMethods)
		 *
		 */
		setDropDownFilter: function(field, systemname, fieldname, filterName1, filterValue1, filterName2, filterValue2, async) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			if (async) {
				this.byId(field).setBusy(true);
			}
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var query = "/rest/commonIntelex/restIntelex/getRecordsByFilter?systemName=" + systemname + "&Field=" + fieldname + "&filterName=" +
				filterName1 + "&filterValue=" + filterValue1;
			// + "&filterName=" + filterName2 + "&filterValue=" + filterValue2,;
			if (filterName2 !== "") {
				query += "&filterName=" + filterName2 + "&filterValue=" + filterValue2;
			}
			//	sap.ui.commons.MessageBox.alert(query);
			//var oSelect = new sap.m.Select();
			//var oItem = new sap.ui.core.Item();
			//oSelect = this.byId(field);
			oModel.read(query, null, null, async,
				function(oData, oResponse) {
					oDataJSONModel.setData(oResponse);
					var obody = oDataJSONModel.getProperty("/body");
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					var oXMLModel = new sap.ui.model.xml.XMLModel();
					oXMLModel.setXML(obody);
					//	sap.ui.commons.MessageBox.alert(field+JSON.stringify(oXMLModel.getXML(), null, 4));
					//	sap.ui.commons.MessageBox.alert(oXMLModel.getProperty("/getRecordsByFilter/idValue"));
					that.getView().setModel(oXMLModel, field);
					if (async) {
						that.byId(field).setBusy(false);
					}
				},
				function(oError) {
					if (async) {
						that.byId(field).setBusy(false);
					}
					//		sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				});
		},
		onSubmit: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			jQuery.sap.require("sap.m.MessageToast");
			var that = this;
			var returnguid;
			var sServiceUrl = "/destinations/WebMethods";

			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			oModel.setHeaders({
				"X-Requested-With": "X"
			});

			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var oXMLModel = new sap.ui.model.xml.XMLModel();
			var oRecord = {};
			var nameVal = [];

			var guid = "fe9a2075-a839-4880-a4ea-f46497282751";
			var systemName = "SafetyIncident_SafetyIncidentObject";
			var objectId = "925b9271-8c18-4825-8f75-16819d23384f";

			sap.m.MessageToast.show(this.byId("reporttype").getValue());

			if (this.byId("reporttype").getValue() === "Quality") {
				systemName = "QualiIncidentV6_QualityIncidentObject";
				nameVal = this._setQualityRecord();
				objectId = "5b6f1879-8bcf-4101-b777-dc858c24ca93";
			} else if (this.byId("reporttype").getValue() === "Environment") {
				systemName = "EnviIncidentsV6_EnviroIncidentsObject";
				nameVal = this._setEnviroRecord();
				objectId = "d32a309b-a082-4737-bd81-fca1b6f5719e";
			} else {
				nameVal = this._setSafetyRecord();
			}

			if (!this._validateDate()) {
				sap.m.MessageToast.show("Date/Time cannot be in the future");
			} else if (this._validateForm()) {

				oRecord.nameVal = nameVal;
				//oRecord.systemName = "SafetyIncident_SafetyIncidentObject"; // for safety
				oRecord.systemName = systemName; // for safety				

				sap.m.MessageToast.show("About to save Recorded");
				//sap.ui.core.BusyIndicator.show();
				/*
				  Use: CreateBatch
				*/
				//var batchChanges = []; 
				var query = "/rest/commonIntelex/restIntelex/dataManagerServices";
				//batchChanges.push( oModel.createBatchOperation(query,"POST", oRecord));

				oModel.create(query, oRecord, null,
					function(oData, oResult) {
						//sap.ui.commons.MessageBox.alert(JSON.stringify(oResult, null, 4));
						oDataJSONModel.setData(oResult);
						var obody = oDataJSONModel.getProperty("/body");
						//
						//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
						//
						oXMLModel.setXML(obody);
						//sap.ui.commons.MessageBox.alert("guid:"+oXMLModel.getProperty("/"));
						that.getView().setModel(oXMLModel.getProperty("/"), "guid");
						returnguid = oXMLModel.getProperty("/");

						//	var objectId = "925b9271-8c18-4825-8f75-16819d23384f";

						if (that.byId("myImage").getSrc() !== null && that.byId("myImage").getSrc() !== '') {
							//sap.ui.commons.MessageBox.alert("srce:" + this.byId("myImage").getSrc());
							that._uploadImage("incident.jpg", returnguid, objectId, that.byId("myImage").getSrc());
						}

						that.setDropDownFilter("workflow", systemName, "Workflow.CurrentStageId", "id", returnguid, "", "",
							false);

						that.setDropDownFilter("nextworkflow", "SysWorkflowStageActionEntity", "",
							"stageId", that.getView().getModel("workflow").getProperty("/getRecordsByFilter/fieldValue"), "", "", false);

						that._issueWorkflow(systemName, that.getView().getModel("nextworkflow").getProperty(
							"/getRecordsByFilter/idValue"), returnguid);

						sap.ui.core.BusyIndicator.hide();

						sap.ui.commons.MessageBox.alert("Near Miss Successfully Submitted:");
						sap.m.MessageToast.show("Incident Success Recorded");
					},
					function(oError) {
						sap.ui.core.BusyIndicator.hide();
						sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
					}, true);
			}

		},
		onSubmit2: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			jQuery.sap.require("sap.m.MessageToast");
			//sap.m.MessageToast.show("start");
			var that = this;
			var returnguid;
			var sServiceUrl = "/destinations/WebMethods";

			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			oModel.setHeaders({
				"X-Requested-With": "X"
			});

			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var oXMLModel = new sap.ui.model.xml.XMLModel();
			var oRecord = {};
			var nameVal = [];

			var guid = "fe9a2075-a839-4880-a4ea-f46497282751";
			var systemName = "SafetyIncident_SafetyIncidentObject";
			var objectId = "925b9271-8c18-4825-8f75-16819d23384f";

			if (this.byId("reporttype").getValue() === "Quality") {
				systemName = "QualiIncidentV6_QualityIncidentObject";
				nameVal = this._setQualityRecord();
				objectId = "5b6f1879-8bcf-4101-b777-dc858c24ca93";
			} else if (this.byId("reporttype").getValue() === "Environment") {
				systemName = "EnviIncidentsV6_EnviroIncidentsObject";
				nameVal = this._setEnviroRecord();
				objectId = "d32a309b-a082-4737-bd81-fca1b6f5719e";
			} else {

				nameVal = this._setSafetyRecord();
			}

			if (!this._validateDate()) {
				sap.m.MessageToast.show("Date/Time cannot be in the future");
			} else if (this._validateForm()) {

				oRecord.nameVal = nameVal;
				//oRecord.systemName = "SafetyIncident_SafetyIncidentObject"; // for safety
				oRecord.systemName = systemName; // for safety				

				//sap.m.MessageToast.show("About to save Recorded");
				this._createNearMiss(oRecord, objectId, systemName);
				/*
				  Use: CreateBatch
				*/

			}

		},

		_createNearMiss: function(oRecord, objectId, systemName) {
			jQuery.sap.require("sap.ui.core.BusyIndicator");

			var that = this;
			var returnguid;
			var sServiceUrl = "/destinations/WebMethods";
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var oXMLModel = new sap.ui.model.xml.XMLModel();
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			oModel.setHeaders({
				"X-Requested-With": "X"
			});
			sap.ui.core.BusyIndicator.show();

			jQuery.sap.delayedCall(3000, this, function() {
				var query = "/rest/commonIntelex/restIntelex/dataManagerServices";
				oModel.create(query, oRecord, null,
					function(oData, oResult) {
						//	sap.ui.commons.MessageBox.alert(JSON.stringify(oResult, null, 4));
						oDataJSONModel.setData(oResult);
						var obody = oDataJSONModel.getProperty("/body");
						//
						//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
						//
						oXMLModel.setXML(obody);
						//sap.ui.commons.MessageBox.alert("guid:"+oXMLModel.getProperty("/"));
						that.getView().setModel(oXMLModel.getProperty("/"), "guid");
						returnguid = oXMLModel.getProperty("/");

						//	var objectId = "925b9271-8c18-4825-8f75-16819d23384f";

						if (that.byId("myImage").getSrc() !== null && that.byId("myImage").getSrc() !== '') {
							//sap.ui.commons.MessageBox.alert("srce:" + this.byId("myImage").getSrc());
							that._uploadImage("incident.jpg", returnguid, objectId, that.byId("myImage").getSrc());
						}

					//	sap.m.MessageToast.show("before work flow");
						that.setDropDownFilter("workflow", systemName, "Workflow.CurrentStageId", "id", returnguid, "", "",
							false);

						that.setDropDownFilter("nextworkflow", "SysWorkflowStageActionEntity", "",
							"stageId", that.getView().getModel("workflow").getProperty("/getRecordsByFilter/fieldValue"), "", "", false);

						that._issueWorkflow(systemName, that.getView().getModel("nextworkflow").getProperty(
							"/getRecordsByFilter/idValue"), returnguid);
							
						sap.ui.core.BusyIndicator.hide();

						sap.ui.commons.MessageBox.alert("Near Miss Successfully Submitted:");
						sap.m.MessageToast.show("Incident Success Recorded");
					},
					function(oError) {
						sap.ui.core.BusyIndicator.hide();
						//	sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
					}, true);
			});

		},
/*

*/
		_setInterlexField: function(record, field, value, id) {
			if (!id === null && !id === "") {
				if (this.byId(id).getVisible()) {
					record[record.length] = this._addField(field, value);
				}
			} else {
				record[record.length] = this._addField(field, value);
			}
		},
		/*
		   add field for Save 
		*/
		_addField: function(field, value) {
			var name = {};
			name.name = field;
			name.value = value;
			return name;
		},
		/*
		 * handle search for location field
		 *
		 */
		handleLocationPress: function(oEvent) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false, null, null, {
				"Content-Type": "application/xml; charset=utf-8"
			});
			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var oXMLModel = new sap.ui.model.xml.XMLModel();
			var showBusy = false;
			if (!this._oDialog) {
				oModel.read( //			"/odata/commonIntelex.odata:ointelex/getRecords?$filter=systemName eq 'SysLocationEntity' and field eq 'Name'",
					"/rest/commonIntelex/restIntelex/getRecords?systemName=SysLocationEntity&Field=Name", null, null, true,
					function(oData, oResponse) {
						// create JSON model  
						oDataJSONModel.setData(oResponse);
						var obody = oDataJSONModel.getProperty("/body");
						//
						//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
						//
						oXMLModel.setXML(obody);
						sap.ui.core.BusyIndicator.hide();
					},
					function(oError) {
						//	sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
					});
				this._oDialog = sap.ui.xmlfragment("nearmiss.view.locationSelect", this);
				//this._oDialog.setModel(this.getView().getModel());
				this._oDialog.setModel(oXMLModel);
				showBusy = true;
			}
			// clear the old search filter
			this._oDialog.getBinding("items").filter([]);
			// toggle compact style
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog);
			this._oDialog.open();
			//sap.ui.commons.MessageBox.alert(oRowsModel.getJSON());
			// set busy indicator
			if (showBusy) {
				sap.ui.core.BusyIndicator.show();
			}
		},
		handleLocationSearch: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			var oFilterName = new sap.ui.model.Filter("fieldValue", sap.ui.model.FilterOperator.Contains, sValue);
			var oFilter = new sap.ui.model.Filter({
				filters: [oFilterName],
				and: false
			});
			var oBinding = oEvent.getSource().getBinding("items");
			oBinding.filter([oFilter]);
		},
		handleLocationClose: function(oEvent) {
			var that = this;
			var aContexts = oEvent.getParameter("selectedContexts");
			if (aContexts && aContexts.length) {
				that.theTokenInput.setValue(aContexts.map(function(oContext) {
					//return oContext.getObject().fieldValue;
					return oContext.getModel().getProperty(oContext.getPath() + "/fieldValue");
				}));
				that.theTokenInputid.setText(aContexts.map(function(oContext) {
					//return oContext.getObject().fieldValue;
					return oContext.getModel().getProperty(oContext.getPath() + "/idValue");
				}));
				that.onLocationChange();
			}
			oEvent.getSource().getBinding("items").filter([]);
		},
		/**
		 *@memberOf nearmiss.controller.main
		 */
		onReportTypeChange: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			/*
				<Label text="Significant Incident?" id="_labelsignificant" required="true"/>
				<Switch id="significant" customTextOff="Yes" customTextOn="No" state="true"/>
				
				<Label text="Category" id="_labelsubcategory" required="true"/>
				<Select selectedKey=" " id="subcategory" width="" items="{subcategory>/getRecord}">
					<sap.ui.core:ListItem text="{subcategory>fieldValue}" key="{subcategory>idValue}"/>
				</Select>	
									
				<Label text="Does this relate to a Capitol Works Project?" id="__labelcapitalworks" required="true" fieldGroupIds="contactName"/>
				<Switch id="__switchcapitol" customTextOff="Yes" customTextOn="No" state="true"/>
				<Label text="Project Name" id="__labelprojectname" required="true"/>
				<Select id="projectname" width="" items="{projectname>/getRecord}">
					<sap.ui.core:ListItem text="{projectname>fieldValue}" key="{projectname>idValue}"/>
				</Select>									
			*/
			this.byId("significant").setVisible(false);
			this.byId("_labelsignificant").setVisible(false);
			this.byId("subcategory").setVisible(false);
			this.byId("_labelsubcategory").setVisible(false);
			this.byId("capital").setVisible(false);
			this.byId("__labelcapitalworks").setVisible(false);
			this.byId("projectname").setVisible(false);
			this.byId("__labelprojectname").setVisible(false);
			this.byId("__labelexp").setVisible(false);
			this.byId("notcontrolled").setVisible(false);

			if (this.byId("reporttype").getValue() === "Safety") {
				this.byId("significant").setVisible(true);
				this.byId("_labelsignificant").setVisible(true);
				this.byId("capital").setVisible(true);
				this.byId("__labelcapitalworks").setVisible(true);
				this.byId("projectname").setVisible(true);
				this.byId("__labelprojectname").setVisible(true);
				this.setDropDown("category", "SafetyIncident_NeaMissCategoryObject", "Caption");
			} else if (this.byId("reporttype").getValue() === "Environment") {
				this.setDropDown("category", "EnviIncidentsV6_EReportCategoryObject", "Caption");
				if (this.byId("controlled").getState()) {
					this.byId("__labelexp").setVisible(true);
					this.byId("notcontrolled").setVisible(true);
				}
			} else if (this.byId("reporttype").getValue() === "Quality") {
				this.byId("subcategory").setVisible(true);
				this.byId("_labelsubcategory").setVisible(true);
				this.setDropDown("category", "QualiIncidentV6_QualityCat1Object", "Caption"); //this.setDropDown("subcategory", "QualiIncidentV6_QualityCat2Object", "Caption");
				this.onCategoryChange();
			}
			this.onCapitonWorksChange();

		},
		/**
		 *@memberOf nearmiss.controller.main
		 */
		getPhoto: function() {
			var that = this;
			var oNav = navigator.camera;
			oNav.getPicture(function onPhotoURISuccess(imageURI) {
				var myImage = that.byId("myImage");
				myImage.setSrc(imageURI);
			}, function onFail(error) {}, {
				quality: 20,
				destinationType: oNav.DestinationType.FILE_URI,
				sourceType: oNav.PictureSourceType.PHOTOLIBRARY
			});
		},
		onMismatch: function(e) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			sap.ui.commons.MessageBox.alert("mismatch");
		},
		onExceed: function(e) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			sap.ui.commons.MessageBox.alert("file name exceed");
		},
		onSizeExceed: function(e) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			sap.ui.commons.MessageBox.alert("size exceed");
		},
		onChangeFUP: function(e) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var output = this.byId("myImage");;
			this._import(e.getParameter("files") && e.getParameter("files")[0]); //this.byId("fileupload").attachChange("onChangeFUP");
		},
		_import: function(file) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			//	sap.ui.commons.MessageBox.alert("ok");
			//	sap.ui.commons.MessageBox.alert("here" + file);
			if (file) {
				var reader = new FileReader();
				//	var reader = new FileReader();
				reader.onload = function() {
					var dataURL = reader.result;
					var output = that.byId("myImage");
					output.setSrc(dataURL);
				};
				reader.readAsDataURL(file);
			}
		},
		/**
		 *@memberOf nearmiss.controller.main
		 */
		onClearImage: function() {
			//This code was generated by the layout editor.
			var output = this.byId("myImage");
			output.setSrc();
		},
		/*
		  validate form
		*/
		_validateForm: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			//this._validateField("reportedby");
			var valid = true;

			if (!this._validateField("describeincident")) valid = false;
			if (!this._validateField("immediateaction")) valid = false;
			//			//	this._validateField("subcategory");
			if (this.byId("location").getVisible())
				if (!this._validateField("location")) valid = false;
			if (!this._validateField("exactlocation")) valid = false;
			if (!this._validateField("date")) valid = false;
			if (!this._validateField("time")) valid = false;

			// Calculate the difference in milliseconds
			//return true;
			return valid;

		},
		_validateDate: function() {
			var valid = true;
			var dd = this.byId("date").getValue()[6] + this.byId("date").getValue()[7];
			var MM = (this.byId("date").getValue()[4] + this.byId("date").getValue()[5]);
			MM = parseInt(MM) - 1;

			var yyyy = this.byId("date").getValue()[0] + this.byId("date").getValue()[1] +
				this.byId("date").getValue()[2] + this.byId("date").getValue()[3];

			var hh = this.byId("time").getValue()[0] + this.byId("time").getValue()[1];
			var mm = this.byId("time").getValue()[3] + this.byId("time").getValue()[4];
			var DateTime;
			DateTime = new Date(yyyy, MM, dd, hh, mm, 0);
			var today = new Date();

			var DateTime_ms = DateTime.getTime();
			var today_ms = today.getTime();
			if (DateTime_ms > today_ms) {
				this.byId("date").setValueState(sap.ui.core.ValueState.Error);
				this.byId("time").setValueState(sap.ui.core.ValueState.Error);
				valid = false;
			}

			return valid;
		},
		/*
		   validate field
		*/
		_validateField: function(field) {
			var oInput = new sap.m.Input();
			oInput = this.byId(field);
			if (oInput.getVisible()) {
				if (oInput.getValue() === "") {
					oInput.setValueState(sap.ui.core.ValueState.Error);
					return false;
				} else {
					oInput.setValueState(sap.ui.core.ValueState.None);
				}
			}
			return true;
		},
		/**
		 *@memberOf nearmiss.controller.main
		 */
		onCategoryChange: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var oCategorySelect = new sap.m.Select();
			oCategorySelect = this.byId("category");
			var osubcategorySelect = new sap.m.Select();
			osubcategorySelect = this.byId("subcategory");
			if (osubcategorySelect.getVisible()) {
				this.setDropDownFilter("subcategory", "QualiIncidentV6_QualityCat2Object", "QualitCategory2", "QualityCat1", oCategorySelect.getValue(),
					"", "", false);
			}
		},
		/**
		 *@memberOf nearmiss.controller.main
		 */
		onCapitonWorksChange: function() {
			//This code was generated by the layout editor.
			this.byId("projectname").setVisible(false);
			this.byId("__labelprojectname").setVisible(false);

			if (!this.byId("capital").getState() &&
				this.byId("capital").getVisible()) {
				this.byId("projectname").setVisible(true);
				this.byId("__labelprojectname").setVisible(true);
			}
		},

		onSiteChange: function() {
			//This code was generated by the layout editor.
			this.byId("location").setVisible(false);
			this.byId("__labellocation").setVisible(false);
			this.byId("department").setVisible(false);
			this.byId("__labeldepartment").setVisible(false);
			this.byId("area").setVisible(false);
			this.byId("__labelarea").setVisible(false);

			if (!this.byId("onsite").getState()) {
				this.byId("location").setVisible(true);
				this.byId("__labellocation").setVisible(true);
				this.byId("department").setVisible(true);
				this.byId("__labeldepartment").setVisible(true);
				this.byId("area").setVisible(true);
				this.byId("__labelarea").setVisible(true);
			}
		},

		onControlChange: function() {
			//This code was generated by the layout editor.
			this.byId("__labelexp").setVisible(false);
			this.byId("notcontrolled").setVisible(false);
			if (this.byId("reporttype").getValue() === "Environment") {
				if (this.byId("controlled").getState()) {
					this.byId("__labelexp").setVisible(true);
					this.byId("notcontrolled").setVisible(true);
				}
			}
		},

		_issueWorkflow: function(SystemName, actionId, guid) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			oModel.setHeaders({
				"X-Requested-With": "X"
			});

			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var oXMLModel = new sap.ui.model.xml.XMLModel();
			var oRecord = {};

			oRecord.systemName = SystemName;
			oRecord.actionId = actionId;
			oRecord.guid = guid;
			//sap.ui.commons.MessageBox.alert("workFlow");

			var query = "/rest/commonIntelex/restIntelex/workflowService";
			oModel.create(query, oRecord, null,
				function(oData, oResult) {
					//sap.ui.commons.MessageBox.alert(JSON.stringify(oResult, null, 4));
					oDataJSONModel.setData(oResult);
					var obody = oDataJSONModel.getProperty("/body");
					//sap.ui.commons.MessageBox.alert(JSON.stringify(oResult, null, 4));
					//
					//  the message is in JSON format - but the body value has been escaped hence we get the body result in XML
					//
					//oXMLModel.setXML(obody);
					//sap.ui.commons.MessageBox.alert("guid:"+oXMLModel.getProperty("/"));
					//that.getView().setModel(oXMLModel.getProperty("/"), "guid");

					//sap.ui.commons.MessageBox.alert("Incident Success Recorded");
				},
				function(oError) {
					sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				});

		},

		_uploadImage: function(Filename, RecordId, ObjectId, Source) {
			jQuery.sap.require("sap.ui.commons.MessageBox");
			var that = this;
			var sServiceUrl = "/destinations/WebMethods";
			var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, true);
			oModel.setHeaders({
				"X-Requested-With": "X"
			});

			var oDataJSONModel = new sap.ui.model.json.JSONModel();
			var oXMLModel = new sap.ui.model.xml.XMLModel();
			var oRecord = {};

			oRecord.Filename = Filename; // for safety
			oRecord.RecordId = RecordId;
			oRecord.ObjectId = ObjectId;
			oRecord.Source = Source;
			//sap.ui.commons.MessageBox.alert("workFlow");

			var query = "/rest/commonIntelex/restIntelex/PrivateDocumentAttachmentService";
			oModel.create(query, oRecord, null,
				function(oData, oResult) {
					//sap.ui.commons.MessageBox.alert(JSON.stringify(oResult, null, 4));
					oDataJSONModel.setData(oResult);
					var obody = oDataJSONModel.getProperty("/body");
					//	sap.ui.commons.MessageBox.alert(JSON.stringify(oResult, null, 4));
				},
				function(oError) {
					//		sap.ui.commons.MessageBox.alert(JSON.stringify(oError, null, 4));
				});

		},

		_setSafetyRecord: function() {

			var nameVal = [];
			var guid = "fe9a2075-a839-4880-a4ea-f46497282751"; //safety
			var dd = this.byId("date").getValue()[6] + this.byId("date").getValue()[7];
			var MM = this.byId("date").getValue()[4] + this.byId("date").getValue()[5];
			//MM = parseInt(MM) - 1;
			var yyyy = this.byId("date").getValue()[0] + this.byId("date").getValue()[1] +
				this.byId("date").getValue()[2] + this.byId("date").getValue()[3];

			var hh = this.byId("time").getValue()[0] + this.byId("time").getValue()[1];
			var mm = this.byId("time").getValue()[3] + this.byId("time").getValue()[4];

			var myDate = new Date(MM + '/' + dd + '/' + yyyy + ' ' + hh + ':' + mm + ':00');
			var month = myDate.getUTCMonth() + 1; //Month is between 0 - 11
			var newDate = myDate.getUTCDate() + '/' + month + '/' + myDate.getUTCFullYear() + ' ' + myDate.getUTCHours() + ':' + myDate.getUTCMinutes() +
				':00';
			//var newDate = new date().getUTCDate() +'/'+ mm + '/' + new date().getUTCFullYear() + ' ' + new date().getUTCHours()+':'+ new date().getUTCMinutes()+':00';

			//sap.ui.commons.MessageBox.alert("date:"+this.byId("date").getValue() + "time:"+ this.byId("time").getValue()+"new:"+ newDate);

			var i = 0;
			nameVal[i] = this._addField("Description", this.byId("describeincident").getValue());
			i++;
			nameVal[i] = this._addField("aTimeofIncident", newDate);
			i++;
			nameVal[i] = this._addField("causSeriousHarm", (this.byId("significant").getState() ? "yes" : "no"));
			i++;
			nameVal[i] = this._addField("situacontrolled", (this.byId("controlled").getState() ? "no" : "yes"));
			i++;
			nameVal[i] = this._addField("SignifiIncident", (this.byId("significant").getState() ? "no" : "yes"));
			if (!this.byId("significant").getState()) {
				i++;
				//nameVal[i] = this._addField("SigIncConfirm", "yes");		
				nameVal[i] = this._addField("CSignifIncident", "yes");

			}

			i++;
			nameVal[i] = this._addField("Offsiteincident", (this.byId("onsite").getState() ? "yes" : "no"));
			i++;
			nameVal[i] = this._addField("locationdetails", this.byId("exactlocation").getValue());
			i++;
			nameVal[i] = this._addField("aCapitalProject", (this.byId("capital").getState() ? "no" : "yes"));
			i++;
			nameVal[i] = this._addField("investiganeeded", (this.byId("investigation").getState() ? "no" : "yes"));
			i++;
			nameVal[i] = this._addField("WebfoSubmission", "No");
			i++;
			nameVal[i] = this._addField("Lionmobileapp", "Yes");

			i++;
			//sap.m.MessageToast.show("before location");
			if (this.byId("location").getVisible()) {
				nameVal[i] = this._addField("Location", this.byId("locationid").getText());
				i++;
				nameVal[i] = this._addField("Department", this.byId("department").getSelectedKey());
				i++;
				nameVal[i] = this._addField("subDepartment", this.byId("area").getSelectedKey());
				i++;
			}

			//sap.m.MessageToast.show("after location");

			nameVal[i] = this._addField("NeaMissCategory", this.byId("category").getSelectedKey());
			i++;

			nameVal[i] = this._addField("SysType", this.byId("reporttype").getSelectedKey());
			i++;

			nameVal[i] = this._addField("CoMeasuresTaken", this.byId("immediateaction").getValue());
			i++;

			nameVal[i] = this._addField("Reporter", this.byId("reportedby").getSelectedKey());
			i++;
			nameVal[i] = this._addField("SafIncidentType", guid);
			i++;
			nameVal[i] = this._addField("capitalProject", this.byId("projectname").getSelectedKey());

			return nameVal;
		},

		_setQualityRecord: function() {

			var nameVal = [];
			var guid = "4752aff2-3dca-4ebc-ba6c-d7fbd7cc6251";
			var dd = this.byId("date").getValue()[6] + this.byId("date").getValue()[7];
			var MM = this.byId("date").getValue()[4] + this.byId("date").getValue()[5];
			//	MM = parseInt(MM) - 1;
			var yyyy = this.byId("date").getValue()[0] + this.byId("date").getValue()[1] +
				this.byId("date").getValue()[2] + this.byId("date").getValue()[3];

			var hh = this.byId("time").getValue()[0] + this.byId("time").getValue()[1];
			var mm = this.byId("time").getValue()[3] + this.byId("time").getValue()[4];

			//			var newDate = dd + '/' + MM + '/' + yyyy + ' ' + hh + ':' + mm + ':00';
			var myDate = new Date(MM + '/' + dd + '/' + yyyy + ' ' + hh + ':' + mm + ':00');
			var month = myDate.getUTCMonth() + 1; //Month is between 0 - 11
			var newDate = myDate.getUTCDate() + '/' + month + '/' + myDate.getUTCFullYear() + ' ' + myDate.getUTCHours() + ':' + myDate.getUTCMinutes() +
				':00';

			var i = 0;
			nameVal[i] = this._addField("Description", this.byId("describeincident").getValue());
			i++;
			nameVal[i] = this._addField("aTimeofIncident", newDate);
			i++;
			//				nameVal[i] = this._addField("causSeriousHarm", (this.byId("significant").getState() ? "yes" : "no"));
			//				i++;
			nameVal[i] = this._addField("situacontrolled", (this.byId("controlled").getState() ? "no" : "yes"));
			i++;
			//				nameVal[i] = this._addField("SignifiIncident", (this.byId("significant").getState() ? "no" : "yes"));
			//				i++;
			//				nameVal[i] = this._addField("Offsiteincident", (this.byId("onsite").getState() ? "yes" : "no"));
			//				i++;
			nameVal[i] = this._addField("locationdetails", this.byId("exactlocation").getValue());
			i++;
			//				nameVal[i] = this._addField("aCapitalProject", (this.byId("capital").getState() ? "no" : "yes"));
			//				i++;
			nameVal[i] = this._addField("investiganeeded", (this.byId("investigation").getState() ? "no" : "yes"));
			i++;
			nameVal[i] = this._addField("WebfoSubmission", "No");
			i++;
			nameVal[i] = this._addField("Lionmobileapp", "Yes");
			i++;
			//sap.m.MessageToast.show("before location");
			if (this.byId("location").getVisible()) {
				nameVal[i] = this._addField("Location", this.byId("locationid").getText());
				i++;
				nameVal[i] = this._addField("Department", this.byId("department").getSelectedKey());
				i++;
				nameVal[i] = this._addField("subDepartment", this.byId("area").getSelectedKey());
				i++;
			}

			//sap.m.MessageToast.show("after location");

			nameVal[i] = this._addField("CategoAffected1", this.byId("category").getSelectedKey());
			i++;
			nameVal[i] = this._addField("CategoAffected2", this.byId("subcategory").getSelectedKey());
			i++;

			nameVal[i] = this._addField("SysType", this.byId("reporttype").getSelectedKey());
			i++;

			nameVal[i] = this._addField("CoMeasuresTaken", this.byId("immediateaction").getValue());
			i++;

			nameVal[i] = this._addField("Reporter", this.byId("reportedby").getSelectedKey());
			i++;
			//				nameVal[i] = this._addField("SafIncidentType", guid);
			//				i++;
			//				nameVal[i] = this._addField("capitalProject", this.byId("projectname").getSelectedItem().getKey());	

			return nameVal;
		},

		_setEnviroRecord: function() {

			var nameVal = [];
			var guid = "cfe8c187-f423-4c0d-86d2-f6071ad507c0";
			var dd = this.byId("date").getValue()[6] + this.byId("date").getValue()[7];
			var MM = this.byId("date").getValue()[4] + this.byId("date").getValue()[5];
			//	MM = parseInt(MM) - 1;
			var yyyy = this.byId("date").getValue()[0] + this.byId("date").getValue()[1] +
				this.byId("date").getValue()[2] + this.byId("date").getValue()[3];

			var hh = this.byId("time").getValue()[0] + this.byId("time").getValue()[1];
			var mm = this.byId("time").getValue()[3] + this.byId("time").getValue()[4];

			//			var newDate = dd + '/' + MM + '/' + yyyy + ' ' + hh + ':' + mm + ':00';
			var myDate = new Date(MM + '/' + dd + '/' + yyyy + ' ' + hh + ':' + mm + ':00');
			var month = myDate.getUTCMonth() + 1; //Month is between 0 - 11
			var newDate = myDate.getUTCDate() + '/' + month + '/' + myDate.getUTCFullYear() + ' ' + myDate.getUTCHours() + ':' + myDate.getUTCMinutes() +
				':00';

			//	sap.ui.commons.MessageBox.alert("Incedent date:"+newDate);

			var i = 0;
			nameVal[i] = this._addField("Description", this.byId("describeincident").getValue());
			i++;
			nameVal[i] = this._addField("aTimeofIncident", newDate);
			i++;
			//				nameVal[i] = this._addField("causSeriousHarm", (this.byId("significant").getState() ? "yes" : "no"));
			//				i++;
			nameVal[i] = this._addField("situacontrolled", (this.byId("controlled").getState() ? "no" : "yes"));
			i++;
			//				nameVal[i] = this._addField("SignifiIncident", (this.byId("significant").getState() ? "no" : "yes"));
			//				i++;
			nameVal[i] = this._addField("Offsite", (this.byId("onsite").getState() ? "yes" : "no"));
			i++;
			nameVal[i] = this._addField("locationdetails", this.byId("exactlocation").getValue());
			i++;
			//				nameVal[i] = this._addField("aCapitalProject", (this.byId("capital").getState() ? "no" : "yes"));
			//				i++;
			nameVal[i] = this._addField("investiganeeded", (this.byId("investigation").getState() ? "no" : "yes"));
			i++;
			nameVal[i] = this._addField("WebfoSubmission", "No");
			i++;
			nameVal[i] = this._addField("Lionmobileapp", "Yes");
			i++;
			//sap.m.MessageToast.show("before location");
			if (this.byId("location").getVisible()) {
				nameVal[i] = this._addField("Location", this.byId("locationid").getText());
				i++;
				nameVal[i] = this._addField("Department", this.byId("department").getSelectedKey());
				i++;
				nameVal[i] = this._addField("subDepartment", this.byId("area").getSelectedKey());
				i++;
			}

			//	sap.m.MessageToast.show("after location");

			nameVal[i] = this._addField("EnviIncCategory", this.byId("category").getSelectedKey());
			i++;

			nameVal[i] = this._addField("SysType", this.byId("reporttype").getSelectedKey());
			i++;

			nameVal[i] = this._addField("CoMeasuresTaken", this.byId("immediateaction").getValue());
			i++;

			nameVal[i] = this._addField("Reporter", this.byId("reportedby").getSelectedKey());
			i++;
			//<TextArea id="notcontrolled"/>
			if (this.byId("controlled").getState()) {
				nameVal[i] = this._addField("Exnotcontrolled", this.byId("notcontrolled").getValue());
				i++;
			}

			//				nameVal[i] = this._addField("SafIncidentType", guid);
			//				i++;
			//				nameVal[i] = this._addField("capitalProject", this.byId("projectname").getSelectedItem().getKey());	

			return nameVal;
		}

	});
});