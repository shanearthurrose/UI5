sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"nearmiss/model/models"
], function(UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("nearmiss.Component", {

		metadata: {
			manifest: "json"
		},
		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			jQuery.sap.require("sap.ui.commons.MessageBox");			
			var oModel = new sap.ui.model.json.JSONModel();
			var userModel = new sap.ui.model.json.JSONModel("/services/userapi/currentUser");
			userModel.loadData("/services/userapi/currentUser", null, false);

			this.setModel(userModel, "userInfo");			
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
		}
	});

});